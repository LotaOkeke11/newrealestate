import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey, X-Paystack-Signature",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const paystackSecretKey = Deno.env.get("PAYSTACK_SECRET_KEY");

    if (!paystackSecretKey) {
      throw new Error("Paystack secret key not configured");
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const signature = req.headers.get("x-paystack-signature");
    const body = await req.text();

    if (signature) {
      const encoder = new TextEncoder();
      const key = await crypto.subtle.importKey(
        "raw",
        encoder.encode(paystackSecretKey),
        { name: "HMAC", hash: "SHA-512" },
        false,
        ["sign"]
      );
      const signatureBytes = await crypto.subtle.sign(
        "HMAC",
        key,
        encoder.encode(body)
      );
      const hash = Array.from(new Uint8Array(signatureBytes))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');

      if (hash !== signature) {
        throw new Error("Invalid signature");
      }
    }

    const event = JSON.parse(body);

    console.log("Webhook event type:", event.event);

    if (event.event === "charge.success") {
      const data = event.data;
      const metadata = data.metadata;

      if (!metadata || !metadata.subscription) {
        return new Response(
          JSON.stringify({ received: true, message: "Not a subscription payment" }),
          {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json",
            },
          }
        );
      }

      const userId = metadata.userId;
      const tierId = metadata.tierId;

      if (!userId || !tierId) {
        throw new Error("Missing user or tier information in metadata");
      }

      const startDate = new Date();
      const endDate = new Date();
      endDate.setMonth(endDate.getMonth() + 1);

      const { error: deleteError } = await supabase
        .from("subscriptions")
        .delete()
        .eq("user_id", userId)
        .eq("status", "active");

      if (deleteError) {
        console.error("Error deleting old subscription:", deleteError);
      }

      const { error: insertError } = await supabase
        .from("subscriptions")
        .insert({
          user_id: userId,
          tier_id: tierId,
          status: "active",
          start_date: startDate.toISOString(),
          end_date: endDate.toISOString(),
          paystack_reference: data.reference,
          paystack_customer_code: data.customer?.customer_code,
        });

      if (insertError) {
        console.error("Error creating subscription:", insertError);
        throw insertError;
      }

      console.log("Subscription created successfully for user:", userId);
    }

    if (event.event === "subscription.disable") {
      const data = event.data;

      const { error } = await supabase
        .from("subscriptions")
        .update({ status: "canceled" })
        .eq("paystack_reference", data.subscription_code);

      if (error) {
        console.error("Error canceling subscription:", error);
      }
    }

    return new Response(
      JSON.stringify({ received: true }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Webhook error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Webhook processing failed" }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});