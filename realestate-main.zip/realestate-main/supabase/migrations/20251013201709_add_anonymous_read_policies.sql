/*
  # Add Anonymous Read Access for Public Browsing

  1. Changes
    - Add SELECT policies for anonymous users on categories and listings tables
    - This allows visitors to browse the website without signing up
    - Authentication is only required for actions like creating listings or viewing contact details

  2. Security
    - Anonymous users can only SELECT (read) data
    - They cannot INSERT, UPDATE, or DELETE
    - Authentication still required for all write operations
*/

-- Allow anonymous users to view active categories
CREATE POLICY "Categories are viewable by anonymous users"
  ON categories
  FOR SELECT
  TO anon
  USING (is_active = true);

-- Allow anonymous users to view active listings
CREATE POLICY "Listings are viewable by anonymous users"
  ON listings
  FOR SELECT
  TO anon
  USING (status = 'published' AND ai_moderation_status = 'approved');
