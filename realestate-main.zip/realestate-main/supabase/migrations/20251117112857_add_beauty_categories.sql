/*
  # Add Beauty & Personal Care Categories
  
  1. New Categories
    - Main category: Beauty & Personal Care
    - Subcategories:
      * Hair Salon Services
      * Wigs & Extensions
      * Makeup Services
      * Makeup Products
      * Skincare Products
      * Perfumes & Fragrances
      * Spa & Wellness
  
  2. Updates
    - Insert beauty main category and all subcategories
    - Set up proper parent-child relationships
*/

-- Insert main Beauty & Personal Care category
INSERT INTO categories (name, slug, icon, description, parent_id)
VALUES (
  'Beauty & Personal Care',
  'beauty-personal-care',
  '💄',
  'Beauty products and services including hair care, makeup, skincare, and fragrances',
  NULL
)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  icon = EXCLUDED.icon,
  description = EXCLUDED.description;

-- Get the parent category ID
DO $$
DECLARE
  beauty_category_id uuid;
BEGIN
  SELECT id INTO beauty_category_id
  FROM categories
  WHERE slug = 'beauty-personal-care';

  -- Insert subcategories
  INSERT INTO categories (name, slug, icon, description, parent_id)
  VALUES
    (
      'Hair Salon Services',
      'hair-salon-services',
      '💇',
      'Professional hair cutting, styling, coloring, and treatments',
      beauty_category_id
    ),
    (
      'Wigs & Extensions',
      'wigs-extensions',
      '👩‍🦱',
      'Human hair wigs, synthetic wigs, hair extensions, and closures',
      beauty_category_id
    ),
    (
      'Makeup Services',
      'makeup-services',
      '💄',
      'Professional makeup application for events, weddings, and photoshoots',
      beauty_category_id
    ),
    (
      'Makeup Products',
      'makeup-products',
      '💋',
      'Cosmetics including lipstick, foundation, eyeshadow, and more',
      beauty_category_id
    ),
    (
      'Skincare Products',
      'skincare-products',
      '🧴',
      'Face creams, serums, cleansers, masks, and skincare treatments',
      beauty_category_id
    ),
    (
      'Perfumes & Fragrances',
      'perfumes-fragrances',
      '🌸',
      'Designer perfumes, body sprays, essential oils, and fragrance sets',
      beauty_category_id
    ),
    (
      'Spa & Wellness',
      'spa-wellness',
      '🧖',
      'Spa treatments, massage therapy, facials, and wellness services',
      beauty_category_id
    )
  ON CONFLICT (slug) DO UPDATE SET
    name = EXCLUDED.name,
    icon = EXCLUDED.icon,
    description = EXCLUDED.description,
    parent_id = EXCLUDED.parent_id;
END $$;