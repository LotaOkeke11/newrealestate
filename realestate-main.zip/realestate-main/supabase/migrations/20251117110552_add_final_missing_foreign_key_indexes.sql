/*
  # Add Final Missing Foreign Key Indexes
  
  1. Performance Improvements
    - Add indexes on the last two foreign key columns without covering indexes
    - Improves JOIN performance and foreign key constraint checking
  
  2. Indexes Added
    - categories.parent_id - For category hierarchy queries
    - profiles.referred_by - For referral tracking queries
*/

-- Categories parent_id - for category hierarchy
CREATE INDEX IF NOT EXISTS idx_categories_parent_id 
ON categories(parent_id);

-- Profiles referred_by - for referral tracking
CREATE INDEX IF NOT EXISTS idx_profiles_referred_by 
ON profiles(referred_by);