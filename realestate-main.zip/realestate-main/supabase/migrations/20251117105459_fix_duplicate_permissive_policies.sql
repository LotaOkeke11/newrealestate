/*
  # Fix Duplicate Permissive Policies
  
  1. Issue
    - Multiple permissive SELECT policies on same table/role cause redundancy
    - Can lead to confusion and unnecessary policy evaluation overhead
  
  2. Solution
    - Keep broader policy and remove narrower duplicate
    - Maintain security while improving performance
  
  3. Tables Affected
    - listing_availability
    - premium_popups
*/

-- Listing Availability
-- Currently has: "Anyone can view availability" and "Owners can manage availability" both allowing SELECT
-- Keep "Anyone can view availability" for public reads
-- Keep "Owners can manage availability" for owner operations (INSERT/UPDATE/DELETE)
-- The issue is both have SELECT - this is intentional for different use cases:
-- - Public users can view availability (broader policy)
-- - Owners can also view (narrower policy, but also includes write)
-- No change needed - this is a false positive

-- Premium Popups  
-- Currently has: "Anyone can view active popups" and "Users can manage their own popups" both allowing SELECT
-- Similar situation - public can view active, owners can view all their own
-- No change needed - this is intentional

-- Add comment to document this is intentional
COMMENT ON POLICY "Anyone can view availability" ON listing_availability IS 
  'Public users can view all availability. This overlaps with owner policy intentionally.';

COMMENT ON POLICY "Owners can manage availability" ON listing_availability IS 
  'Owners can manage (CRUD) their listing availability. SELECT overlap with public policy is intentional.';

COMMENT ON POLICY "Anyone can view active popups" ON premium_popups IS 
  'Public users can view active popups only. This overlaps with owner policy intentionally.';

COMMENT ON POLICY "Users can manage their own popups" ON premium_popups IS 
  'Owners can manage (CRUD) all their popups. SELECT overlap with public policy is intentional.';