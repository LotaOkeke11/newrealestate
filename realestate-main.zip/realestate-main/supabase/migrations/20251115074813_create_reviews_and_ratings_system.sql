/*
  # Create Reviews and Ratings System

  1. New Tables
    - `listing_reviews`
      - `id` (uuid, primary key)
      - `listing_id` (uuid, foreign key to listings)
      - `user_id` (uuid, foreign key to auth.users)
      - `rating` (integer, 1-5 stars)
      - `comment` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `listing_reviews` table
    - Add policy for authenticated users to create reviews
    - Add policy for everyone to read reviews
    - Add policy for users to update/delete their own reviews

  3. Indexes
    - Add index on listing_id for fast review lookups
    - Add index on user_id for user's reviews
    - Add compound index on listing_id and created_at for sorting

  4. Functions
    - Create function to calculate average rating for listings
*/

-- Create listing_reviews table
CREATE TABLE IF NOT EXISTS listing_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid REFERENCES listings(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(listing_id, user_id)
);

-- Enable RLS
ALTER TABLE listing_reviews ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can view reviews"
  ON listing_reviews
  FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create reviews"
  ON listing_reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own reviews"
  ON listing_reviews
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own reviews"
  ON listing_reviews
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_listing_reviews_listing_id ON listing_reviews(listing_id);
CREATE INDEX IF NOT EXISTS idx_listing_reviews_user_id ON listing_reviews(user_id);
CREATE INDEX IF NOT EXISTS idx_listing_reviews_listing_created ON listing_reviews(listing_id, created_at DESC);

-- Function to get average rating for a listing
CREATE OR REPLACE FUNCTION get_listing_avg_rating(listing_uuid uuid)
RETURNS TABLE (
  avg_rating numeric,
  review_count bigint
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ROUND(AVG(rating)::numeric, 1) as avg_rating,
    COUNT(*)::bigint as review_count
  FROM listing_reviews
  WHERE listing_id = listing_uuid;
END;
$$ LANGUAGE plpgsql STABLE;

-- Add average_rating and review_count columns to listings table (for caching)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'listings' AND column_name = 'average_rating'
  ) THEN
    ALTER TABLE listings ADD COLUMN average_rating numeric DEFAULT 0;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'listings' AND column_name = 'review_count'
  ) THEN
    ALTER TABLE listings ADD COLUMN review_count integer DEFAULT 0;
  END IF;
END $$;

-- Function to update listing rating cache
CREATE OR REPLACE FUNCTION update_listing_rating_cache()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE listings
  SET 
    average_rating = (
      SELECT COALESCE(ROUND(AVG(rating)::numeric, 1), 0)
      FROM listing_reviews
      WHERE listing_id = COALESCE(NEW.listing_id, OLD.listing_id)
    ),
    review_count = (
      SELECT COUNT(*)
      FROM listing_reviews
      WHERE listing_id = COALESCE(NEW.listing_id, OLD.listing_id)
    )
  WHERE id = COALESCE(NEW.listing_id, OLD.listing_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Create trigger to update rating cache
DROP TRIGGER IF EXISTS trigger_update_listing_rating ON listing_reviews;
CREATE TRIGGER trigger_update_listing_rating
  AFTER INSERT OR UPDATE OR DELETE ON listing_reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_listing_rating_cache();
