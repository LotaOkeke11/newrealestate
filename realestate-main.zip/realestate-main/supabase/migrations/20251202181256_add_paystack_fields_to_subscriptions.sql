/*
  # Add Paystack fields to subscriptions table

  1. Changes
    - Add `tier_id` column to reference subscription_tiers
    - Add `start_date` column for subscription start
    - Add `end_date` column for subscription end
    - Add `paystack_reference` column for Paystack transaction reference
    - Add `paystack_customer_code` column for Paystack customer code
    - Rename existing columns to match webhook expectations

  2. Notes
    - Maintains backward compatibility with existing data
    - Sets reasonable defaults for new columns
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'tier_id'
  ) THEN
    ALTER TABLE subscriptions ADD COLUMN tier_id uuid REFERENCES subscription_tiers(id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'start_date'
  ) THEN
    ALTER TABLE subscriptions ADD COLUMN start_date timestamptz DEFAULT now();
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'end_date'
  ) THEN
    ALTER TABLE subscriptions ADD COLUMN end_date timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'paystack_reference'
  ) THEN
    ALTER TABLE subscriptions ADD COLUMN paystack_reference text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'paystack_customer_code'
  ) THEN
    ALTER TABLE subscriptions ADD COLUMN paystack_customer_code text;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_subscriptions_tier_id ON subscriptions(tier_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_paystack_reference ON subscriptions(paystack_reference);
