/*
  # Document Intentional Policy Overlaps
  
  1. Issue
    - Multiple permissive SELECT policies reported as potential issue
    - These are intentional by design, not security problems
  
  2. Explanation
    - listing_availability: Public read access + Owner full access
    - premium_popups: Public filtered access + Owner full access
    - Both patterns are correct and intentional
  
  3. Solution
    - Document policies to clarify intentional design
    - Add comments explaining why overlaps exist
*/

-- Listing Availability Policies
-- Public users need read-only access to view availability
-- Owners need full CRUD access to manage their availability
-- Both policies have SELECT, but serve different use cases
COMMENT ON POLICY "Anyone can view availability" ON listing_availability IS 
  'Allows public users to view availability for booking purposes. Intentional overlap with owner policy for different access scopes.';

COMMENT ON POLICY "Owners can manage availability" ON listing_availability IS 
  'Allows listing owners full CRUD access to their availability. SELECT overlap with public policy is intentional - different use cases.';

-- Premium Popups Policies  
-- Public users can only see active popups (filtered)
-- Owners can see and manage all their popups (unfiltered)
-- Both policies have SELECT, but with different filters
COMMENT ON POLICY "Anyone can view active popups" ON premium_popups IS 
  'Allows public users to view only active popups. Intentional overlap with owner policy - public sees filtered subset.';

COMMENT ON POLICY "Users can manage their own popups" ON premium_popups IS 
  'Allows popup owners full CRUD access to all their popups. SELECT overlap with public policy is intentional - owners see all, public sees filtered.';

-- This is correct security design:
-- - Public users: Limited read access with filters
-- - Owners: Full access without filters
-- - Overlapping SELECT permissions serve different purposes