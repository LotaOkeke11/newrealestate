/*
  # Subscription Tiers and Category Access
  
  1. New Tables
    - `subscription_tiers`
      - `id` (uuid, primary key)
      - `name` (text) - Tier name (Free, Basic, Pro, Premium, Enterprise)
      - `price` (numeric) - Monthly price in NGN
      - `description` (text) - Tier description
      - `features` (jsonb) - Array of features
      - `max_listings` (integer) - Maximum listings allowed
      - `level` (integer) - Tier level for ordering (1-5)
      - `created_at` (timestamp)
    
    - `tier_categories`
      - `id` (uuid, primary key)
      - `tier_id` (uuid, foreign key)
      - `category_id` (uuid, foreign key)
      - `created_at` (timestamp)
    
    - `user_subscriptions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `tier_id` (uuid, foreign key)
      - `status` (text) - active, cancelled, expired
      - `starts_at` (timestamp)
      - `ends_at` (timestamp)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
  
  2. Security
    - Enable RLS on all tables
    - Users can view their own subscriptions
    - Anyone can view subscription tiers and tier categories
*/

CREATE TABLE IF NOT EXISTS subscription_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  price numeric NOT NULL DEFAULT 0,
  description text,
  features jsonb DEFAULT '[]'::jsonb,
  max_listings integer NOT NULL DEFAULT 5,
  level integer NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tier_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tier_id uuid NOT NULL REFERENCES subscription_tiers(id) ON DELETE CASCADE,
  category_id uuid NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(tier_id, category_id)
);

CREATE TABLE IF NOT EXISTS user_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tier_id uuid NOT NULL REFERENCES subscription_tiers(id),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'expired')),
  starts_at timestamptz NOT NULL DEFAULT now(),
  ends_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, tier_id, status)
);

ALTER TABLE subscription_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE tier_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view subscription tiers"
  ON subscription_tiers FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view tier categories"
  ON tier_categories FOR SELECT
  USING (true);

CREATE POLICY "Users can view own subscriptions"
  ON user_subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own subscriptions"
  ON user_subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own subscriptions"
  ON user_subscriptions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

INSERT INTO subscription_tiers (name, price, description, features, max_listings, level) VALUES
  ('Free', 0, 'Perfect for getting started', 
   '["Post up to 5 listings", "Basic category access", "Standard support", "7 days listing duration"]'::jsonb, 
   5, 1),
  ('Basic', 2500, 'Great for small sellers', 
   '["Post up to 25 listings", "Access to 3 categories", "Priority support", "30 days listing duration", "Featured badge"]'::jsonb, 
   25, 2),
  ('Pro', 7500, 'Ideal for growing businesses', 
   '["Post up to 100 listings", "Access to 6 categories", "Premium support", "60 days listing duration", "Featured badge", "Analytics dashboard", "Boost listings"]'::jsonb, 
   100, 3),
  ('Premium', 15000, 'For established businesses', 
   '["Post up to 500 listings", "Access to 9 categories", "24/7 VIP support", "90 days listing duration", "Top featured badge", "Advanced analytics", "Unlimited boosts", "Verified seller badge"]'::jsonb, 
   500, 4),
  ('Enterprise', 35000, 'Unlimited potential', 
   '["Unlimited listings", "Access to all categories", "Dedicated account manager", "365 days listing duration", "Premium featured badge", "Custom analytics", "Priority placement", "API access", "White-label options"]'::jsonb, 
   999999, 5);
