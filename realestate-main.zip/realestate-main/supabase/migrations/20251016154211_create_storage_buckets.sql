/*
  # Create Storage Buckets for Images

  1. New Storage Buckets
    - `listing-images`: For product/listing images
    - `verification-documents`: For seller verification documents

  2. Security
    - Enable RLS on storage buckets
    - Authenticated users can upload to listing-images
    - Authenticated users can upload to verification-documents
    - Anyone can view listing-images (public)
    - Only owners can view verification-documents

  3. Notes
    - listing-images is public for product display
    - verification-documents is private for security
*/

-- Create listing-images bucket (public)
INSERT INTO storage.buckets (id, name, public)
VALUES ('listing-images', 'listing-images', true)
ON CONFLICT (id) DO NOTHING;

-- Create verification-documents bucket (private)
INSERT INTO storage.buckets (id, name, public)
VALUES ('verification-documents', 'verification-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for listing-images (public bucket)
CREATE POLICY "Anyone can view listing images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'listing-images');

CREATE POLICY "Authenticated users can upload listing images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'listing-images');

CREATE POLICY "Users can update own listing images"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'listing-images' AND auth.uid()::text = (storage.foldername(name))[1])
  WITH CHECK (bucket_id = 'listing-images' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete own listing images"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'listing-images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Storage policies for verification-documents (private bucket)
CREATE POLICY "Users can upload own verification documents"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'verification-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view own verification documents"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'verification-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update own verification documents"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'verification-documents' AND auth.uid()::text = (storage.foldername(name))[1])
  WITH CHECK (bucket_id = 'verification-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete own verification documents"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'verification-documents' AND auth.uid()::text = (storage.foldername(name))[1]);
