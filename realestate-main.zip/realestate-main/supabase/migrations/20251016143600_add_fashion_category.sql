/*
  # Add Fashion Category

  1. New Category
    - Add 'fashion' category (in addition to existing 'fashion-lifestyle')
    - This matches the slug expected by UploadFashionPage

  2. Notes
    - fashion-lifestyle remains for general fashion items
    - fashion is the main category for fashion upload form
*/

INSERT INTO categories (name, slug, description, icon, is_active)
VALUES ('Fashion', 'fashion', 'Clothing, shoes, and fashion accessories', '👗', true)
ON CONFLICT (slug) DO NOTHING;
