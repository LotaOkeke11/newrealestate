/*
  # Fix Anonymous User Access to Homepage Content

  1. Changes
    - Drop old restrictive policies
    - Create new policies allowing anonymous users to view active listings
    - Allow access to profiles for seller information
    - Fix status field to use 'active' instead of 'published'

  2. Security
    - Anonymous users can only read (SELECT) data
    - Cannot modify or delete anything
    - Authentication required for write operations
*/

-- Drop old restrictive policies if they exist
DROP POLICY IF EXISTS "Listings are viewable by anonymous users" ON listings;
DROP POLICY IF EXISTS "Listings are viewable by everyone" ON listings;
DROP POLICY IF EXISTS "Public can view active listings" ON listings;
DROP POLICY IF EXISTS "Categories are viewable by anonymous users" ON categories;
DROP POLICY IF EXISTS "Public can view active categories" ON categories;

-- Create comprehensive policy for listings (works with 'active' status)
CREATE POLICY "Allow public read access to active listings"
  ON listings
  FOR SELECT
  USING (status = 'active');

-- Create policy for categories
CREATE POLICY "Allow public read access to active categories"
  ON categories
  FOR SELECT
  USING (is_active = true);

-- Allow anonymous users to read profiles (for seller names, etc)
DROP POLICY IF EXISTS "Profiles are viewable by everyone" ON profiles;
CREATE POLICY "Allow public read access to profiles"
  ON profiles
  FOR SELECT
  USING (true);

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon, authenticated;
