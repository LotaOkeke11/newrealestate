/*
  # Add Missing Listing Columns for PropertyPro, Jiji, and Airbnb Forms
  
  1. Real Estate / PropertyPro Fields
    - toilets (integer)
    - parking_spaces (integer)  
    - year_built (integer)
    - is_serviced (boolean)
    - is_newly_built (boolean)
    - location_address (text)
    - nearby_landmarks (text)
    - listing_type (text) - for sale/rent/shortlet
    
  2. Vehicles / Jiji Fields
    - vehicle_make (text) - replaces 'make'
    - vehicle_model (text) - replaces 'model'
    - vehicle_year (integer) - replaces 'year'
    - vehicle_condition (text)
    - body_type (text)
    - exterior_color (text)
    - interior_color (text)
    - engine_size (text)
    - seats (integer)
    - doors (integer)
    - registered_city (text)
    - customs_duty (text)
    - accident_history (text)
    - vin (text)
    - features (jsonb)
    - price_negotiable (boolean)
    
  3. Shortlet / Airbnb Fields
    - space_type (text) - entire place, private room, shared room
    - guests (integer)
    - beds (integer)
    - pricing_model (text) - sale, rent, shortlet
    - cleaning_fee (numeric)
    - security_deposit (numeric)
    - minimum_nights (integer)
    - maximum_nights (integer)
    - check_in_time (text)
    - check_out_time (text)
    - instant_book (boolean)
    - location_description (text)
*/

DO $$
BEGIN
  -- Real Estate / PropertyPro columns
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'toilets') THEN
    ALTER TABLE listings ADD COLUMN toilets integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'parking_spaces') THEN
    ALTER TABLE listings ADD COLUMN parking_spaces integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'year_built') THEN
    ALTER TABLE listings ADD COLUMN year_built integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'is_serviced') THEN
    ALTER TABLE listings ADD COLUMN is_serviced boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'is_newly_built') THEN
    ALTER TABLE listings ADD COLUMN is_newly_built boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'location_address') THEN
    ALTER TABLE listings ADD COLUMN location_address text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'nearby_landmarks') THEN
    ALTER TABLE listings ADD COLUMN nearby_landmarks text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'listing_type') THEN
    ALTER TABLE listings ADD COLUMN listing_type text;
  END IF;
  
  -- Vehicles / Jiji columns
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'vehicle_make') THEN
    ALTER TABLE listings ADD COLUMN vehicle_make text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'vehicle_model') THEN
    ALTER TABLE listings ADD COLUMN vehicle_model text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'vehicle_year') THEN
    ALTER TABLE listings ADD COLUMN vehicle_year integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'vehicle_condition') THEN
    ALTER TABLE listings ADD COLUMN vehicle_condition text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'body_type') THEN
    ALTER TABLE listings ADD COLUMN body_type text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'exterior_color') THEN
    ALTER TABLE listings ADD COLUMN exterior_color text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'interior_color') THEN
    ALTER TABLE listings ADD COLUMN interior_color text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'engine_size') THEN
    ALTER TABLE listings ADD COLUMN engine_size text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'seats') THEN
    ALTER TABLE listings ADD COLUMN seats integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'doors') THEN
    ALTER TABLE listings ADD COLUMN doors integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'registered_city') THEN
    ALTER TABLE listings ADD COLUMN registered_city text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'customs_duty') THEN
    ALTER TABLE listings ADD COLUMN customs_duty text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'accident_history') THEN
    ALTER TABLE listings ADD COLUMN accident_history text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'vin') THEN
    ALTER TABLE listings ADD COLUMN vin text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'features') THEN
    ALTER TABLE listings ADD COLUMN features jsonb;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'price_negotiable') THEN
    ALTER TABLE listings ADD COLUMN price_negotiable boolean DEFAULT false;
  END IF;
  
  -- Shortlet / Airbnb columns
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'space_type') THEN
    ALTER TABLE listings ADD COLUMN space_type text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'guests') THEN
    ALTER TABLE listings ADD COLUMN guests integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'beds') THEN
    ALTER TABLE listings ADD COLUMN beds integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'pricing_model') THEN
    ALTER TABLE listings ADD COLUMN pricing_model text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'cleaning_fee') THEN
    ALTER TABLE listings ADD COLUMN cleaning_fee numeric;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'security_deposit') THEN
    ALTER TABLE listings ADD COLUMN security_deposit numeric;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'minimum_nights') THEN
    ALTER TABLE listings ADD COLUMN minimum_nights integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'maximum_nights') THEN
    ALTER TABLE listings ADD COLUMN maximum_nights integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'check_in_time') THEN
    ALTER TABLE listings ADD COLUMN check_in_time text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'check_out_time') THEN
    ALTER TABLE listings ADD COLUMN check_out_time text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'instant_book') THEN
    ALTER TABLE listings ADD COLUMN instant_book boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'listings' AND column_name = 'location_description') THEN
    ALTER TABLE listings ADD COLUMN location_description text;
  END IF;
END $$;
