/*
  # Add 'deleted' status to listings

  1. Changes
    - Drop existing status check constraint
    - Add new constraint with 'deleted' status included
    - This allows sellers to mark listings as deleted

  2. Allowed statuses after migration
    - active: Listing is live and visible
    - sold: Item has been sold
    - expired: Listing has expired
    - flagged: Flagged for review
    - draft: Not yet published
    - deleted: Soft deleted by seller
*/

-- Drop the existing constraint
ALTER TABLE listings DROP CONSTRAINT IF EXISTS listings_status_check;

-- Add new constraint with 'deleted' status
ALTER TABLE listings ADD CONSTRAINT listings_status_check 
  CHECK (status IN ('active', 'sold', 'expired', 'flagged', 'draft', 'deleted'));
