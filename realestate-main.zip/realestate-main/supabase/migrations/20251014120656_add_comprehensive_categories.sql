/*
  # Add Comprehensive Category System
  
  1. Categories
    - Real Estate (with subcategories)
    - Media & Creative Equipment
    - Vehicles & Rentals
    - Music & Entertainment
    - Jobs & Services
    - Home & Living
    - Fashion & Lifestyle
    - Travel & Hospitality
  
  2. Fields
    - Add rental_duration field for rental listings
    - Add service_type for jobs/services
    - Add portfolio_urls for service providers
*/

-- Insert main categories and subcategories
DO $$
BEGIN
  -- Real Estate
  INSERT INTO categories (name, slug, description, icon, is_active)
  VALUES 
    ('Real Estate', 'real-estate', 'Properties for rent, sale, and investment', '🏘️', true),
    ('Rent', 'rent', 'Residential and commercial rentals', '🏠', true),
    ('Sale', 'sale', 'Properties for sale', '🏡', true),
    ('Shortlets', 'shortlets', 'Short-term rentals and stays', '🏖️', true),
    ('Lands', 'lands', 'Land for sale or lease', '🌄', true),
    ('Commercial', 'commercial', 'Commercial properties', '🏢', true)
  ON CONFLICT (slug) DO NOTHING;

  -- Media & Creative Equipment
  INSERT INTO categories (name, slug, description, icon, is_active)
  VALUES 
    ('Media & Creative', 'media-creative', 'Professional media and creative equipment', '📷', true),
    ('Cameras', 'cameras', 'Cameras and lenses', '📸', true),
    ('Lighting', 'lighting', 'Studio and event lighting', '💡', true),
    ('Audio Equipment', 'audio-equipment', 'Microphones, mixers, and sound gear', '🎤', true),
    ('Drones', 'drones', 'Drones and aerial equipment', '🚁', true),
    ('Studio Rentals', 'studio-rentals', 'Photography and video studios', '🎬', true)
  ON CONFLICT (slug) DO NOTHING;

  -- Vehicles & Rentals
  INSERT INTO categories (name, slug, description, icon, is_active)
  VALUES 
    ('Vehicles', 'vehicles', 'Cars, motorcycles, and vehicle rentals', '🚗', true),
    ('Cars for Sale', 'cars-sale', 'New and used cars', '🚙', true),
    ('Luxury Rentals', 'luxury-rentals', 'Premium vehicle rentals', '🏎️', true),
    ('Motorcycles', 'motorcycles', 'Bikes and scooters', '🏍️', true),
    ('Boats & Marine', 'boats-marine', 'Boats and watercraft', '⛵', true),
    ('Auto Parts', 'auto-parts', 'Vehicle parts and accessories', '🔧', true)
  ON CONFLICT (slug) DO NOTHING;

  -- Music & Entertainment
  INSERT INTO categories (name, slug, description, icon, is_active)
  VALUES 
    ('Music & Entertainment', 'music-entertainment', 'Music gear and entertainment services', '🎵', true),
    ('DJ Equipment', 'dj-equipment', 'DJ gear and controllers', '🎧', true),
    ('Stage Lights', 'stage-lights', 'Performance lighting', '✨', true),
    ('Instruments', 'instruments', 'Musical instruments', '🎸', true),
    ('Performers', 'performers', 'Artists and entertainers', '🎭', true)
  ON CONFLICT (slug) DO NOTHING;

  -- Jobs & Services
  INSERT INTO categories (name, slug, description, icon, is_active)
  VALUES 
    ('Jobs & Services', 'jobs-services', 'Professional creative services', '💼', true),
    ('Videographers', 'videographers', 'Video production services', '🎥', true),
    ('Photographers', 'photographers', 'Photography services', '📷', true),
    ('Editors', 'editors', 'Video and photo editing', '✂️', true),
    ('Designers', 'designers', 'Graphic and web design', '🎨', true),
    ('Event Planners', 'event-planners', 'Event planning services', '🎉', true)
  ON CONFLICT (slug) DO NOTHING;

  -- Home & Living
  INSERT INTO categories (name, slug, description, icon, is_active)
  VALUES 
    ('Home & Living', 'home-living', 'Furniture and home services', '🏠', true),
    ('Furniture', 'furniture', 'Home and office furniture', '🛋️', true),
    ('Interior Design', 'interior-design', 'Interior design services', '🖼️', true),
    ('Cleaning Services', 'cleaning-services', 'Professional cleaning', '🧹', true),
    ('Security', 'security', 'Home security services', '🔒', true)
  ON CONFLICT (slug) DO NOTHING;

  -- Fashion & Lifestyle
  INSERT INTO categories (name, slug, description, icon, is_active)
  VALUES 
    ('Fashion & Lifestyle', 'fashion-lifestyle', 'Fashion and beauty products', '👗', true),
    ('Men Fashion', 'men-fashion', 'Men''s clothing and accessories', '👔', true),
    ('Women Fashion', 'women-fashion', 'Women''s clothing and accessories', '👠', true),
    ('Accessories', 'accessories', 'Fashion accessories', '👜', true),
    ('Beauty', 'beauty', 'Beauty products and services', '💄', true)
  ON CONFLICT (slug) DO NOTHING;

  -- Travel & Hospitality
  INSERT INTO categories (name, slug, description, icon, is_active)
  VALUES 
    ('Travel & Hospitality', 'travel-hospitality', 'Travel and accommodation', '✈️', true),
    ('Hotels', 'hotels', 'Hotel bookings', '🏨', true),
    ('Tours', 'tours', 'Tour packages and guides', '🗺️', true),
    ('Event Spaces', 'event-spaces', 'Venues for events', '🎪', true)
  ON CONFLICT (slug) DO NOTHING;
END $$;

-- Add new fields to listings table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'listings' AND column_name = 'rental_duration'
  ) THEN
    ALTER TABLE listings ADD COLUMN rental_duration text CHECK (rental_duration IN ('hourly', 'daily', 'weekly', 'monthly', 'yearly'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'listings' AND column_name = 'service_type'
  ) THEN
    ALTER TABLE listings ADD COLUMN service_type text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'listings' AND column_name = 'portfolio_urls'
  ) THEN
    ALTER TABLE listings ADD COLUMN portfolio_urls text[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'listings' AND column_name = 'is_rental'
  ) THEN
    ALTER TABLE listings ADD COLUMN is_rental boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'listings' AND column_name = 'is_featured'
  ) THEN
    ALTER TABLE listings ADD COLUMN is_featured boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'listings' AND column_name = 'price_per_unit'
  ) THEN
    ALTER TABLE listings ADD COLUMN price_per_unit text DEFAULT 'fixed';
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_listings_rental ON listings(is_rental) WHERE is_rental = true;
CREATE INDEX IF NOT EXISTS idx_listings_featured ON listings(is_featured) WHERE is_featured = true;
CREATE INDEX IF NOT EXISTS idx_listings_rental_duration ON listings(rental_duration) WHERE rental_duration IS NOT NULL;
