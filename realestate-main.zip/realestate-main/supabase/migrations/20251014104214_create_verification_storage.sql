/*
  # Create Storage for Verification Documents
  
  1. Storage
    - Create verification-documents bucket
    - Set up RLS policies for secure uploads
  
  2. Security
    - Users can only upload their own documents
    - Users can read their own documents
    - Admin can read all documents
*/

-- Create the storage bucket (this needs to be done via Supabase dashboard or API)
-- The following is documentation of what needs to be set up

-- Note: Storage buckets are typically created through Supabase dashboard
-- This migration documents the expected configuration

-- Bucket name: verification-documents
-- Public: false
-- File size limit: 10MB
-- Allowed MIME types: image/*, application/pdf

-- RLS policies would be:
-- 1. Users can upload to their own folder: bucket_id = 'verification-documents' AND (storage.foldername(name))[1] = auth.uid()::text
-- 2. Users can read their own files: bucket_id = 'verification-documents' AND (storage.foldername(name))[1] = auth.uid()::text

-- For now, we'll add a helper function to check document ownership
CREATE OR REPLACE FUNCTION check_verification_document_owner(document_path text)
RETURNS boolean AS $$
BEGIN
  -- Extract user_id from path (format: user_id/filename)
  RETURN split_part(document_path, '/', 1)::uuid = auth.uid();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
