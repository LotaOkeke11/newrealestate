/*
  # Add Food & Restaurants Categories
  
  1. New Categories
    - Foodstuffs (groceries like rice, oil, beans)
    - Restaurants (food menus, delivery services)
  
  2. Changes
    - Add food-related categories to the categories table
    - Ensure unique category slugs
  
  3. Notes
    - Categories will support listing foodstuffs with quantities and units
    - Restaurant listings will support menu items with prices and descriptions
*/

-- Insert Food & Restaurants parent category if not exists
INSERT INTO categories (name, slug, icon, parent_id, created_at)
VALUES ('Food & Restaurants', 'food-restaurants', 'utensils', NULL, now())
ON CONFLICT (slug) DO NOTHING;

-- Get the parent category id
DO $$
DECLARE
  parent_cat_id uuid;
BEGIN
  SELECT id INTO parent_cat_id FROM categories WHERE slug = 'food-restaurants';
  
  -- Insert Foodstuffs subcategory
  INSERT INTO categories (name, slug, icon, parent_id, created_at)
  VALUES ('Foodstuffs', 'foodstuffs', 'shopping-basket', parent_cat_id, now())
  ON CONFLICT (slug) DO NOTHING;
  
  -- Insert Restaurants subcategory
  INSERT INTO categories (name, slug, icon, parent_id, created_at)
  VALUES ('Restaurants', 'restaurants', 'utensils', parent_cat_id, now())
  ON CONFLICT (slug) DO NOTHING;
END $$;