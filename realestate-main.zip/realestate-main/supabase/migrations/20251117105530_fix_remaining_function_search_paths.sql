/*
  # Fix Remaining Function Search Paths
  
  1. Security Issue
    - Functions with mutable search_path are vulnerable to injection attacks
    - SECURITY DEFINER functions need immutable search_path
  
  2. Solution
    - Set search_path = public, pg_temp on all function variants
    - Recreate triggers that depend on these functions
  
  3. Functions Fixed
    - check_creative_portfolio_owner (both signatures)
    - check_listing_owner (both signatures)
    - check_verification_document_owner (both signatures)
*/

-- Check creative portfolio owner (no arguments - trigger version)
DROP FUNCTION IF EXISTS public.check_creative_portfolio_owner() CASCADE;
CREATE FUNCTION public.check_creative_portfolio_owner()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE plpgsql
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.creative_profiles
    WHERE id = NEW.creative_profile_id
    AND user_id = auth.uid()
  ) THEN
    RAISE EXCEPTION 'You can only add portfolio items to your own profile';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Check creative portfolio owner (with file_path argument - storage policy version)
DROP FUNCTION IF EXISTS public.check_creative_portfolio_owner(text) CASCADE;
CREATE FUNCTION public.check_creative_portfolio_owner(file_path text)
RETURNS boolean
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE plpgsql
AS $$
DECLARE
  profile_id uuid;
BEGIN
  profile_id := (regexp_match(file_path, 'portfolio/([0-9a-f-]+)/'))[1]::uuid;
  
  RETURN EXISTS (
    SELECT 1 FROM public.creative_profiles
    WHERE id = profile_id
    AND user_id = auth.uid()
  );
END;
$$;

-- Check listing owner (no arguments - trigger version)
DROP FUNCTION IF EXISTS public.check_listing_owner() CASCADE;
CREATE FUNCTION public.check_listing_owner()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE plpgsql
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.listings
    WHERE id = NEW.listing_id
    AND user_id = auth.uid()
  ) THEN
    RAISE EXCEPTION 'You can only modify your own listings';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Check listing owner (with file_path argument - storage policy version)
DROP FUNCTION IF EXISTS public.check_listing_owner(text) CASCADE;
CREATE FUNCTION public.check_listing_owner(file_path text)
RETURNS boolean
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE plpgsql
AS $$
DECLARE
  listing_id uuid;
BEGIN
  listing_id := (regexp_match(file_path, 'listings/([0-9a-f-]+)/'))[1]::uuid;
  
  RETURN EXISTS (
    SELECT 1 FROM public.listings
    WHERE id = listing_id
    AND user_id = auth.uid()
  );
END;
$$;

-- Check verification document owner (no arguments - trigger version)
DROP FUNCTION IF EXISTS public.check_verification_document_owner() CASCADE;
CREATE FUNCTION public.check_verification_document_owner()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.user_id != auth.uid() THEN
    RAISE EXCEPTION 'You can only upload verification documents for yourself';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Check verification document owner (with document_path argument - storage policy version)
DROP FUNCTION IF EXISTS public.check_verification_document_owner(text) CASCADE;
CREATE FUNCTION public.check_verification_document_owner(document_path text)
RETURNS boolean
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE plpgsql
AS $$
DECLARE
  doc_user_id uuid;
BEGIN
  doc_user_id := (regexp_match(document_path, 'verifications/([0-9a-f-]+)/'))[1]::uuid;
  
  RETURN doc_user_id = auth.uid();
END;
$$;

-- Recreate triggers
DROP TRIGGER IF EXISTS check_portfolio_owner ON public.creative_portfolio_items;
CREATE TRIGGER check_portfolio_owner
  BEFORE INSERT OR UPDATE ON public.creative_portfolio_items
  FOR EACH ROW
  EXECUTE FUNCTION public.check_creative_portfolio_owner();

DROP TRIGGER IF EXISTS check_verification_owner ON public.seller_verifications;
CREATE TRIGGER check_verification_owner
  BEFORE INSERT OR UPDATE ON public.seller_verifications
  FOR EACH ROW
  EXECUTE FUNCTION public.check_verification_document_owner();