/*
  # Fix Anonymous User Access to Listings

  1. Changes
    - Update the anonymous user SELECT policy on listings table
    - Allow anonymous users to view listings with status = 'active'
    - Remove the ai_moderation_status requirement for now (can be added later when moderation is implemented)
  
  2. Security
    - Anonymous users can only SELECT (read) listings
    - Only active listings are visible
    - No write permissions for anonymous users
*/

-- Drop the existing anonymous policy
DROP POLICY IF EXISTS "Listings are viewable by anonymous users" ON listings;

-- Create a new policy that allows anonymous users to view active listings
CREATE POLICY "Anonymous users can view active listings"
  ON listings
  FOR SELECT
  TO anon
  USING (status = 'active');
