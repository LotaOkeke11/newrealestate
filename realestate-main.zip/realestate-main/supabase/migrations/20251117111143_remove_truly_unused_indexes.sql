/*
  # Remove Truly Unused Indexes
  
  1. Analysis
    - Many indexes are on tables/features not yet active
    - Keeping foreign key indexes that will be needed for active features
    - Removing indexes for inactive/future features to reduce overhead
  
  2. Strategy
    - KEEP: Indexes for active features (messages, listings, profiles, categories)
    - REMOVE: Indexes for inactive features that can be added when needed
  
  3. Indexes to Remove (Inactive Features)
    - seller_verifications (feature not active)
    - subscriptions (feature not active)
    - reviews (feature not active)
    - analytics_events (feature not active)
    - tier_categories (feature not active)
    - user_subscriptions (feature not active)
    - favorites (feature not active)
    - listing_reviews (feature not active)
    - cart_items (feature not active)
    - orders (feature not active)
    - order_items (feature not active)
    - creative_profiles (feature not active)
    - creative_verifications (feature not active)
    - creative_portfolio_items (feature not active)
    - creative_ratings (feature not active)
    - premium_popups (feature not active)
  
  4. Indexes to Keep (Active Features)
    - profiles.referred_by (user system active)
    - categories.parent_id (category system active)
    - messages indexes (messaging active)
*/

-- Remove indexes for inactive features
-- These can be re-added when features are activated

-- Seller verifications (not active)
DROP INDEX IF EXISTS idx_seller_verifications_user_id;

-- Subscriptions (not active)
DROP INDEX IF EXISTS idx_subscriptions_user_id;

-- Reviews (not active)
DROP INDEX IF EXISTS idx_reviews_buyer_id;
DROP INDEX IF EXISTS idx_reviews_listing_id;
DROP INDEX IF EXISTS idx_reviews_seller_id;

-- Analytics (not active)
DROP INDEX IF EXISTS idx_analytics_events_listing_id;
DROP INDEX IF EXISTS idx_analytics_events_user_id;

-- Tier/Subscription categories (not active)
DROP INDEX IF EXISTS idx_tier_categories_category_id;
DROP INDEX IF EXISTS idx_user_subscriptions_tier_id;

-- Favorites (not active)
DROP INDEX IF EXISTS idx_favorites_listing_id;

-- Listing reviews (not active)
DROP INDEX IF EXISTS idx_listing_reviews_user_id;

-- Cart/Orders (not active)
DROP INDEX IF EXISTS idx_cart_items_listing_id;
DROP INDEX IF EXISTS idx_orders_buyer_id;
DROP INDEX IF EXISTS idx_orders_seller_id;
DROP INDEX IF EXISTS idx_order_items_order_id;
DROP INDEX IF EXISTS idx_order_items_listing_id;

-- Creative profiles (not active)
DROP INDEX IF EXISTS idx_creative_profiles_user_id;
DROP INDEX IF EXISTS idx_creative_verifications_creative_profile_id;
DROP INDEX IF EXISTS idx_creative_portfolio_items_creative_profile_id;
DROP INDEX IF EXISTS idx_creative_ratings_client_user_id;

-- Premium popups (not active)
DROP INDEX IF EXISTS idx_premium_popups_creative_profile_id;
DROP INDEX IF EXISTS idx_premium_popups_user_id;

-- Messages - keep conversation_ref_id but remove listing_id
-- conversation_ref_id might be used for legacy support
DROP INDEX IF EXISTS idx_messages_listing_id;

-- Note: Keeping these indexes as they're for active features:
-- - idx_profiles_referred_by (profiles are active)
-- - idx_categories_parent_id (categories are active)
-- - idx_messages_conversation_ref_id (messages are active)