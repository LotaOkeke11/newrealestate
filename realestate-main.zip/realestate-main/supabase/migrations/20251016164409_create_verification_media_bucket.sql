/*
  # Create Verification Media Storage Bucket

  1. New Storage Bucket
    - `verification-media`: Dedicated bucket for seller verification documents
      - Government ID photos
      - Selfie verification
      - Utility bills/bank statements
      - CAC certificates
      - Business logos
      - Office photos

  2. Security
    - Enable RLS on storage bucket
    - Only authenticated users can upload their own documents
    - Only the user who uploaded can view their documents
    - Admin can view all documents (for verification purposes)
    - File size limit: 10MB per file
    - Allowed types: images and PDFs only

  3. Storage Organization
    - Files organized by user_id folders
    - Each document type has clear naming convention
    - Example: {user_id}/national-id-{timestamp}.jpg

  4. Important Notes
    - This is a PRIVATE bucket for security
    - Documents are highly sensitive personal information
    - Only owners and admins should access
*/

-- Create verification-media bucket (private, secure)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'verification-media',
  'verification-media',
  false,
  10485760,
  ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'application/pdf']
)
ON CONFLICT (id) DO UPDATE SET
  file_size_limit = 10485760,
  allowed_mime_types = ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'application/pdf'];

-- Storage policies for verification-media bucket

-- Users can upload their own verification documents
CREATE POLICY "Users can upload own verification media"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'verification-media' 
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Users can view their own verification documents
CREATE POLICY "Users can view own verification media"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'verification-media' 
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Users can update their own verification documents
CREATE POLICY "Users can update own verification media"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'verification-media' 
    AND auth.uid()::text = (storage.foldername(name))[1]
  )
  WITH CHECK (
    bucket_id = 'verification-media' 
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Users can delete their own verification documents
CREATE POLICY "Users can delete own verification media"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'verification-media' 
    AND auth.uid()::text = (storage.foldername(name))[1]
  );
