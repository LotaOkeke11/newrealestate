/*
  # Add Missing Upload Form Categories

  1. New Categories
    - electronics: For UploadElectronicsPage
    - fashion: For UploadFashionPage (already added in previous migration)

  2. Notes
    - These match the slugs expected by upload forms
    - Ensures all upload forms have corresponding categories
*/

INSERT INTO categories (name, slug, description, icon, is_active)
VALUES
  ('Electronics', 'electronics', 'Phones, laptops, tablets, and electronics', '📱', true)
ON CONFLICT (slug) DO NOTHING;
