/*
  # Fix Multiple Permissive Policies (Corrected)
  
  1. Issue
    - Multiple permissive SELECT policies on same table can create confusion
    - Best practice: Consolidate into single policy per action
  
  2. Tables Affected
    - listing_availability: "Anyone can view availability" + "Owners can manage availability"
    - premium_popups: "Anyone can view active popups" + "Users can manage their own popups"
  
  3. Solution
    - Drop existing policies
    - Create single consolidated policy per action
    - Use correct column names (listings.user_id, not seller_id)
*/

-- Fix listing_availability policies
DROP POLICY IF EXISTS "Anyone can view availability" ON listing_availability;
DROP POLICY IF EXISTS "Owners can manage availability" ON listing_availability;

-- Consolidated SELECT policy for listing_availability
-- Everyone can view availability for booking purposes
CREATE POLICY "listing_availability_select"
  ON listing_availability
  FOR SELECT
  TO authenticated
  USING (true);

-- Owner-only policies for modifications
CREATE POLICY "listing_availability_insert"
  ON listing_availability
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM listings
      WHERE listings.id = listing_availability.listing_id
      AND listings.user_id = auth.uid()
    )
  );

CREATE POLICY "listing_availability_update"
  ON listing_availability
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM listings
      WHERE listings.id = listing_availability.listing_id
      AND listings.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM listings
      WHERE listings.id = listing_availability.listing_id
      AND listings.user_id = auth.uid()
    )
  );

CREATE POLICY "listing_availability_delete"
  ON listing_availability
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM listings
      WHERE listings.id = listing_availability.listing_id
      AND listings.user_id = auth.uid()
    )
  );

-- Fix premium_popups policies
DROP POLICY IF EXISTS "Anyone can view active popups" ON premium_popups;
DROP POLICY IF EXISTS "Users can manage their own popups" ON premium_popups;

-- Consolidated SELECT policy for premium_popups
-- Public sees active popups OR their own popups (all statuses)
CREATE POLICY "premium_popups_select"
  ON premium_popups
  FOR SELECT
  TO authenticated
  USING (
    is_active = true 
    OR user_id = auth.uid() 
    OR creative_profile_id IN (
      SELECT id FROM creative_profiles 
      WHERE user_id = auth.uid()
    )
  );

-- Owner-only policies for modifications
CREATE POLICY "premium_popups_insert"
  ON premium_popups
  FOR INSERT
  TO authenticated
  WITH CHECK (
    user_id = auth.uid() 
    OR creative_profile_id IN (
      SELECT id FROM creative_profiles 
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "premium_popups_update"
  ON premium_popups
  FOR UPDATE
  TO authenticated
  USING (
    user_id = auth.uid() 
    OR creative_profile_id IN (
      SELECT id FROM creative_profiles 
      WHERE user_id = auth.uid()
    )
  )
  WITH CHECK (
    user_id = auth.uid() 
    OR creative_profile_id IN (
      SELECT id FROM creative_profiles 
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "premium_popups_delete"
  ON premium_popups
  FOR DELETE
  TO authenticated
  USING (
    user_id = auth.uid() 
    OR creative_profile_id IN (
      SELECT id FROM creative_profiles 
      WHERE user_id = auth.uid()
    )
  );