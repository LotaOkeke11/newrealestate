/*
  # Remove Unused Indexes
  
  1. Performance Improvements
    - Remove indexes that are not being used by queries
    - Improves INSERT/UPDATE/DELETE performance
    - Reduces database storage requirements
  
  2. Strategy
    - Keep foreign key indexes (even if unused now, they're important for JOINs)
    - Remove only those that truly provide no value
    - Can be recreated later if query patterns change
  
  3. Indexes to Remove
    - Truly unused indexes that don't cover foreign keys or critical queries
*/

-- These indexes were just created but are showing as unused
-- Keep them as they're important for foreign key performance
-- (They'll be used once queries start hitting these tables)

-- Remove only non-critical, truly unused indexes

-- Profiles - referral system not heavily used yet
DROP INDEX IF EXISTS idx_profiles_referred_by;

-- Categories - hierarchy not heavily queried yet  
DROP INDEX IF EXISTS idx_categories_parent_id;

-- Seller verifications - keep for now, will be used when verification feature is active
-- DROP INDEX IF EXISTS idx_seller_verifications_user_id;

-- Subscriptions - keep for now, will be used when subscription features are active
-- DROP INDEX IF EXISTS idx_subscriptions_user_id;

-- Messages conversation created - redundant with other message indexes
DROP INDEX IF EXISTS idx_messages_conversation_created;

-- Messages listing_id - keep, important for listing-related messages
-- DROP INDEX IF EXISTS idx_messages_listing_id;

-- Reviews - keep all, will be heavily used once review system is active
-- DROP INDEX IF EXISTS idx_reviews_buyer_id;
-- DROP INDEX IF EXISTS idx_reviews_listing_id;
-- DROP INDEX IF EXISTS idx_reviews_seller_id;

-- Analytics events user_id - keep for user analytics queries
-- DROP INDEX IF EXISTS idx_analytics_events_user_id;

-- Tier categories - keep for subscription tier queries
-- DROP INDEX IF EXISTS idx_tier_categories_category_id;

-- User subscriptions - keep for user subscription lookups
-- DROP INDEX IF EXISTS idx_user_subscriptions_tier_id;

-- Order items listing - keep for order-listing joins
-- DROP INDEX IF EXISTS idx_order_items_listing_id;

-- Creative ratings - keep for rating lookups
-- DROP INDEX IF EXISTS idx_creative_ratings_client_user_id;

-- Premium popups - keep for popup queries
-- DROP INDEX IF EXISTS idx_premium_popups_creative_profile_id;
-- DROP INDEX IF EXISTS idx_premium_popups_user_id;