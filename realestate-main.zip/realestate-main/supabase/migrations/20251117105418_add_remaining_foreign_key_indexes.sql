/*
  # Add Remaining Foreign Key Indexes
  
  1. Performance Improvements
    - Add indexes on all remaining foreign key columns
    - Improves JOIN performance and foreign key constraint checking
  
  2. Tables Affected
    - analytics_events (listing_id)
    - cart_items (listing_id)
    - creative_portfolio_items (creative_profile_id)
    - creative_profiles (user_id)
    - creative_verifications (creative_profile_id)
    - favorites (listing_id)
    - listing_reviews (user_id)
    - messages (conversation_ref_id, recipient_id)
    - order_items (order_id)
    - orders (buyer_id, seller_id)
*/

-- Analytics events
CREATE INDEX IF NOT EXISTS idx_analytics_events_listing_id 
ON analytics_events(listing_id);

-- Cart items
CREATE INDEX IF NOT EXISTS idx_cart_items_listing_id 
ON cart_items(listing_id);

-- Creative portfolio items
CREATE INDEX IF NOT EXISTS idx_creative_portfolio_items_creative_profile_id 
ON creative_portfolio_items(creative_profile_id);

-- Creative profiles
CREATE INDEX IF NOT EXISTS idx_creative_profiles_user_id 
ON creative_profiles(user_id);

-- Creative verifications
CREATE INDEX IF NOT EXISTS idx_creative_verifications_creative_profile_id 
ON creative_verifications(creative_profile_id);

-- Favorites
CREATE INDEX IF NOT EXISTS idx_favorites_listing_id 
ON favorites(listing_id);

-- Listing reviews
CREATE INDEX IF NOT EXISTS idx_listing_reviews_user_id 
ON listing_reviews(user_id);

-- Messages
CREATE INDEX IF NOT EXISTS idx_messages_conversation_ref_id 
ON messages(conversation_ref_id);

CREATE INDEX IF NOT EXISTS idx_messages_recipient_id 
ON messages(recipient_id);

-- Order items
CREATE INDEX IF NOT EXISTS idx_order_items_order_id 
ON order_items(order_id);

-- Orders
CREATE INDEX IF NOT EXISTS idx_orders_buyer_id 
ON orders(buyer_id);

CREATE INDEX IF NOT EXISTS idx_orders_seller_id 
ON orders(seller_id);