/*
  # Remove Condition Check Constraint

  1. Changes
    - Drop the condition check constraint from listings table
    - Allow any text value for condition field

  2. Reason
    - Forms submit various condition formats (e.g., "Excellent", "Brand New", "Brand New with Tags")
    - Database constraint was too restrictive
    - This allows flexibility for different product types
*/

DO $$
BEGIN
  -- Drop the condition check constraint if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.constraint_column_usage
    WHERE constraint_name = 'listings_condition_check'
  ) THEN
    ALTER TABLE listings DROP CONSTRAINT listings_condition_check;
  END IF;
END $$;
