export const getListingDetailUrl = (listingId: string, categorySlug?: string): string => {
  if (!categorySlug) {
    return `/listing/${listingId}`;
  }

  const realEstateCategories = ['real-estate', 'properties', 'houses', 'apartments'];
  const electronicsCategories = ['electronics', 'phones', 'computers', 'gadgets', 'laptops'];

  if (realEstateCategories.some(cat => categorySlug.includes(cat))) {
    return `/property/${listingId}`;
  }

  if (electronicsCategories.some(cat => categorySlug.includes(cat))) {
    return `/electronics/${listingId}`;
  }

  return `/listing/${listingId}`;
};
