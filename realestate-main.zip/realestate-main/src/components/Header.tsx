import { useState, useEffect } from 'react';
import { Search, Menu, Heart, MessageCircle, User, LogOut, LayoutDashboard, ShoppingCart, PlusCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { AdvancedSearchBar } from './AdvancedSearchBar';
import { supabase } from '../lib/supabase';

type HeaderProps = {
  onMenuClick?: () => void;
};

export const Header = ({ onMenuClick }: HeaderProps) => {
  const { user, profile, signOut } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    if (user) {
      loadCartCount();

      const channel = supabase
        .channel('cart-changes')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'cart_items',
            filter: `user_id=eq.${user.id}`
          },
          () => {
            loadCartCount();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    } else {
      setCartCount(0);
    }
  }, [user]);

  const loadCartCount = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('cart_items')
      .select('quantity')
      .eq('user_id', user.id);

    if (data) {
      const totalCount = data.reduce((sum, item) => sum + item.quantity, 0);
      setCartCount(totalCount);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    setShowUserMenu(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-amber-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <button
              onClick={onMenuClick}
              className="p-2 rounded-xl hover:bg-amber-50 transition-all group relative"
            >
              <div className="flex flex-col gap-1.5 w-6">
                <span className="block h-0.5 w-6 bg-gradient-to-r from-amber-500 to-amber-600 rounded-full transition-all group-hover:w-5"></span>
                <span className="block h-0.5 w-5 bg-gradient-to-r from-amber-500 to-amber-600 rounded-full transition-all group-hover:w-6"></span>
                <span className="block h-0.5 w-6 bg-gradient-to-r from-amber-500 to-amber-600 rounded-full transition-all group-hover:w-4"></span>
              </div>
            </button>

            <a href="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">RS</span>
              </div>
              <span className="hidden sm:block text-xl font-bold bg-gradient-to-r from-amber-600 to-amber-800 bg-clip-text text-transparent">
                RentSaleStay
              </span>
            </a>
          </div>

          <div className="flex-1 max-w-2xl mx-4 hidden md:block">
            <AdvancedSearchBar />
          </div>

          <div className="flex items-center space-x-2 sm:space-x-4">
            {user && (
              <a
                href="/post-ad"
                className="hidden sm:flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-bold hover:from-amber-600 hover:to-amber-700 transition-all shadow-md"
              >
                <PlusCircle className="w-5 h-5" />
                <span>Post Ad</span>
              </a>
            )}

            <a href="/cart" className="p-2 rounded-full hover:bg-amber-50 transition-colors relative">
              <ShoppingCart className="w-6 h-6 text-amber-600" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-5 h-5 px-1 bg-amber-600 text-white text-xs rounded-full flex items-center justify-center font-bold">
                  {cartCount > 99 ? '99+' : cartCount}
                </span>
              )}
            </a>

            <a href="/chat" className="p-2 rounded-full hover:bg-amber-50 transition-colors relative" title="Messages">
              <MessageCircle className="w-6 h-6 text-amber-600" />
              <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
            </a>

            {user ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-2 p-2 rounded-full hover:bg-amber-50 transition-colors"
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-semibold">
                      {profile?.full_name?.charAt(0).toUpperCase()}
                    </span>
                  </div>
                </button>

                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-amber-100 py-2">
                    <div className="px-4 py-2 border-b border-amber-100">
                      <p className="font-semibold text-gray-900">{profile?.full_name}</p>
                      <p className="text-xs text-gray-500 capitalize">{profile?.account_type}</p>
                    </div>

                    {(profile?.account_type === 'seller' || profile?.account_type === 'business') && (
                      <a
                        href="/dashboard"
                        className="flex items-center space-x-2 px-4 py-2 hover:bg-amber-50 transition-colors"
                      >
                        <LayoutDashboard className="w-4 h-4 text-amber-600" />
                        <span className="text-sm">Dashboard</span>
                      </a>
                    )}

                    <a
                      href="/profile"
                      className="flex items-center space-x-2 px-4 py-2 hover:bg-amber-50 transition-colors"
                    >
                      <User className="w-4 h-4 text-amber-600" />
                      <span className="text-sm">My Profile</span>
                    </a>

                    <button
                      onClick={handleSignOut}
                      className="w-full flex items-center space-x-2 px-4 py-2 hover:bg-amber-50 transition-colors text-left"
                    >
                      <LogOut className="w-4 h-4 text-amber-600" />
                      <span className="text-sm">Sign Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <a
                href="/login"
                className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-full hover:from-amber-600 hover:to-amber-700 transition-all font-semibold text-sm"
              >
                Sign In
              </a>
            )}
          </div>
        </div>

        <div className="md:hidden pb-3">
          <AdvancedSearchBar />
        </div>
      </div>
    </header>
  );
};
