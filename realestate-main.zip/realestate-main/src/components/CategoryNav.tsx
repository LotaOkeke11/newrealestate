import { useEffect, useState } from 'react';
import * as Icons from 'lucide-react';
import { supabase, Category } from '../lib/supabase';

export const CategoryNav = () => {
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    const { data } = await supabase
      .from('categories')
      .select('*')
      .is('parent_id', null)
      .eq('is_active', true)
      .order('order_index');

    if (data) {
      setCategories(data);
    }
  };

  const getIcon = (iconName: string | null) => {
    if (!iconName) return Icons.Package;
    const Icon = (Icons as any)[iconName];
    return Icon || Icons.Package;
  };

  return (
    <nav className="bg-gradient-to-r from-amber-50 to-white border-b border-amber-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center space-x-6 overflow-x-auto py-4 scrollbar-hide">
          {categories.map((category) => {
            const Icon = getIcon(category.icon);
            const href = category.slug === 'rent' ? '/rentals' : `/category/${category.slug}`;
            return (
              <a
                key={category.id}
                href={href}
                className="flex flex-col items-center min-w-fit group"
              >
                <div className="w-12 h-12 rounded-full bg-white border-2 border-amber-200 flex items-center justify-center group-hover:border-amber-400 group-hover:bg-amber-50 transition-all shadow-sm">
                  <Icon className="w-6 h-6 text-amber-600" />
                </div>
                <span className="text-xs mt-2 text-gray-700 group-hover:text-amber-700 font-medium text-center">
                  {category.name}
                </span>
              </a>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
