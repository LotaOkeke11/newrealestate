import { useState, useEffect, useRef } from 'react';
import { Search, X, TrendingUp, Clock, MapPin, Tag, SlidersHorizontal } from 'lucide-react';
import { supabase } from '../lib/supabase';

type SearchSuggestion = {
  id: string;
  title: string;
  price: number;
  category: string;
  location_city: string;
  location_state: string;
  images: string[];
};

type RecentSearch = {
  query: string;
  timestamp: number;
};

type AdvancedSearchBarProps = {
  onSearch?: (query: string) => void;
  showFilters?: boolean;
};

export const AdvancedSearchBar = ({ onSearch, showFilters = false }: AdvancedSearchBarProps) => {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([]);
  const [recentSearches, setRecentSearches] = useState<RecentSearch[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadRecentSearches();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (query.length >= 2) {
      const debounce = setTimeout(() => {
        fetchSuggestions(query);
      }, 300);

      return () => clearTimeout(debounce);
    } else {
      setSuggestions([]);
    }
  }, [query]);

  const loadRecentSearches = () => {
    const saved = localStorage.getItem('recentSearches');
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  };

  const saveRecentSearch = (searchQuery: string) => {
    const searches = recentSearches.filter((s) => s.query !== searchQuery);
    const updated = [{ query: searchQuery, timestamp: Date.now() }, ...searches].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('recentSearches', JSON.stringify(updated));
  };

  const clearRecentSearch = (searchQuery: string) => {
    const updated = recentSearches.filter((s) => s.query !== searchQuery);
    setRecentSearches(updated);
    localStorage.setItem('recentSearches', JSON.stringify(updated));
  };

  const fetchSuggestions = async (searchQuery: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('listings')
        .select(`
          id,
          title,
          price,
          images,
          location_city,
          location_state,
          category:categories(name)
        `)
        .or(`title.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%`)
        .eq('status', 'active')
        .limit(8);

      if (data) {
        setSuggestions(
          data.map((item: any) => ({
            ...item,
            category: item.category?.name || 'Uncategorized',
          }))
        );
      }
    } catch (err) {
      console.error('Search error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (searchQuery: string = query) => {
    if (searchQuery.trim()) {
      saveRecentSearch(searchQuery.trim());
      setShowSuggestions(false);
      if (onSearch) {
        onSearch(searchQuery.trim());
      } else {
        window.location.href = `/search?q=${encodeURIComponent(searchQuery.trim())}`;
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < suggestions.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : -1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (selectedIndex >= 0 && suggestions[selectedIndex]) {
        window.location.href = `/listing/${suggestions[selectedIndex].id}`;
      } else {
        handleSearch();
      }
    } else if (e.key === 'Escape') {
      setShowSuggestions(false);
    }
  };

  const highlightMatch = (text: string, searchTerm: string) => {
    if (!searchTerm) return text;

    const parts = text.split(new RegExp(`(${searchTerm})`, 'gi'));
    return parts.map((part, index) =>
      part.toLowerCase() === searchTerm.toLowerCase() ? (
        <span key={index} className="bg-amber-200 font-semibold">
          {part}
        </span>
      ) : (
        part
      )
    );
  };

  return (
    <div ref={searchRef} className="relative w-full max-w-3xl">
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setShowSuggestions(true)}
          onKeyDown={handleKeyDown}
          placeholder="Search for products, services, real estate, vehicles..."
          className="w-full px-4 py-3 pl-12 pr-24 border-2 border-amber-200 rounded-2xl focus:outline-none focus:border-amber-400 transition-colors shadow-sm text-base"
        />
        <Search className="absolute left-4 top-3.5 w-5 h-5 text-amber-600" />

        <div className="absolute right-2 top-2 flex items-center gap-2">
          {query && (
            <button
              onClick={() => {
                setQuery('');
                setSuggestions([]);
                inputRef.current?.focus();
              }}
              className="p-1.5 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          )}
          {showFilters && (
            <button className="p-2 hover:bg-amber-50 rounded-lg transition-colors">
              <SlidersHorizontal className="w-5 h-5 text-amber-600" />
            </button>
          )}
          <button
            onClick={() => handleSearch()}
            className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-semibold hover:from-amber-600 hover:to-amber-700 transition-all"
          >
            Search
          </button>
        </div>
      </div>

      {showSuggestions && (query.length >= 2 || recentSearches.length > 0) && (
        <div className="absolute top-full mt-2 w-full bg-white rounded-2xl shadow-2xl border-2 border-amber-100 overflow-hidden z-50 max-h-[70vh] overflow-y-auto">
          {recentSearches.length > 0 && query.length < 2 && (
            <div className="p-4 border-b border-gray-100">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Recent Searches
                </h3>
                <button
                  onClick={() => {
                    setRecentSearches([]);
                    localStorage.removeItem('recentSearches');
                  }}
                  className="text-xs text-amber-600 hover:text-amber-700 font-semibold"
                >
                  Clear All
                </button>
              </div>
              <div className="space-y-1">
                {recentSearches.map((search, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between group hover:bg-amber-50 rounded-lg px-3 py-2 cursor-pointer"
                    onClick={() => {
                      setQuery(search.query);
                      handleSearch(search.query);
                    }}
                  >
                    <div className="flex items-center gap-2 flex-1">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-700">{search.query}</span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        clearRecentSearch(search.query);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-200 rounded transition-opacity"
                    >
                      <X className="w-3 h-3 text-gray-500" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {loading && (
            <div className="p-8 text-center">
              <div className="animate-spin w-8 h-8 border-3 border-amber-600 border-t-transparent rounded-full mx-auto"></div>
              <p className="text-sm text-gray-500 mt-2">Searching...</p>
            </div>
          )}

          {!loading && suggestions.length > 0 && (
            <div className="p-2">
              <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide px-3 py-2 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Suggested Products
              </h3>
              <div className="space-y-1">
                {suggestions.map((suggestion, index) => (
                  <a
                    key={suggestion.id}
                    href={`/listing/${suggestion.id}`}
                    className={`flex items-center gap-3 p-3 rounded-xl hover:bg-amber-50 transition-colors ${
                      selectedIndex === index ? 'bg-amber-50' : ''
                    }`}
                  >
                    <div className="w-14 h-14 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                      {suggestion.images && suggestion.images.length > 0 ? (
                        <img
                          src={suggestion.images[0]}
                          alt={suggestion.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Search className="w-6 h-6 text-gray-400" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-900 truncate text-sm">
                        {highlightMatch(suggestion.title, query)}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-100 text-amber-700 rounded text-xs font-medium">
                          <Tag className="w-3 h-3" />
                          {suggestion.category}
                        </span>
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {suggestion.location_city}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="text-sm font-bold text-amber-600">
                        ₦{suggestion.price.toLocaleString()}
                      </p>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          )}

          {!loading && query.length >= 2 && suggestions.length === 0 && (
            <div className="p-8 text-center">
              <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600 font-semibold mb-1">No results found</p>
              <p className="text-sm text-gray-500">Try different keywords or browse categories</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
