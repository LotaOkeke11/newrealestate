import { Facebook, Twitter, Instagram, Linkedin, Youtube, Mail, Phone, MapPin, Send } from 'lucide-react';

export const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-xl">RS</span>
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
                RentSaleStay
              </span>
            </div>
            <p className="text-gray-300 mb-6 max-w-md">
              Your trusted marketplace for buying, selling, and renting everything from real estate to creative equipment. Connect with sellers and buyers across Nigeria.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-300">
                <MapPin className="w-5 h-5 text-amber-500" />
                <span>Lagos, Nigeria</span>
              </div>
              <div className="flex items-center gap-3 text-gray-300">
                <Mail className="w-5 h-5 text-amber-500" />
                <a href="mailto:support@example.com" className="hover:text-amber-400 transition-colors">
                  support@example.com
                </a>
              </div>
              <div className="flex items-center gap-3 text-gray-300">
                <Phone className="w-5 h-5 text-amber-500" />
                <a href="tel:+2341234567890" className="hover:text-amber-400 transition-colors">
                  +234 123 456 7890
                </a>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4 text-white">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="/" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="/categories" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Browse Categories
                </a>
              </li>
              <li>
                <a href="/rentals" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Rentals
                </a>
              </li>
              <li>
                <a href="/jobs-services" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Jobs & Services
                </a>
              </li>
              <li>
                <a href="/post-ad" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Post an Ad
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4 text-white">Support</h3>
            <ul className="space-y-2">
              <li>
                <a href="/help" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Help Center
                </a>
              </li>
              <li>
                <a href="/about" className="text-gray-300 hover:text-amber-400 transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="/contact" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="/faq" className="text-gray-300 hover:text-amber-400 transition-colors">
                  FAQ
                </a>
              </li>
              <li>
                <a href="/safety-tips" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Safety Tips
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4 text-white">Legal</h3>
            <ul className="space-y-2">
              <li>
                <a href="/privacy-policy" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="/terms-of-service" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="/cookie-policy" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Cookie Policy
                </a>
              </li>
              <li>
                <a href="/seller-agreement" className="text-gray-300 hover:text-amber-400 transition-colors">
                  Seller Agreement
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-gray-400 text-sm">
              © {currentYear} RentSaleStay. All rights reserved.
            </div>

            <div className="flex items-center gap-4">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 hover:bg-amber-600 rounded-full flex items-center justify-center transition-all"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 hover:bg-amber-600 rounded-full flex items-center justify-center transition-all"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 hover:bg-amber-600 rounded-full flex items-center justify-center transition-all"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 hover:bg-amber-600 rounded-full flex items-center justify-center transition-all"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 hover:bg-amber-600 rounded-full flex items-center justify-center transition-all"
              >
                <Youtube className="w-5 h-5" />
              </a>
            </div>

            <div className="text-gray-400 text-sm">
              Made with ❤️ in Nigeria
            </div>
          </div>
        </div>

        <div className="mt-8 p-6 bg-gradient-to-r from-amber-600 to-orange-600 rounded-2xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold mb-1">Stay Updated!</h3>
              <p className="text-amber-100 text-sm">Subscribe to get the latest deals and updates</p>
            </div>
            <div className="flex gap-2 w-full md:w-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 md:w-64 px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-white text-gray-900"
              />
              <button className="px-6 py-3 bg-white text-amber-600 rounded-xl font-bold hover:bg-gray-100 transition-all flex items-center gap-2">
                <Send className="w-5 h-5" />
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
