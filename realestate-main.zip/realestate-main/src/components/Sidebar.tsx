import { X, Home, LayoutDashboard, Package, CreditCard, Settings, HelpCircle, Star, ShieldCheck, PlusCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

type SidebarProps = {
  isOpen: boolean;
  onClose: () => void;
};

export const Sidebar = ({ isOpen, onClose }: SidebarProps) => {
  const { user, profile } = useAuth();

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity"
        onClick={onClose}
      />

      <div className="fixed top-0 left-0 h-full w-80 bg-white shadow-2xl z-50 transform transition-transform duration-300">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">Menu</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="overflow-y-auto h-[calc(100vh-80px)]">
          {user && profile && (
            <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-amber-50 to-orange-50">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-lg font-bold">
                    {profile.full_name?.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{profile.full_name}</p>
                  <p className="text-xs text-gray-600 capitalize">{profile.account_type}</p>
                </div>
              </div>
            </div>
          )}

          <nav className="p-4 space-y-2">
            <a
              href="/"
              onClick={onClose}
              className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-amber-50 transition-colors group"
            >
              <Home className="w-5 h-5 text-gray-600 group-hover:text-amber-600" />
              <span className="font-medium text-gray-700 group-hover:text-amber-700">Home</span>
            </a>

            {user && (profile?.account_type === 'seller' || profile?.account_type === 'business') && (
              <>
                <a
                  href="/post-ad"
                  onClick={onClose}
                  className="flex items-center gap-3 px-4 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg mb-2"
                >
                  <PlusCircle className="w-5 h-5" />
                  <span className="font-bold">Post New Ad</span>
                </a>

                <a
                  href="/dashboard"
                  onClick={onClose}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-amber-50 transition-colors group"
                >
                  <LayoutDashboard className="w-5 h-5 text-gray-600 group-hover:text-amber-600" />
                  <span className="font-medium text-gray-700 group-hover:text-amber-700">Dashboard</span>
                </a>

                <a
                  href="/list-property"
                  onClick={onClose}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-amber-50 transition-colors group"
                >
                  <Package className="w-5 h-5 text-gray-600 group-hover:text-amber-600" />
                  <span className="font-medium text-gray-700 group-hover:text-amber-700">My Listings</span>
                </a>

                <a
                  href="/subscription"
                  onClick={onClose}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-amber-50 transition-colors group"
                >
                  <CreditCard className="w-5 h-5 text-gray-600 group-hover:text-amber-600" />
                  <span className="font-medium text-gray-700 group-hover:text-amber-700">Subscription</span>
                </a>

                <a
                  href="/verification"
                  onClick={onClose}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-green-50 transition-colors group"
                >
                  <ShieldCheck className="w-5 h-5 text-green-600 group-hover:text-green-700" />
                  <span className="font-medium text-green-700 group-hover:text-green-800">Get Verified</span>
                </a>
              </>
            )}

            <div className="border-t border-gray-200 my-4"></div>

            <a
              href="/settings"
              onClick={onClose}
              className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-amber-50 transition-colors group"
            >
              <Settings className="w-5 h-5 text-gray-600 group-hover:text-amber-600" />
              <span className="font-medium text-gray-700 group-hover:text-amber-700">Settings</span>
            </a>

            <a
              href="/help"
              onClick={onClose}
              className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-amber-50 transition-colors group"
            >
              <HelpCircle className="w-5 h-5 text-gray-600 group-hover:text-amber-600" />
              <span className="font-medium text-gray-700 group-hover:text-amber-700">Help & Support</span>
            </a>

            {user && profile?.account_type !== 'seller' && profile?.account_type !== 'business' && (
              <>
                <div className="border-t border-gray-200 my-4"></div>
                <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Star className="w-5 h-5 text-amber-600 fill-current" />
                    <h3 className="font-bold text-gray-900">Become a Seller</h3>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">
                    Start selling and earn money on our platform
                  </p>
                  <a
                    href="/register"
                    onClick={onClose}
                    className="block text-center px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-lg font-semibold text-sm hover:from-amber-600 hover:to-amber-700 transition-all"
                  >
                    Get Started
                  </a>
                </div>
              </>
            )}
          </nav>
        </div>
      </div>
    </>
  );
};
