import { ShieldCheck, ShieldAlert } from 'lucide-react';

type VerificationBadgeProps = {
  level: number;
  status: 'approved' | 'pending' | 'rejected';
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
};

export const VerificationBadge = ({ level, status, size = 'md', showText = true }: VerificationBadgeProps) => {
  if (status !== 'approved' || level === 0) return null;

  const sizes = {
    sm: 'w-5 h-5',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
  };

  const textSizes = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
  };

  const badges = [
    {
      level: 1,
      name: 'ID Verified',
      color: 'from-blue-500 to-cyan-500',
      textColor: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-300',
    },
    {
      level: 2,
      name: 'Address Verified',
      color: 'from-green-500 to-emerald-500',
      textColor: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-300',
    },
    {
      level: 3,
      name: 'Business Verified',
      color: 'from-amber-500 to-orange-500',
      textColor: 'text-amber-600',
      bgColor: 'bg-amber-50',
      borderColor: 'border-amber-300',
    },
  ];

  const badge = badges[level - 1];

  if (!badge) return null;

  if (!showText) {
    return (
      <div
        className={`inline-flex items-center justify-center ${sizes[size]} bg-gradient-to-br ${badge.color} rounded-full`}
        title={badge.name}
      >
        <ShieldCheck className={`${size === 'sm' ? 'w-3 h-3' : size === 'md' ? 'w-4 h-4' : 'w-5 h-5'} text-white`} />
      </div>
    );
  }

  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 ${badge.bgColor} ${badge.borderColor} border rounded-full ${textSizes[size]}`}
    >
      <div className={`${sizes[size]} bg-gradient-to-br ${badge.color} rounded-full flex items-center justify-center`}>
        <ShieldCheck className={`${size === 'sm' ? 'w-3 h-3' : size === 'md' ? 'w-3.5 h-3.5' : 'w-4 h-4'} text-white`} />
      </div>
      <span className={`font-semibold ${badge.textColor}`}>{badge.name}</span>
    </div>
  );
};
