import { useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  Home, Upload, X, MapPin, Bed, Bath, Wifi, Car, Droplet, Wind, Tv,
  Coffee, Building, Shield, Video, CheckCircle2, AlertCircle, DollarSign,
  Calendar, ChevronRight, Image as ImageIcon
} from 'lucide-react';

export const UploadRealEstatePage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [listingType, setListingType] = useState<'sale' | 'rent' | 'shortlet'>('rent');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [videoFile, setVideoFile] = useState<File | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    propertyType: '',
    price: '',
    bedrooms: '',
    bathrooms: '',
    squareFeet: '',
    isFurnished: false,
    locationState: '',
    locationCity: '',
    locationArea: '',
    sellerType: 'owner',
    paymentFrequency: 'monthly',
    nightlyRate: '',
    weeklyRate: '',
    monthlyRate: '',
    houseRules: '',
    contactPhone: '',
    contactWhatsapp: '',
  });

  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);

  const amenitiesList = [
    { id: 'wifi', label: 'WiFi', icon: Wifi },
    { id: 'parking', label: 'Parking', icon: Car },
    { id: 'pool', label: 'Pool', icon: Droplet },
    { id: 'ac', label: 'AC', icon: Wind },
    { id: 'tv', label: 'TV', icon: Tv },
    { id: 'kitchen', label: 'Kitchen', icon: Coffee },
    { id: 'generator', label: 'Generator', icon: Building },
    { id: 'security', label: 'Security', icon: Shield },
  ];

  const propertyTypes = [
    'Apartment', 'House', 'Duplex', 'Penthouse', 'Studio',
    'Office Space', 'Shop', 'Warehouse', 'Land', 'Condo'
  ];

  const nigeriaStates = [
    'Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo', 'Kaduna', 'Anambra',
    'Enugu', 'Delta', 'Edo', 'Ogun', 'Ondo', 'Kwara', 'Imo'
  ];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + imageFiles.length > 15) {
      setError('Maximum 15 images allowed');
      return;
    }

    setImageFiles((prev) => [...prev, ...files]);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreviews((prev) => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleSubmit = async () => {
    setLoading(true);
    setError('');

    try {
      if (!user) throw new Error('Please sign in');
      if (imageFiles.length === 0) throw new Error('Add at least one image');

      const imageUrls: string[] = [];
      for (let i = 0; i < imageFiles.length; i++) {
        const file = imageFiles[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/property-${Date.now()}-${i}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from('listing-images')
          .upload(fileName, file);

        if (!uploadError) {
          const { data: urlData } = supabase.storage
            .from('listing-images')
            .getPublicUrl(fileName);
          imageUrls.push(urlData.publicUrl);
        }
      }

      let videoUrl = '';
      if (videoFile) {
        const fileExt = videoFile.name.split('.').pop();
        const fileName = `${user.id}/video-${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('listing-images')
          .upload(fileName, videoFile);

        if (!uploadError) {
          const { data: urlData } = supabase.storage
            .from('listing-images')
            .getPublicUrl(fileName);
          videoUrl = urlData.publicUrl;
        }
      }

      // Get the correct category based on listing type (rent/sale/shortlet)
      const categorySlug = listingType === 'sale' ? 'sale' : listingType === 'rent' ? 'rent' : 'shortlet';

      const { data: category } = await supabase
        .from('categories')
        .select('id, slug')
        .eq('slug', categorySlug)
        .maybeSingle();

      // Fallback to real-estate parent if subcategory not found
      let categoryId = category?.id;
      if (!categoryId) {
        const { data: parentCategory } = await supabase
          .from('categories')
          .select('id')
          .eq('slug', 'real-estate')
          .maybeSingle();
        categoryId = parentCategory?.id;
      }

      const listingData: any = {
        user_id: user.id,
        category_id: categoryId,
        title: formData.title,
        description: formData.description,
        price: listingType === 'shortlet' ? parseFloat(formData.nightlyRate) : parseFloat(formData.price),
        currency: 'NGN',
        images: imageUrls,
        video_url: videoUrl || null,
        property_type: formData.propertyType,
        bedrooms: parseInt(formData.bedrooms) || 0,
        bathrooms: parseInt(formData.bathrooms) || 0,
        square_feet: parseInt(formData.squareFeet) || 0,
        is_furnished: formData.isFurnished,
        amenities: selectedAmenities,
        location_state: formData.locationState,
        location_city: formData.locationCity,
        location_area: formData.locationArea,
        seller_type: formData.sellerType,
        contact_phone: formData.contactPhone,
        contact_whatsapp: formData.contactWhatsapp,
        condition: 'new',
        status: 'active',
        is_rental: listingType !== 'sale',
        rental_duration: listingType === 'shortlet' ? 'daily' : 'monthly',
      };

      if (listingType === 'rent') {
        listingData.payment_frequency = formData.paymentFrequency;
      } else if (listingType === 'shortlet') {
        listingData.nightly_rate = parseFloat(formData.nightlyRate);
        listingData.weekly_rate = parseFloat(formData.weeklyRate) || null;
        listingData.monthly_rate = parseFloat(formData.monthlyRate) || null;
        listingData.house_rules = formData.houseRules;
      }

      const { data: listing, error: listingError } = await supabase
        .from('listings')
        .insert(listingData)
        .select()
        .single();

      if (listingError) throw listingError;

      setSuccess(true);
      setTimeout(() => {
        window.location.href = category?.slug ? `/category/${category.slug}` : '/';
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    window.location.href = '/post-ad';
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="mb-6">
          <a href="/post-ad" className="text-blue-600 hover:text-blue-700 text-sm font-semibold mb-2 inline-block">
            ← Back to categories
          </a>
          <h1 className="text-4xl font-bold text-gray-900">List Your Property</h1>
          <p className="text-gray-600 mt-2">Fill in the details to create your listing</p>
        </div>

        <div className="flex items-center justify-between mb-8 bg-white rounded-2xl p-4 shadow-sm">
          <div className={`flex items-center gap-2 ${step >= 1 ? 'text-blue-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>1</div>
            <span className="font-semibold hidden sm:block">Type</span>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
          <div className={`flex items-center gap-2 ${step >= 2 ? 'text-blue-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>2</div>
            <span className="font-semibold hidden sm:block">Details</span>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
          <div className={`flex items-center gap-2 ${step >= 3 ? 'text-blue-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>3</div>
            <span className="font-semibold hidden sm:block">Photos</span>
          </div>
        </div>

        {success && (
          <div className="mb-6 p-4 bg-green-50 border-2 border-green-200 rounded-xl flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-green-800">Listed Successfully!</p>
              <p className="text-sm text-green-700">Redirecting...</p>
            </div>
          </div>
        )}

        {error && (
          <div className="mb-6 p-4 bg-red-50 border-2 border-red-200 rounded-xl flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
            <span className="text-sm text-red-700">{error}</span>
          </div>
        )}

        {step === 1 && (
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Choose Listing Type</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <button
                onClick={() => {
                  setListingType('sale');
                  setStep(2);
                }}
                className="p-6 border-2 border-gray-200 rounded-xl hover:border-blue-500 hover:bg-blue-50 transition-all text-center"
              >
                <Home className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                <h3 className="font-bold text-gray-900 mb-1">For Sale</h3>
                <p className="text-sm text-gray-600">Sell your property</p>
              </button>

              <button
                onClick={() => {
                  setListingType('rent');
                  setStep(2);
                }}
                className="p-6 border-2 border-gray-200 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all text-center"
              >
                <Building className="w-12 h-12 text-green-600 mx-auto mb-3" />
                <h3 className="font-bold text-gray-900 mb-1">For Rent</h3>
                <p className="text-sm text-gray-600">Long-term rental</p>
              </button>

              <button
                onClick={() => {
                  setListingType('shortlet');
                  setStep(2);
                }}
                className="p-6 border-2 border-gray-200 rounded-xl hover:border-purple-500 hover:bg-purple-50 transition-all text-center"
              >
                <Calendar className="w-12 h-12 text-purple-600 mx-auto mb-3" />
                <h3 className="font-bold text-gray-900 mb-1">Shortlet</h3>
                <p className="text-sm text-gray-600">Vacation rental</p>
              </button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Property Details</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Property Title *</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., Luxury 3 Bedroom Apartment in Lekki"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Description *</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe your property..."
                  rows={5}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Property Type *</label>
                  <select
                    value={formData.propertyType}
                    onChange={(e) => setFormData({ ...formData, propertyType: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  >
                    <option value="">Select Type</option>
                    {propertyTypes.map((type) => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    {listingType === 'shortlet' ? 'Nightly Rate (₦) *' : 'Price (₦) *'}
                  </label>
                  <input
                    type="number"
                    value={listingType === 'shortlet' ? formData.nightlyRate : formData.price}
                    onChange={(e) =>
                      listingType === 'shortlet'
                        ? setFormData({ ...formData, nightlyRate: e.target.value })
                        : setFormData({ ...formData, price: e.target.value })
                    }
                    placeholder="0"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              {listingType === 'shortlet' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Weekly Rate (₦)</label>
                    <input
                      type="number"
                      value={formData.weeklyRate}
                      onChange={(e) => setFormData({ ...formData, weeklyRate: e.target.value })}
                      placeholder="Optional discount"
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Monthly Rate (₦)</label>
                    <input
                      type="number"
                      value={formData.monthlyRate}
                      onChange={(e) => setFormData({ ...formData, monthlyRate: e.target.value })}
                      placeholder="Optional discount"
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    <Bed className="w-4 h-4 inline mr-1" />Bedrooms
                  </label>
                  <input
                    type="number"
                    value={formData.bedrooms}
                    onChange={(e) => setFormData({ ...formData, bedrooms: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    <Bath className="w-4 h-4 inline mr-1" />Bathrooms
                  </label>
                  <input
                    type="number"
                    value={formData.bathrooms}
                    onChange={(e) => setFormData({ ...formData, bathrooms: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Sq. Feet</label>
                  <input
                    type="number"
                    value={formData.squareFeet}
                    onChange={(e) => setFormData({ ...formData, squareFeet: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Furnished?</label>
                  <label className="flex items-center justify-center h-[52px] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.isFurnished}
                      onChange={(e) => setFormData({ ...formData, isFurnished: e.target.checked })}
                      className="w-5 h-5 text-blue-600"
                    />
                    <span className="ml-2">Yes</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-3">Amenities</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {amenitiesList.map((amenity) => {
                    const Icon = amenity.icon;
                    const isSelected = selectedAmenities.includes(amenity.id);
                    return (
                      <button
                        key={amenity.id}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedAmenities(selectedAmenities.filter((a) => a !== amenity.id));
                          } else {
                            setSelectedAmenities([...selectedAmenities, amenity.id]);
                          }
                        }}
                        className={`p-3 border-2 rounded-xl transition-all ${
                          isSelected ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                        }`}
                      >
                        <Icon className="w-6 h-6 mx-auto mb-1 text-blue-600" />
                        <p className="text-xs font-bold text-gray-900">{amenity.label}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">State *</label>
                  <select
                    value={formData.locationState}
                    onChange={(e) => setFormData({ ...formData, locationState: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  >
                    <option value="">Select State</option>
                    {nigeriaStates.map((state) => (
                      <option key={state} value={state}>{state}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">City *</label>
                  <input
                    type="text"
                    value={formData.locationCity}
                    onChange={(e) => setFormData({ ...formData, locationCity: e.target.value })}
                    placeholder="e.g., Ikeja"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Area</label>
                  <input
                    type="text"
                    value={formData.locationArea}
                    onChange={(e) => setFormData({ ...formData, locationArea: e.target.value })}
                    placeholder="e.g., GRA"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              {listingType === 'shortlet' && (
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">House Rules</label>
                  <textarea
                    value={formData.houseRules}
                    onChange={(e) => setFormData({ ...formData, houseRules: e.target.value })}
                    placeholder="No smoking, No pets, Check-in after 2 PM..."
                    rows={3}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Phone *</label>
                  <input
                    type="tel"
                    value={formData.contactPhone}
                    onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                    placeholder="+234 XXX XXX XXXX"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">WhatsApp</label>
                  <input
                    type="tel"
                    value={formData.contactWhatsapp}
                    onChange={(e) => setFormData({ ...formData, contactWhatsapp: e.target.value })}
                    placeholder="+234 XXX XXX XXXX"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <button
                onClick={() => setStep(3)}
                disabled={!formData.title || !formData.description}
                className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all disabled:opacity-50"
              >
                Continue to Photos →
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Upload Photos & Video</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-3">
                  Property Images & Videos *
                </label>
                <input
                  type="file"
                  multiple
                  accept="image/*,video/*"
                  onChange={handleImageChange}
                  className="hidden"
                  id="media-upload"
                />
                <label
                  htmlFor="media-upload"
                  className="block border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-blue-400 transition-colors cursor-pointer"
                >
                  <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-1 font-semibold">Click to upload or drag and drop</p>
                  <p className="text-gray-500 text-sm">PNG, JPG up to 10MB each</p>
                </label>

                {imagePreviews.length > 0 && (
                  <div className="grid grid-cols-3 md:grid-cols-5 gap-4 mt-6">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative aspect-square rounded-xl overflow-hidden border-2 border-gray-200">
                        <img src={preview} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                        <button
                          onClick={() => {
                            setImageFiles((prev) => prev.filter((_, i) => i !== index));
                            setImagePreviews((prev) => prev.filter((_, i) => i !== index));
                          }}
                          className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex gap-4">
                <button
                  onClick={() => setStep(2)}
                  className="flex-1 py-4 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                >
                  ← Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={loading || imageFiles.length === 0}
                  className="flex-1 py-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl font-bold hover:from-blue-700 hover:to-cyan-700 transition-all disabled:opacity-50"
                >
                  {loading ? 'Publishing...' : 'Publish Listing'}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};
