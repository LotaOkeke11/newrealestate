import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  Wrench, MapPin, Calendar, Package, Heart, Share2, Shield, Phone, MessageCircle,
  ChevronLeft, ChevronRight, Check, X, Car
} from 'lucide-react';

type PartListing = {
  id: string;
  title: string;
  description: string;
  price: number;
  images: string[];
  item_type: string;
  brand: string;
  condition: string;
  specifications: any;
  warranty_status: string;
  price_negotiable: boolean;
  location_state: string;
  location_city: string;
  contact_phone: string;
  contact_whatsapp: string;
  created_at: string;
  user_id: string;
  profiles: {
    full_name: string;
    verification_level: number;
  };
};

export const CarPartsDetailPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [listing, setListing] = useState<PartListing | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showPhone, setShowPhone] = useState(false);

  useEffect(() => {
    loadListing();
  }, []);

  const loadListing = async () => {
    const id = window.location.pathname.split('/car-part/')[1];
    const { data, error } = await supabase
      .from('listings')
      .select(`
        *,
        profiles:user_id (
          full_name,
          verification_level
        )
      `)
      .eq('id', id)
      .maybeSingle();

    if (data) setListing(data);
    setLoading(false);
  };

  const nextImage = () => {
    if (listing) {
      setCurrentImageIndex((prev) => (prev + 1) % listing.images.length);
    }
  };

  const prevImage = () => {
    if (listing) {
      setCurrentImageIndex((prev) => (prev - 1 + listing.images.length) % listing.images.length);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin w-16 h-16 border-4 border-gray-700 border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center"><p className="text-2xl font-bold text-gray-900">Car part not found</p></div>
        </div>
      </div>
    );
  }

  const specs = listing.specifications || {};
  const compatibleMakes = specs.compatible_makes || [];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <a href="/" className="inline-flex items-center text-gray-700 hover:text-gray-900 font-semibold mb-4">
            ← Back to listings
          </a>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-xl shadow-md overflow-hidden">
                <div className="relative aspect-video bg-gray-900">
                  {listing.images && listing.images.length > 0 && (
                    <>
                      <img
                        src={listing.images[currentImageIndex]}
                        alt={listing.title}
                        className="w-full h-full object-contain"
                      />
                      {listing.images.length > 1 && (
                        <>
                          <button
                            onClick={prevImage}
                            className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center backdrop-blur-sm"
                          >
                            <ChevronLeft className="w-6 h-6" />
                          </button>
                          <button
                            onClick={nextImage}
                            className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center backdrop-blur-sm"
                          >
                            <ChevronRight className="w-6 h-6" />
                          </button>
                          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                            {listing.images.map((_, idx) => (
                              <button
                                key={idx}
                                onClick={() => setCurrentImageIndex(idx)}
                                className={`w-2 h-2 rounded-full transition-all ${
                                  idx === currentImageIndex ? 'bg-white w-8' : 'bg-white/50'
                                }`}
                              />
                            ))}
                          </div>
                        </>
                      )}
                    </>
                  )}
                </div>

                <div className="grid grid-cols-6 gap-2 p-4 bg-gray-100">
                  {listing.images?.slice(0, 6).map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentImageIndex(idx)}
                      className={`aspect-video rounded-lg overflow-hidden border-2 ${
                        idx === currentImageIndex ? 'border-gray-700' : 'border-transparent'
                      }`}
                    >
                      <img src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-gray-900 mb-3">{listing.title}</h1>
                    <div className="flex items-center gap-4 text-gray-600 mb-3">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {listing.location_city}, {listing.location_state}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {new Date(listing.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        const reviewsSection = document.querySelector('[data-reviews-section]');
                        reviewsSection?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="inline-flex items-center gap-2 px-4 py-2 bg-amber-50 border-2 border-amber-200 rounded-xl hover:bg-amber-100 transition-colors"
                    >
                      <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                      <span className="font-bold text-gray-900">View Reviews</span>
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <button className="p-3 border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Heart className="w-5 h-5" />
                    </button>
                    <button className="p-3 border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h2 className="text-xl font-bold text-gray-900 mb-4">Part Details</h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {listing.item_type && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Category</div>
                        <div className="font-bold text-gray-900">{listing.item_type}</div>
                      </div>
                    )}
                    {listing.brand && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Brand</div>
                        <div className="font-bold text-gray-900">{listing.brand}</div>
                      </div>
                    )}
                    {listing.condition && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Condition</div>
                        <div className="font-bold text-gray-900">{listing.condition}</div>
                      </div>
                    )}
                    {specs.part_number && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Part Number</div>
                        <div className="font-bold text-gray-900">{specs.part_number}</div>
                      </div>
                    )}
                    {listing.warranty_status && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Warranty</div>
                        <div className="font-bold text-gray-900">{listing.warranty_status}</div>
                      </div>
                    )}
                    {specs.year_range && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Year Range</div>
                        <div className="font-bold text-gray-900">{specs.year_range}</div>
                      </div>
                    )}
                  </div>
                </div>

                {compatibleMakes && compatibleMakes.length > 0 && (
                  <div className="border-t pt-6 mt-6">
                    <h2 className="text-xl font-bold text-gray-900 mb-4">Compatible With</h2>
                    <div className="flex flex-wrap gap-2">
                      {compatibleMakes.map((make: string, idx: number) => (
                        <div key={idx} className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg border border-gray-200">
                          <Car className="w-4 h-4 text-gray-600" />
                          <span className="font-semibold text-gray-900">{make}</span>
                        </div>
                      ))}
                    </div>
                    {specs.compatible_models && (
                      <div className="mt-3">
                        <p className="text-sm text-gray-600">Models: <span className="text-gray-900 font-semibold">{specs.compatible_models}</span></p>
                      </div>
                    )}
                  </div>
                )}

                {listing.description && (
                  <div className="border-t pt-6 mt-6">
                    <h2 className="text-xl font-bold text-gray-900 mb-4">Description</h2>
                    <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{listing.description}</p>
                  </div>
                )}

                <div className="border-t pt-6 mt-6">
                  <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
                    <Shield className="w-6 h-6 text-blue-600" />
                    <div>
                      <p className="font-bold text-gray-900">Safety Tips</p>
                      <p className="text-sm text-gray-700">Verify part compatibility. Check for warranty. Inspect before payment.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-md p-6 sticky top-6">
                <div className="mb-6">
                  <div className="text-3xl font-bold text-gray-900 mb-2">
                    ₦{listing.price.toLocaleString()}
                    {listing.price_negotiable && (
                      <span className="text-sm text-gray-600 font-normal ml-2">(Negotiable)</span>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  {listing.contact_phone && (
                    <div className="grid grid-cols-2 gap-3">
                      <a
                        href={`tel:${listing.contact_phone}`}
                        className="py-4 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
                      >
                        <Phone className="w-5 h-5" />
                        Call
                      </a>
                      <a
                        href={`https://wa.me/${(listing.contact_whatsapp || listing.contact_phone).replace(/\D/g, '')}?text=${encodeURIComponent(`Hi, I'm interested in: ${listing.title}`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-4 bg-[#25D366] hover:bg-[#20BD5A] text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
                      >
                        <MessageCircle className="w-5 h-5" />
                        WhatsApp
                      </a>
                    </div>
                  )}
                </div>

                <div className="mt-6 pt-6 border-t">
                  <p className="text-sm text-gray-600 mb-3 font-semibold">Seller Information</p>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                      {listing.profiles?.full_name?.charAt(0)?.toUpperCase() || 'U'}
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-gray-900 text-lg">{listing.profiles?.full_name || 'Anonymous Seller'}</p>
                      {listing.profiles?.verification_level > 0 && (
                        <div className="flex items-center gap-1 text-sm text-green-600 mt-1">
                          <Shield className="w-4 h-4" />
                          Verified Seller
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-100 border-2 border-gray-300 rounded-xl p-6">
                <h3 className="font-bold text-gray-900 mb-3">Safety First</h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-gray-700 flex-shrink-0 mt-0.5" />
                    <span>Verify part compatibility with your vehicle</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-gray-700 flex-shrink-0 mt-0.5" />
                    <span>Check warranty information</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-gray-700 flex-shrink-0 mt-0.5" />
                    <span>Inspect part condition before purchase</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <X className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                    <span>Never pay without seeing the part</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};
