import { useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  Home, Upload, X, CheckCircle2, AlertCircle, Image as ImageIcon,
  Bed, Users, Wifi, Coffee, Tv, Wind, Droplet, Utensils, Car, Shield,
  MapPin, DollarSign, Calendar, Star, Check
} from 'lucide-react';

export const UploadShortletAirbnbPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [currentStep, setCurrentStep] = useState(1);
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    propertyType: '',
    spaceType: '',
    guests: '',
    bedrooms: '',
    beds: '',
    bathrooms: '',
    pricePerNight: '',
    cleaningFee: '',
    securityDeposit: '',
    minimumNights: '1',
    maximumNights: '',
    checkInTime: '14:00',
    checkOutTime: '11:00',
    instantBook: false,
    amenities: {
      wifi: false,
      kitchen: false,
      tv: false,
      airConditioning: false,
      heating: false,
      washingMachine: false,
      freeParking: false,
      pool: false,
      hotTub: false,
      gym: false,
      bbqGrill: false,
      fireplace: false,
      dedicatedWorkspace: false,
      securityCameras: false,
      smokeAlarm: false,
      firstAidKit: false,
    },
    houseRules: {
      petsAllowed: false,
      smokingAllowed: false,
      partiesAllowed: false,
      childrenAllowed: true,
      quietHours: false,
    },
    locationState: '',
    locationCity: '',
    locationAddress: '',
    locationDescription: '',
    contactPhone: '',
    contactWhatsapp: '',
  });

  const propertyTypes = [
    'Apartment', 'House', 'Villa', 'Condo', 'Townhouse', 'Bungalow',
    'Loft', 'Guest House', 'Hotel Room', 'Serviced Apartment'
  ];

  const spaceTypes = [
    'Entire place', 'Private room', 'Shared room'
  ];

  const nigeriaStates = [
    'Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo', 'Kaduna', 'Anambra',
    'Enugu', 'Delta', 'Edo', 'Ogun', 'Ondo', 'Kwara', 'Imo'
  ];

  const amenitiesList = [
    { key: 'wifi', label: 'WiFi', icon: Wifi, category: 'essentials' },
    { key: 'kitchen', label: 'Kitchen', icon: Utensils, category: 'essentials' },
    { key: 'tv', label: 'TV', icon: Tv, category: 'essentials' },
    { key: 'airConditioning', label: 'Air Conditioning', icon: Wind, category: 'essentials' },
    { key: 'heating', label: 'Heating', icon: Wind, category: 'essentials' },
    { key: 'washingMachine', label: 'Washing Machine', icon: Droplet, category: 'essentials' },
    { key: 'freeParking', label: 'Free Parking', icon: Car, category: 'essentials' },
    { key: 'pool', label: 'Pool', icon: Droplet, category: 'features' },
    { key: 'hotTub', label: 'Hot Tub', icon: Droplet, category: 'features' },
    { key: 'gym', label: 'Gym', icon: Users, category: 'features' },
    { key: 'bbqGrill', label: 'BBQ Grill', icon: Coffee, category: 'features' },
    { key: 'fireplace', label: 'Fireplace', icon: Coffee, category: 'features' },
    { key: 'dedicatedWorkspace', label: 'Dedicated Workspace', icon: Coffee, category: 'features' },
    { key: 'securityCameras', label: 'Security Cameras', icon: Shield, category: 'safety' },
    { key: 'smokeAlarm', label: 'Smoke Alarm', icon: Shield, category: 'safety' },
    { key: 'firstAidKit', label: 'First Aid Kit', icon: Shield, category: 'safety' },
  ];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + imageFiles.length > 20) {
      setError('Maximum 20 images allowed');
      return;
    }

    setImageFiles((prev) => [...prev, ...files]);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreviews((prev) => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImageFiles((prev) => prev.filter((_, i) => i !== index));
    setImagePreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    setLoading(true);
    setError('');

    try {
      if (!user) throw new Error('Please sign in');
      if (imageFiles.length < 5) throw new Error('Add at least 5 images');

      const imageUrls: string[] = [];
      for (let i = 0; i < imageFiles.length; i++) {
        const file = imageFiles[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/shortlet-${Date.now()}-${i}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from('listing-images')
          .upload(fileName, file);

        if (!uploadError) {
          const { data: urlData } = supabase.storage
            .from('listing-images')
            .getPublicUrl(fileName);
          imageUrls.push(urlData.publicUrl);
        }
      }

      // Use 'shortlet' subcategory, fallback to 'real-estate' parent
      const { data: category } = await supabase
        .from('categories')
        .select('id, slug')
        .eq('slug', 'shortlet')
        .maybeSingle();

      let categoryId = category?.id;
      if (!categoryId) {
        const { data: parentCategory } = await supabase
          .from('categories')
          .select('id')
          .eq('slug', 'real-estate')
          .maybeSingle();
        categoryId = parentCategory?.id;
      }

      const listingData = {
        user_id: user.id,
        category_id: categoryId,
        title: formData.title,
        description: formData.description,
        price: parseFloat(formData.pricePerNight),
        currency: 'NGN',
        images: imageUrls,
        property_type: formData.propertyType,
        space_type: formData.spaceType,
        pricing_model: 'shortlet',
        guests: parseInt(formData.guests),
        bedrooms: parseInt(formData.bedrooms),
        beds: parseInt(formData.beds),
        bathrooms: parseInt(formData.bathrooms),
        cleaning_fee: formData.cleaningFee ? parseFloat(formData.cleaningFee) : null,
        security_deposit: formData.securityDeposit ? parseFloat(formData.securityDeposit) : null,
        minimum_nights: parseInt(formData.minimumNights),
        maximum_nights: formData.maximumNights ? parseInt(formData.maximumNights) : null,
        check_in_time: formData.checkInTime,
        check_out_time: formData.checkOutTime,
        instant_book: formData.instantBook,
        amenities: formData.amenities,
        house_rules: formData.houseRules,
        location_state: formData.locationState,
        location_city: formData.locationCity,
        location_address: formData.locationAddress,
        location_description: formData.locationDescription,
        contact_phone: formData.contactPhone,
        contact_whatsapp: formData.contactWhatsapp,
        status: 'active',
      };

      const { data: listing, error: listingError } = await supabase
        .from('listings')
        .insert(listingData)
        .select()
        .single();

      if (listingError) throw listingError;

      setSuccess(true);
      setTimeout(() => {
        window.location.href = category?.slug ? `/category/${category.slug}` : '/';
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    window.location.href = '/post-ad';
    return null;
  }

  const essentialAmenities = amenitiesList.filter(a => a.category === 'essentials');
  const featureAmenities = amenitiesList.filter(a => a.category === 'features');
  const safetyAmenities = amenitiesList.filter(a => a.category === 'safety');

  const steps = ['Property', 'Details', 'Amenities', 'Photos', 'Pricing'];
  const progress = (currentStep / steps.length) * 100;

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1">
        <div className="bg-gradient-to-r from-pink-500 via-red-500 to-orange-500 text-white py-6 px-4 sticky top-16 z-10 shadow-lg">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-4">
              <div>
                <a href="/post-ad" className="text-white/80 hover:text-white text-sm font-semibold mb-2 inline-block">
                  ← Back
                </a>
                <h1 className="text-3xl font-bold">List Your Short-Term Rental</h1>
                <p className="text-white/90">Airbnb-style listing in {steps.length} simple steps</p>
              </div>
              <div className="hidden md:block w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
                <Home className="w-8 h-8 text-white" />
              </div>
            </div>

            <div className="flex items-center gap-2">
              {steps.map((step, index) => (
                <div key={step} className="flex-1">
                  <div className="flex items-center gap-2">
                    <div
                      className={`flex-1 h-2 rounded-full transition-all ${
                        index + 1 <= currentStep ? 'bg-white' : 'bg-white/30'
                      }`}
                    />
                  </div>
                  <div className={`text-xs mt-1 ${index + 1 === currentStep ? 'font-bold' : 'text-white/70'}`}>
                    {step}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 py-8">
          {success && (
            <div className="mb-6 p-4 bg-green-50 border-2 border-green-200 rounded-2xl flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-green-800">Listing Created Successfully!</p>
                <p className="text-sm text-green-700">Redirecting to your listing...</p>
              </div>
            </div>
          )}

          {error && (
            <div className="mb-6 p-4 bg-red-50 border-2 border-red-200 rounded-2xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <span className="text-sm text-red-700">{error}</span>
            </div>
          )}

          {currentStep === 1 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">What type of place are you listing?</h2>
                <p className="text-gray-600 mb-6">Choose the property type that best describes your space</p>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {propertyTypes.map((type) => (
                    <button
                      key={type}
                      onClick={() => setFormData({ ...formData, propertyType: type })}
                      className={`p-6 border-2 rounded-2xl text-left transition-all hover:border-pink-500 hover:shadow-lg ${
                        formData.propertyType === type
                          ? 'border-pink-500 bg-pink-50 shadow-lg'
                          : 'border-gray-200'
                      }`}
                    >
                      <Home className={`w-8 h-8 mb-3 ${formData.propertyType === type ? 'text-pink-500' : 'text-gray-400'}`} />
                      <div className="font-bold text-gray-900">{type}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">What can guests book?</h3>
                <div className="space-y-3">
                  {spaceTypes.map((type) => (
                    <button
                      key={type}
                      onClick={() => setFormData({ ...formData, spaceType: type })}
                      className={`w-full p-5 border-2 rounded-xl text-left transition-all hover:border-pink-500 ${
                        formData.spaceType === type
                          ? 'border-pink-500 bg-pink-50'
                          : 'border-gray-200'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                          formData.spaceType === type ? 'border-pink-500 bg-pink-500' : 'border-gray-300'
                        }`}>
                          {formData.spaceType === type && <Check className="w-4 h-4 text-white" />}
                        </div>
                        <div>
                          <div className="font-bold text-gray-900">{type}</div>
                          <div className="text-sm text-gray-600">
                            {type === 'Entire place' && 'Guests have the whole place to themselves'}
                            {type === 'Private room' && 'Guests have their own room, shared common areas'}
                            {type === 'Shared room' && 'Guests sleep in a shared space'}
                          </div>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Share some basics about your place</h2>
                <p className="text-gray-600 mb-6">Let guests know what to expect</p>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-3">Guests</label>
                    <div className="flex items-center gap-4 p-4 border-2 border-gray-300 rounded-xl">
                      <Users className="w-6 h-6 text-gray-400" />
                      <input
                        type="number"
                        value={formData.guests}
                        onChange={(e) => setFormData({ ...formData, guests: e.target.value })}
                        placeholder="4"
                        min="1"
                        className="flex-1 text-lg font-semibold outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">Bedrooms</label>
                      <div className="flex items-center gap-2 p-4 border-2 border-gray-300 rounded-xl">
                        <Bed className="w-5 h-5 text-gray-400" />
                        <input
                          type="number"
                          value={formData.bedrooms}
                          onChange={(e) => setFormData({ ...formData, bedrooms: e.target.value })}
                          placeholder="2"
                          min="0"
                          className="flex-1 font-semibold outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">Beds</label>
                      <div className="flex items-center gap-2 p-4 border-2 border-gray-300 rounded-xl">
                        <Bed className="w-5 h-5 text-gray-400" />
                        <input
                          type="number"
                          value={formData.beds}
                          onChange={(e) => setFormData({ ...formData, beds: e.target.value })}
                          placeholder="3"
                          min="0"
                          className="flex-1 font-semibold outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">Bathrooms</label>
                      <div className="flex items-center gap-2 p-4 border-2 border-gray-300 rounded-xl">
                        <Droplet className="w-5 h-5 text-gray-400" />
                        <input
                          type="number"
                          value={formData.bathrooms}
                          onChange={(e) => setFormData({ ...formData, bathrooms: e.target.value })}
                          placeholder="2"
                          min="0"
                          step="0.5"
                          className="flex-1 font-semibold outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-3">Title</label>
                    <input
                      type="text"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="Beautiful apartment in the heart of Lagos"
                      className="w-full px-4 py-4 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500 text-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-3">Description</label>
                    <textarea
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Tell guests about your space - what makes it special, the neighborhood, nearby attractions..."
                      rows={6}
                      className="w-full px-4 py-4 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500 text-lg"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">What amenities do you offer?</h2>
                <p className="text-gray-600 mb-6">Select all that apply</p>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-4">Essentials</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {essentialAmenities.map((amenity) => (
                        <label
                          key={amenity.key}
                          className={`flex items-center gap-3 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                            formData.amenities[amenity.key as keyof typeof formData.amenities]
                              ? 'border-pink-500 bg-pink-50'
                              : 'border-gray-300 hover:border-pink-300'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={formData.amenities[amenity.key as keyof typeof formData.amenities]}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                amenities: { ...formData.amenities, [amenity.key]: e.target.checked },
                              })
                            }
                            className="w-5 h-5 text-pink-600 rounded"
                          />
                          <amenity.icon className="w-5 h-5 text-gray-600" />
                          <span className="font-semibold text-gray-900">{amenity.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-4">Features</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {featureAmenities.map((amenity) => (
                        <label
                          key={amenity.key}
                          className={`flex items-center gap-3 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                            formData.amenities[amenity.key as keyof typeof formData.amenities]
                              ? 'border-pink-500 bg-pink-50'
                              : 'border-gray-300 hover:border-pink-300'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={formData.amenities[amenity.key as keyof typeof formData.amenities]}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                amenities: { ...formData.amenities, [amenity.key]: e.target.checked },
                              })
                            }
                            className="w-5 h-5 text-pink-600 rounded"
                          />
                          <amenity.icon className="w-5 h-5 text-gray-600" />
                          <span className="font-semibold text-gray-900">{amenity.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-4">Safety</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {safetyAmenities.map((amenity) => (
                        <label
                          key={amenity.key}
                          className={`flex items-center gap-3 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                            formData.amenities[amenity.key as keyof typeof formData.amenities]
                              ? 'border-pink-500 bg-pink-50'
                              : 'border-gray-300 hover:border-pink-300'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={formData.amenities[amenity.key as keyof typeof formData.amenities]}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                amenities: { ...formData.amenities, [amenity.key]: e.target.checked },
                              })
                            }
                            className="w-5 h-5 text-pink-600 rounded"
                          />
                          <amenity.icon className="w-5 h-5 text-gray-600" />
                          <span className="font-semibold text-gray-900">{amenity.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-4">House Rules</h3>
                    <div className="space-y-3">
                      {[
                        { key: 'petsAllowed', label: 'Pets allowed' },
                        { key: 'smokingAllowed', label: 'Smoking allowed' },
                        { key: 'partiesAllowed', label: 'Parties/events allowed' },
                        { key: 'childrenAllowed', label: 'Children allowed' },
                        { key: 'quietHours', label: 'Quiet hours (10 PM - 8 AM)' },
                      ].map((rule) => (
                        <label
                          key={rule.key}
                          className="flex items-center gap-3 p-4 border-2 border-gray-300 rounded-xl cursor-pointer hover:border-pink-300"
                        >
                          <input
                            type="checkbox"
                            checked={formData.houseRules[rule.key as keyof typeof formData.houseRules]}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                houseRules: { ...formData.houseRules, [rule.key]: e.target.checked },
                              })
                            }
                            className="w-5 h-5 text-pink-600 rounded"
                          />
                          <span className="font-semibold text-gray-900">{rule.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Add photos of your place</h2>
                <p className="text-gray-600 mb-6">Upload at least 5 high-quality photos. The first will be your cover photo.</p>

                <div className="border-2 border-dashed border-gray-300 rounded-2xl p-12 text-center hover:border-pink-400 transition-colors bg-gray-50">
                  <ImageIcon className="w-20 h-20 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-2 font-semibold text-lg">Drag and drop or click to upload</p>
                  <p className="text-sm text-gray-500 mb-6">Upload up to 20 images</p>
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                    id="image-upload"
                  />
                  <label
                    htmlFor="image-upload"
                    className="px-8 py-4 bg-gradient-to-r from-pink-500 to-red-500 text-white rounded-xl cursor-pointer hover:from-pink-600 hover:to-red-600 inline-block font-bold shadow-lg text-lg"
                  >
                    Upload Photos
                  </label>
                </div>

                {imagePreviews.length > 0 && (
                  <div className="mt-8">
                    <p className="font-bold text-gray-900 mb-4">{imagePreviews.length} photo(s) uploaded</p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {imagePreviews.map((preview, index) => (
                        <div key={index} className="relative aspect-square rounded-xl overflow-hidden border-2 border-gray-200 shadow-md group">
                          <img src={preview} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                          <button
                            onClick={() => removeImage(index)}
                            className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full hover:bg-red-600 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-4 h-4" />
                          </button>
                          {index === 0 && (
                            <div className="absolute bottom-2 left-2 px-3 py-1 bg-pink-500 text-white text-xs font-bold rounded-full shadow-lg">
                              <Star className="w-3 h-3 inline mr-1" />
                              Cover
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-bold text-gray-900">Location</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-2">State</label>
                    <select
                      value={formData.locationState}
                      onChange={(e) => setFormData({ ...formData, locationState: e.target.value })}
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500"
                    >
                      <option value="">Select State</option>
                      {nigeriaStates.map((state) => (
                        <option key={state} value={state}>{state}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-2">City/Area</label>
                    <input
                      type="text"
                      value={formData.locationCity}
                      onChange={(e) => setFormData({ ...formData, locationCity: e.target.value })}
                      placeholder="e.g., Lekki, Victoria Island"
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-bold text-gray-900 mb-2">Street Address</label>
                    <input
                      type="text"
                      value={formData.locationAddress}
                      onChange={(e) => setFormData({ ...formData, locationAddress: e.target.value })}
                      placeholder="Full address"
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-bold text-gray-900 mb-2">Location Description</label>
                    <textarea
                      value={formData.locationDescription}
                      onChange={(e) => setFormData({ ...formData, locationDescription: e.target.value })}
                      placeholder="Describe the neighborhood, nearby attractions, transportation..."
                      rows={3}
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStep === 5 && (
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Set your price</h2>
                <p className="text-gray-600 mb-6">You can always change it later</p>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-3">Base Price (per night)</label>
                    <div className="relative">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-3xl font-bold text-gray-400">₦</div>
                      <input
                        type="number"
                        value={formData.pricePerNight}
                        onChange={(e) => setFormData({ ...formData, pricePerNight: e.target.value })}
                        placeholder="0"
                        className="w-full pl-14 pr-4 py-6 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500 text-3xl font-bold"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">Cleaning Fee (optional)</label>
                      <div className="relative">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-bold text-gray-400">₦</div>
                        <input
                          type="number"
                          value={formData.cleaningFee}
                          onChange={(e) => setFormData({ ...formData, cleaningFee: e.target.value })}
                          placeholder="0"
                          className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500 text-lg"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">Security Deposit (optional)</label>
                      <div className="relative">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-bold text-gray-400">₦</div>
                        <input
                          type="number"
                          value={formData.securityDeposit}
                          onChange={(e) => setFormData({ ...formData, securityDeposit: e.target.value })}
                          placeholder="0"
                          className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500 text-lg"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">Minimum Nights</label>
                      <input
                        type="number"
                        value={formData.minimumNights}
                        onChange={(e) => setFormData({ ...formData, minimumNights: e.target.value })}
                        min="1"
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">Maximum Nights (optional)</label>
                      <input
                        type="number"
                        value={formData.maximumNights}
                        onChange={(e) => setFormData({ ...formData, maximumNights: e.target.value })}
                        placeholder="No limit"
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">Check-in Time</label>
                      <input
                        type="time"
                        value={formData.checkInTime}
                        onChange={(e) => setFormData({ ...formData, checkInTime: e.target.value })}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">Check-out Time</label>
                      <input
                        type="time"
                        value={formData.checkOutTime}
                        onChange={(e) => setFormData({ ...formData, checkOutTime: e.target.value })}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500"
                      />
                    </div>
                  </div>

                  <label className="flex items-center gap-3 p-4 border-2 border-gray-300 rounded-xl cursor-pointer hover:border-pink-300">
                    <input
                      type="checkbox"
                      checked={formData.instantBook}
                      onChange={(e) => setFormData({ ...formData, instantBook: e.target.checked })}
                      className="w-5 h-5 text-pink-600 rounded"
                    />
                    <div>
                      <div className="font-bold text-gray-900">Enable Instant Book</div>
                      <div className="text-sm text-gray-600">Guests can book without waiting for approval</div>
                    </div>
                  </label>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-bold text-gray-900">Contact Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-2">Phone Number</label>
                    <input
                      type="tel"
                      value={formData.contactPhone}
                      onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                      placeholder="+234 XXX XXX XXXX"
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-2">WhatsApp</label>
                    <input
                      type="tel"
                      value={formData.contactWhatsapp}
                      onChange={(e) => setFormData({ ...formData, contactWhatsapp: e.target.value })}
                      placeholder="+234 XXX XXX XXXX"
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-pink-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between gap-4 pt-8 border-t-2">
            {currentStep > 1 && (
              <button
                onClick={() => setCurrentStep(currentStep - 1)}
                className="px-8 py-4 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:border-gray-400 transition-all"
              >
                Back
              </button>
            )}

            {currentStep < steps.length ? (
              <button
                onClick={() => setCurrentStep(currentStep + 1)}
                disabled={
                  (currentStep === 1 && (!formData.propertyType || !formData.spaceType)) ||
                  (currentStep === 2 && (!formData.guests || !formData.title || !formData.description))
                }
                className="ml-auto px-8 py-4 bg-gradient-to-r from-pink-500 to-red-500 text-white rounded-xl font-bold hover:from-pink-600 hover:to-red-600 transition-all disabled:opacity-50 shadow-lg"
              >
                Next
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={loading || imageFiles.length < 5 || !formData.pricePerNight}
                className="ml-auto px-8 py-4 bg-gradient-to-r from-pink-500 to-red-500 text-white rounded-xl font-bold hover:from-pink-600 hover:to-red-600 transition-all disabled:opacity-50 shadow-lg flex items-center gap-3"
              >
                {loading ? (
                  <>
                    <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                    Publishing...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    Publish Listing
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};
