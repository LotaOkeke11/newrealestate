import { useEffect, useState } from 'react';
import { TrendingUp, Zap, Star, MapPin, Heart, Plus, Upload, Eye, MessageCircle, ShoppingCart, Crown } from 'lucide-react';
import { Header } from '../components/Header';
import { CategoryNav } from '../components/CategoryNav';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { supabase, Category } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

type Listing = {
  id: string;
  title: string;
  price: number;
  images: string[];
  location_city?: string;
  location_state?: string;
  created_at: string;
  status: string;
  user_id?: string;
};

export const HomePage = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [listings, setListings] = useState<Listing[]>([]);
  const [featuredListings, setFeaturedListings] = useState<Listing[]>([]);
  const [cameraListings, setCameraListings] = useState<Listing[]>([]);
  const [mediaListings, setMediaListings] = useState<Listing[]>([]);
  const [saleListings, setSaleListings] = useState<Listing[]>([]);
  const [rentListings, setRentListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [addingToCart, setAddingToCart] = useState<string | null>(null);
  const [userSubscription, setUserSubscription] = useState<any>(null);
  const [isPremium, setIsPremium] = useState(false);
  const { user, profile } = useAuth();

  useEffect(() => {
    loadCategories();
    loadListings();
    loadCategoryListings();
    if (user) {
      loadUserSubscription();
    }
  }, [user]);

  const loadUserSubscription = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('subscriptions')
      .select('*, subscription_tiers(*)')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .maybeSingle();

    if (data) {
      setUserSubscription(data);
      // Premium is Growth tier (level 2) and above
      const tier = data.subscription_tiers as any;
      setIsPremium(tier?.level >= 2);
    } else {
      setIsPremium(false);
    }
  };

  const loadCategories = async () => {
    const { data } = await supabase
      .from('categories')
      .select('*')
      .is('parent_id', null)
      .order('order_index')
      .limit(8);

    if (data) {
      setCategories(data);
    }
  };

  const loadListings = async () => {
    setLoading(true);
    try {
      const { data: allListings } = await supabase
        .from('listings')
        .select(`
          id,
          title,
          price,
          images,
          location_city,
          location_state,
          created_at,
          status,
          user_id,
          categories(name, slug)
        `)
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(50);

      if (allListings) {
        setListings(allListings);
        setFeaturedListings(allListings.slice(0, 5));
      }
    } catch (error) {
      console.error('Error loading listings:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadCategoryListings = async () => {
    try {
      const { data: cameras } = await supabase
        .from('listings')
        .select(`
          id,
          title,
          price,
          images,
          location_city,
          location_state,
          created_at,
          status,
          user_id,
          categories!inner(name, slug)
        `)
        .eq('categories.slug', 'cameras')
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(10);

      if (cameras) setCameraListings(cameras);

      const { data: media } = await supabase
        .from('listings')
        .select(`
          id,
          title,
          price,
          images,
          location_city,
          location_state,
          created_at,
          status,
          user_id,
          categories!inner(name, slug)
        `)
        .eq('categories.slug', 'media-creative')
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(10);

      if (media) setMediaListings(media);

      // Load Sale category listings
      const { data: sale } = await supabase
        .from('listings')
        .select(`
          id,
          title,
          price,
          images,
          location_city,
          location_state,
          created_at,
          status,
          user_id,
          categories!inner(name, slug)
        `)
        .eq('categories.slug', 'sale')
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(10);

      if (sale) setSaleListings(sale);

      // Load Rent category listings
      const { data: rent } = await supabase
        .from('listings')
        .select(`
          id,
          title,
          price,
          images,
          location_city,
          location_state,
          created_at,
          status,
          user_id,
          categories!inner(name, slug)
        `)
        .eq('categories.slug', 'rent')
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(10);

      if (rent) setRentListings(rent);
    } catch (error) {
      console.error('Error loading category listings:', error);
    }
  };

  const getListingImage = (listing: Listing) => {
    if (listing.images && listing.images.length > 0) {
      return listing.images[0];
    }
    return 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=400';
  };

  const getListingLocation = (listing: Listing) => {
    if (listing.location_city && listing.location_state) {
      return `${listing.location_city}, ${listing.location_state}`;
    }
    if (listing.location_city) return listing.location_city;
    if (listing.location_state) return listing.location_state;
    return 'Nigeria';
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const handleProductClick = (listingId: string) => {
    window.location.href = `/product/${listingId}`;
  };

  const addToCart = async (e: React.MouseEvent, listingId: string) => {
    e.stopPropagation();

    if (!user) {
      window.location.href = '/login';
      return;
    }

    setAddingToCart(listingId);

    try {
      const { data: existingItem } = await supabase
        .from('cart_items')
        .select('id, quantity')
        .eq('user_id', user.id)
        .eq('listing_id', listingId)
        .maybeSingle();

      if (existingItem) {
        await supabase
          .from('cart_items')
          .update({ quantity: existingItem.quantity + 1 })
          .eq('id', existingItem.id);
      } else {
        await supabase
          .from('cart_items')
          .insert({
            user_id: user.id,
            listing_id: listingId,
            quantity: 1
          });
      }

      const cartButton = document.querySelector(`[data-cart-button="${listingId}"]`);
      if (cartButton) {
        cartButton.classList.add('animate-bounce');
        setTimeout(() => cartButton.classList.remove('animate-bounce'), 500);
      }
    } catch (error) {
      console.error('Error adding to cart:', error);
    } finally {
      setAddingToCart(null);
    }
  };

  const startChat = async (e: React.MouseEvent, listing: Listing) => {
    e.stopPropagation();

    if (!user) {
      window.location.href = '/login';
      return;
    }

    if (listing.user_id === user.id) {
      return;
    }

    const { data: existingConv } = await supabase
      .from('conversations')
      .select('id')
      .eq('listing_id', listing.id)
      .eq('buyer_id', user.id)
      .eq('seller_id', listing.user_id)
      .maybeSingle();

    if (existingConv) {
      window.location.href = `/chat?conversation=${existingConv.id}`;
      return;
    }

    const { data: newConv } = await supabase
      .from('conversations')
      .insert({
        listing_id: listing.id,
        buyer_id: user.id,
        seller_id: listing.user_id,
        last_message: `Interested in: ${listing.title}`,
        last_message_at: new Date().toISOString()
      })
      .select()
      .single();

    if (newConv) {
      await supabase
        .from('messages')
        .insert({
          conversation_id: newConv.id,
          sender_id: user.id,
          recipient_id: listing.user_id,
          content: `Hi! I'm interested in "${listing.title}"`,
          topic: 'listing',
          extension: 'text',
          is_read: false
        });

      window.location.href = `/chat?conversation=${newConv.id}`;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />
      <CategoryNav />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {user && (profile?.account_type === 'seller' || profile?.account_type === 'business') && (
          <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <a
              href="/post-ad"
              className="flex items-center justify-center gap-3 py-5 bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 text-white rounded-2xl font-bold text-lg hover:from-amber-600 hover:via-orange-600 hover:to-orange-700 transition-all shadow-xl hover:shadow-2xl hover:scale-105 group"
            >
              <Plus className="w-7 h-7 group-hover:rotate-90 transition-transform" />
              <span>Post Ad</span>
            </a>
            <a
              href="/dashboard"
              className="flex items-center justify-center gap-3 py-5 bg-white border-2 border-amber-300 text-amber-700 rounded-2xl font-bold text-lg hover:bg-amber-50 transition-all shadow-lg hover:shadow-xl hover:scale-105"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
              <span>My Dashboard</span>
            </a>
          </div>
        )}

        {isPremium ? (
          <section className="mb-8">
            <div className="relative h-80 rounded-3xl overflow-hidden bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 shadow-xl">
              <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full flex items-center gap-2">
                <Crown className="w-5 h-5 text-white" />
                <span className="text-white font-semibold text-sm">Premium Feature</span>
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white px-4">
                  <h1 className="text-4xl md:text-5xl font-bold mb-3 drop-shadow-lg">
                    Shop Everything in Nigeria
                  </h1>
                  <p className="text-lg md:text-xl mb-6 drop-shadow">
                    From Real Estate to Electronics - Unbeatable Prices
                  </p>
                  <div className="flex flex-wrap gap-4 justify-center">
                    <a
                      href="/post-ad"
                      className="px-8 py-4 bg-white text-amber-600 rounded-xl font-bold hover:bg-amber-50 transition-all shadow-xl hover:shadow-2xl hover:scale-105 flex items-center gap-2"
                    >
                      <Plus className="w-5 h-5" />
                      Post Your Ad
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </section>
        ) : user ? (
          <section className="mb-8">
            <div className="relative h-80 rounded-3xl overflow-hidden bg-gradient-to-r from-gray-700 via-gray-800 to-gray-900 shadow-xl border-2 border-amber-400">
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnptLTEyIDBjMy4zMTQgMCA2IDIuNjg2IDYgNnMtMi42ODYgNi02IDYtNi0yLjY4Ni02LTYgMi42ODYtNiA2LTZ6IiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9Ii4wNSIvPjwvZz48L3N2Zz4=')] opacity-20"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white px-4 relative z-10">
                  <div className="inline-block p-3 bg-amber-500/20 rounded-full mb-4">
                    <Crown className="w-12 h-12 text-amber-400" />
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold mb-3 drop-shadow-lg">
                    Premium Advertisement Space
                  </h2>
                  <p className="text-lg md:text-xl mb-6 drop-shadow text-gray-300">
                    Unlock this premium banner to showcase your business to thousands of buyers
                  </p>
                  <div className="flex flex-wrap gap-4 justify-center">
                    <a
                      href="/subscription"
                      className="px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-bold hover:from-amber-600 hover:to-amber-700 transition-all shadow-xl hover:shadow-2xl hover:scale-105 flex items-center gap-2"
                    >
                      <Crown className="w-5 h-5" />
                      Upgrade to Premium
                    </a>
                    <a
                      href="/post-ad"
                      className="px-8 py-4 bg-white/10 backdrop-blur-sm text-white border-2 border-white/30 rounded-xl font-bold hover:bg-white/20 transition-all shadow-xl flex items-center gap-2"
                    >
                      <Plus className="w-5 h-5" />
                      Post Regular Ad
                    </a>
                  </div>
                  <p className="mt-4 text-sm text-gray-400">
                    Starting from ₦2,500/month • Growth tier and above
                  </p>
                </div>
              </div>
            </div>
          </section>
        ) : (
          <section className="mb-8">
            <div className="relative h-80 rounded-3xl overflow-hidden bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 shadow-xl">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white px-4">
                  <h1 className="text-4xl md:text-5xl font-bold mb-3 drop-shadow-lg">
                    Shop Everything in Nigeria
                  </h1>
                  <p className="text-lg md:text-xl mb-6 drop-shadow">
                    From Real Estate to Electronics - Unbeatable Prices
                  </p>
                  <div className="flex flex-wrap gap-4 justify-center">
                    <a
                      href="/register"
                      className="px-8 py-4 bg-white text-amber-600 rounded-xl font-bold hover:bg-amber-50 transition-all shadow-xl hover:shadow-2xl hover:scale-105 flex items-center gap-2"
                    >
                      <Plus className="w-5 h-5" />
                      Start Selling Now
                    </a>
                    <a
                      href="/subscription"
                      className="px-8 py-4 bg-amber-700 text-white rounded-xl font-bold hover:bg-amber-800 transition-all shadow-xl hover:shadow-2xl hover:scale-105"
                    >
                      View Plans
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center">
              <Zap className="w-7 h-7 text-amber-500 mr-2 fill-current" />
              Featured Listings
            </h2>
            <a href="/search" className="text-amber-600 hover:text-amber-700 font-semibold text-sm">
              View All →
            </a>
          </div>
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full mx-auto"></div>
              <p className="text-gray-600 mt-4">Loading listings...</p>
            </div>
          ) : featuredListings.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
              {featuredListings.map((listing) => (
                <button
                  key={listing.id}
                  onClick={() => handleProductClick(listing.id)}
                  className="group bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden border border-gray-100 text-left"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={getListingImage(listing)}
                      alt={listing.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 bg-white/95 rounded-full hover:bg-white transition-colors shadow-lg">
                        <Heart className="w-4 h-4 text-gray-600" />
                      </button>
                      <button
                        onClick={(e) => startChat(e, listing)}
                        disabled={!user || listing.user_id === user?.id}
                        className="p-2 bg-green-500 hover:bg-green-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to message seller' : listing.user_id === user?.id ? 'Your own listing' : 'Message seller'}
                      >
                        <MessageCircle className="w-4 h-4 text-white" />
                      </button>
                      <button
                        onClick={(e) => addToCart(e, listing.id)}
                        disabled={addingToCart === listing.id || !user || listing.user_id === user?.id}
                        data-cart-button={listing.id}
                        className="p-2 bg-amber-500 hover:bg-amber-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to add to cart' : listing.user_id === user?.id ? 'Your own listing' : 'Add to cart'}
                      >
                        <ShoppingCart className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  </div>
                  <div className="p-2">
                    <h3 className="font-medium text-sm text-gray-900 line-clamp-2 mb-1">
                      {listing.title}
                    </h3>
                    <p className="text-amber-600 font-bold text-sm mb-1">
                      {formatPrice(listing.price)}
                    </p>
                    <div className="flex items-center text-xs text-gray-500">
                      <MapPin className="w-3 h-3 mr-1" />
                      <span>{getListingLocation(listing)}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-50 rounded-xl">
              <p className="text-gray-600">No listings yet. Be the first to post!</p>
              <a href="/post-ad" className="mt-4 inline-block px-6 py-3 bg-amber-500 text-white rounded-xl font-bold hover:bg-amber-600">
                Post Your First Listing
              </a>
            </div>
          )}
        </section>

        <section className="mb-8 bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Shop by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {categories.map((category) => (
              <a
                key={category.id}
                href={`/category/${category.slug}`}
                className="bg-white rounded-xl p-4 hover:shadow-md transition-all text-center"
              >
                <div className="w-12 h-12 mx-auto mb-2 bg-amber-100 rounded-full flex items-center justify-center">
                  <span className="text-2xl">📦</span>
                </div>
                <p className="font-semibold text-sm text-gray-900">{category.name}</p>
              </a>
            ))}
          </div>
        </section>

        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center">
              <TrendingUp className="w-7 h-7 text-amber-600 mr-2" />
              Recent Listings
            </h2>
            <a href="/search" className="text-amber-600 hover:text-amber-700 font-semibold text-sm">
              View All →
            </a>
          </div>
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full mx-auto"></div>
              <p className="text-gray-600 mt-4">Loading listings...</p>
            </div>
          ) : listings.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
              {listings.map((listing) => (
                <button
                  key={listing.id}
                  onClick={() => handleProductClick(listing.id)}
                  className="group bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden border border-gray-100 text-left"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={getListingImage(listing)}
                      alt={listing.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 bg-white/95 rounded-full hover:bg-white transition-colors shadow-lg">
                        <Heart className="w-4 h-4 text-gray-600" />
                      </button>
                      <button
                        onClick={(e) => startChat(e, listing)}
                        disabled={!user || listing.user_id === user?.id}
                        className="p-2 bg-green-500 hover:bg-green-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to message seller' : listing.user_id === user?.id ? 'Your own listing' : 'Message seller'}
                      >
                        <MessageCircle className="w-4 h-4 text-white" />
                      </button>
                      <button
                        onClick={(e) => addToCart(e, listing.id)}
                        disabled={addingToCart === listing.id || !user || listing.user_id === user?.id}
                        data-cart-button={listing.id}
                        className="p-2 bg-amber-500 hover:bg-amber-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to add to cart' : listing.user_id === user?.id ? 'Your own listing' : 'Add to cart'}
                      >
                        <ShoppingCart className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  </div>
                  <div className="p-2">
                    <h3 className="font-medium text-sm text-gray-900 line-clamp-2 mb-1">
                      {listing.title}
                    </h3>
                    <p className="text-amber-600 font-bold text-sm mb-1">
                      {formatPrice(listing.price)}
                    </p>
                    <div className="flex items-center text-xs text-gray-500">
                      <MapPin className="w-3 h-3 mr-1" />
                      <span className="line-clamp-1">{getListingLocation(listing)}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-50 rounded-xl">
              <p className="text-gray-600">No listings yet. Be the first to post!</p>
              <a href="/post-ad" className="mt-4 inline-block px-6 py-3 bg-amber-500 text-white rounded-xl font-bold hover:bg-amber-600">
                Post Your First Listing
              </a>
            </div>
          )}
        </section>

        {cameraListings.length > 0 && (
          <section className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center">
                <span className="text-3xl mr-3">📷</span>
                Professional Cameras & Equipment
              </h2>
              <a href="/category/cameras" className="text-amber-600 hover:text-amber-700 font-semibold text-sm">
                View All →
              </a>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
              {cameraListings.slice(0, 5).map((listing) => (
                <button
                  key={listing.id}
                  onClick={() => handleProductClick(listing.id)}
                  className="group bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden border border-gray-100 text-left"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={getListingImage(listing)}
                      alt={listing.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 bg-white/95 rounded-full hover:bg-white transition-colors shadow-lg">
                        <Heart className="w-4 h-4 text-gray-600" />
                      </button>
                      <button
                        onClick={(e) => startChat(e, listing)}
                        disabled={!user || listing.user_id === user?.id}
                        className="p-2 bg-green-500 hover:bg-green-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to message seller' : listing.user_id === user?.id ? 'Your own listing' : 'Message seller'}
                      >
                        <MessageCircle className="w-4 h-4 text-white" />
                      </button>
                      <button
                        onClick={(e) => addToCart(e, listing.id)}
                        disabled={addingToCart === listing.id || !user || listing.user_id === user?.id}
                        data-cart-button={listing.id}
                        className="p-2 bg-amber-500 hover:bg-amber-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to add to cart' : listing.user_id === user?.id ? 'Your own listing' : 'Add to cart'}
                      >
                        <ShoppingCart className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  </div>
                  <div className="p-2">
                    <h3 className="font-medium text-sm text-gray-900 line-clamp-2 mb-1">
                      {listing.title}
                    </h3>
                    <p className="text-amber-600 font-bold text-sm mb-1">
                      {formatPrice(listing.price)}
                    </p>
                    <div className="flex items-center text-xs text-gray-500">
                      <MapPin className="w-3 h-3 mr-1" />
                      <span className="line-clamp-1">{getListingLocation(listing)}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {mediaListings.length > 0 && (
          <section className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center">
                <span className="text-3xl mr-3">🎬</span>
                Media & Creative Equipment
              </h2>
              <a href="/category/media-creative" className="text-amber-600 hover:text-amber-700 font-semibold text-sm">
                View All →
              </a>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
              {mediaListings.slice(0, 5).map((listing) => (
                <button
                  key={listing.id}
                  onClick={() => handleProductClick(listing.id)}
                  className="group bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden border border-gray-100 text-left"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={getListingImage(listing)}
                      alt={listing.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 bg-white/95 rounded-full hover:bg-white transition-colors shadow-lg">
                        <Heart className="w-4 h-4 text-gray-600" />
                      </button>
                      <button
                        onClick={(e) => startChat(e, listing)}
                        disabled={!user || listing.user_id === user?.id}
                        className="p-2 bg-green-500 hover:bg-green-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to message seller' : listing.user_id === user?.id ? 'Your own listing' : 'Message seller'}
                      >
                        <MessageCircle className="w-4 h-4 text-white" />
                      </button>
                      <button
                        onClick={(e) => addToCart(e, listing.id)}
                        disabled={addingToCart === listing.id || !user || listing.user_id === user?.id}
                        data-cart-button={listing.id}
                        className="p-2 bg-amber-500 hover:bg-amber-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to add to cart' : listing.user_id === user?.id ? 'Your own listing' : 'Add to cart'}
                      >
                        <ShoppingCart className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  </div>
                  <div className="p-2">
                    <h3 className="font-medium text-sm text-gray-900 line-clamp-2 mb-1">
                      {listing.title}
                    </h3>
                    <p className="text-amber-600 font-bold text-sm mb-1">
                      {formatPrice(listing.price)}
                    </p>
                    <div className="flex items-center text-xs text-gray-500">
                      <MapPin className="w-3 h-3 mr-1" />
                      <span className="line-clamp-1">{getListingLocation(listing)}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {saleListings.length > 0 && (
          <section className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center">
                <span className="text-3xl mr-3">🏡</span>
                Properties for Sale
              </h2>
              <a href="/category/sale" className="text-amber-600 hover:text-amber-700 font-semibold text-sm">
                View All →
              </a>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
              {saleListings.slice(0, 5).map((listing) => (
                <button
                  key={listing.id}
                  onClick={() => handleProductClick(listing.id)}
                  className="group bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden border border-gray-100 text-left"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={getListingImage(listing)}
                      alt={listing.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 bg-white/95 rounded-full hover:bg-white transition-colors shadow-lg">
                        <Heart className="w-4 h-4 text-gray-600" />
                      </button>
                      <button
                        onClick={(e) => startChat(e, listing)}
                        disabled={!user || listing.user_id === user?.id}
                        className="p-2 bg-green-500 hover:bg-green-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to message seller' : listing.user_id === user?.id ? 'Your own listing' : 'Message seller'}
                      >
                        <MessageCircle className="w-4 h-4 text-white" />
                      </button>
                      <button
                        onClick={(e) => addToCart(e, listing.id)}
                        disabled={addingToCart === listing.id || !user || listing.user_id === user?.id}
                        data-cart-button={listing.id}
                        className="p-2 bg-amber-500 hover:bg-amber-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to add to cart' : listing.user_id === user?.id ? 'Your own listing' : 'Add to cart'}
                      >
                        <ShoppingCart className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  </div>
                  <div className="p-2">
                    <h3 className="font-medium text-sm text-gray-900 line-clamp-2 mb-1">
                      {listing.title}
                    </h3>
                    <p className="text-amber-600 font-bold text-sm mb-1">
                      {formatPrice(listing.price)}
                    </p>
                    <div className="flex items-center text-xs text-gray-500">
                      <MapPin className="w-3 h-3 mr-1" />
                      <span className="line-clamp-1">{getListingLocation(listing)}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {rentListings.length > 0 && (
          <section className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center">
                <span className="text-3xl mr-3">🏠</span>
                Properties for Rent
              </h2>
              <a href="/category/rent" className="text-amber-600 hover:text-amber-700 font-semibold text-sm">
                View All →
              </a>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
              {rentListings.slice(0, 5).map((listing) => (
                <button
                  key={listing.id}
                  onClick={() => handleProductClick(listing.id)}
                  className="group bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden border border-gray-100 text-left"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={getListingImage(listing)}
                      alt={listing.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 bg-white/95 rounded-full hover:bg-white transition-colors shadow-lg">
                        <Heart className="w-4 h-4 text-gray-600" />
                      </button>
                      <button
                        onClick={(e) => startChat(e, listing)}
                        disabled={!user || listing.user_id === user?.id}
                        className="p-2 bg-green-500 hover:bg-green-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to message seller' : listing.user_id === user?.id ? 'Your own listing' : 'Message seller'}
                      >
                        <MessageCircle className="w-4 h-4 text-white" />
                      </button>
                      <button
                        onClick={(e) => addToCart(e, listing.id)}
                        disabled={addingToCart === listing.id || !user || listing.user_id === user?.id}
                        data-cart-button={listing.id}
                        className="p-2 bg-amber-500 hover:bg-amber-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                        title={!user ? 'Sign in to add to cart' : listing.user_id === user?.id ? 'Your own listing' : 'Add to cart'}
                      >
                        <ShoppingCart className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  </div>
                  <div className="p-2">
                    <h3 className="font-medium text-sm text-gray-900 line-clamp-2 mb-1">
                      {listing.title}
                    </h3>
                    <p className="text-amber-600 font-bold text-sm mb-1">
                      {formatPrice(listing.price)}
                    </p>
                    <div className="flex items-center text-xs text-gray-500">
                      <MapPin className="w-3 h-3 mr-1" />
                      <span className="line-clamp-1">{getListingLocation(listing)}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        <section className="mb-8">
          <div className="bg-gradient-to-r from-amber-100 to-amber-50 rounded-3xl p-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-3">
                Ready to Start Selling?
              </h2>
              <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
                Join thousands of sellers on Nigeria's fastest-growing marketplace.
                List your products and reach millions of buyers.
              </p>
              <div className="flex flex-wrap justify-center gap-4 mb-6">
                <div className="bg-white rounded-xl p-4 shadow-md min-w-[130px]">
                  <div className="text-2xl font-bold text-amber-600">5+</div>
                  <div className="text-xs text-gray-600">Plans</div>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-md min-w-[130px]">
                  <div className="text-2xl font-bold text-amber-600">12+</div>
                  <div className="text-xs text-gray-600">Categories</div>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-md min-w-[130px]">
                  <div className="text-2xl font-bold text-amber-600">24/7</div>
                  <div className="text-xs text-gray-600">Support</div>
                </div>
              </div>
              <a
                href="/register"
                className="inline-block px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-full font-bold text-lg hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg"
              >
                Start Selling Today
              </a>
            </div>
          </div>
        </section>
      </main>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">Simple steps to start buying, selling, or renting</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center group">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform shadow-xl">
                <Upload className="w-12 h-12 text-white" />
              </div>
              <div className="bg-blue-50 text-blue-600 text-sm font-bold px-4 py-1 rounded-full inline-block mb-4">
                Step 1
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Post an Ad</h3>
              <p className="text-gray-600">
                Create your listing in minutes with photos, description, and pricing. Choose from various categories including real estate, vehicles, services, and more.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-emerald-500 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform shadow-xl">
                <Eye className="w-12 h-12 text-white" />
              </div>
              <div className="bg-green-50 text-green-600 text-sm font-bold px-4 py-1 rounded-full inline-block mb-4">
                Step 2
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Get Seen</h3>
              <p className="text-gray-600">
                Your listing reaches thousands of potential buyers. Get verified to boost visibility and build trust with buyers across Nigeria.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-24 h-24 bg-gradient-to-br from-amber-500 to-orange-500 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform shadow-xl">
                <MessageCircle className="w-12 h-12 text-white" />
              </div>
              <div className="bg-amber-50 text-amber-600 text-sm font-bold px-4 py-1 rounded-full inline-block mb-4">
                Step 3
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Chat & Close Deals</h3>
              <p className="text-gray-600">
                Connect directly with buyers through our secure messaging platform. Negotiate, arrange viewings, and close deals safely.
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <a
              href="/post-ad"
              className="inline-block px-8 py-4 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white rounded-2xl font-bold hover:from-amber-600 hover:via-orange-600 hover:to-orange-700 transition-all shadow-lg text-lg"
            >
              Get Started Now
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};
