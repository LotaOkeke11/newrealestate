import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  Home, Car, Smartphone, Shirt, Sofa, Briefcase, Music, Calendar,
  Package, ArrowRight, Sparkles, Zap, Heart, ShoppingBasket, Utensils
} from 'lucide-react';

type Category = {
  id: string;
  name: string;
  slug: string;
  icon: any;
  color: string;
  gradient: string;
  description: string;
};

export const UnifiedPostAdPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    const { data } = await supabase
      .from('categories')
      .select('*')
      .order('name');

    if (data) {
      const categoriesWithIcons: Category[] = data.map((cat) => ({
        ...cat,
        icon: getCategoryIcon(cat.slug),
        color: getCategoryColor(cat.slug),
        gradient: getCategoryGradient(cat.slug),
        description: getCategoryDescription(cat.slug),
      }));
      setCategories(categoriesWithIcons);
    }
    setLoading(false);
  };

  const getCategoryIcon = (slug: string) => {
    const iconMap: { [key: string]: any } = {
      'real-estate': Home,
      'vehicles': Car,
      'electronics': Smartphone,
      'fashion': Shirt,
      'home-furniture': Sofa,
      'jobs-services': Briefcase,
      'music-equipment': Music,
      'events': Calendar,
      'beauty-personal-care': Heart,
      'food-restaurants': Utensils,
      'foodstuffs': ShoppingBasket,
      'restaurants': Utensils,
    };
    return iconMap[slug] || Package;
  };

  const getCategoryColor = (slug: string) => {
    const colorMap: { [key: string]: string } = {
      'real-estate': 'blue',
      'vehicles': 'green',
      'electronics': 'orange',
      'fashion': 'pink',
      'home-furniture': 'purple',
      'jobs-services': 'indigo',
      'music-equipment': 'red',
      'events': 'yellow',
      'beauty-personal-care': 'rose',
      'food-restaurants': 'amber',
      'foodstuffs': 'lime',
      'restaurants': 'orange',
    };
    return colorMap[slug] || 'gray';
  };

  const getCategoryGradient = (slug: string) => {
    const gradientMap: { [key: string]: string } = {
      'real-estate': 'from-blue-500 to-cyan-500',
      'vehicles': 'from-green-500 to-emerald-500',
      'electronics': 'from-orange-500 to-amber-500',
      'fashion': 'from-pink-500 to-rose-500',
      'home-furniture': 'from-purple-500 to-violet-500',
      'jobs-services': 'from-indigo-500 to-blue-600',
      'music-equipment': 'from-red-500 to-orange-500',
      'events': 'from-yellow-500 to-orange-400',
      'beauty-personal-care': 'from-pink-500 to-rose-500',
      'food-restaurants': 'from-amber-500 to-orange-500',
      'foodstuffs': 'from-lime-500 to-green-500',
      'restaurants': 'from-orange-500 to-red-500',
    };
    return gradientMap[slug] || 'from-gray-500 to-gray-600';
  };

  const getCategoryDescription = (slug: string) => {
    const descMap: { [key: string]: string } = {
      'real-estate': 'List properties for sale, rent, or shortlet',
      'vehicles': 'Sell or rent cars, bikes, and vehicles',
      'electronics': 'Sell phones, laptops, and gadgets',
      'fashion': 'Sell clothing, shoes, and accessories',
      'home-furniture': 'List furniture and home decor',
      'jobs-services': 'Post job openings or offer services',
      'music-equipment': 'Rent or sell music gear',
      'events': 'Create and promote events',
      'beauty-personal-care': 'List beauty products or services',
      'food-restaurants': 'List foodstuffs or restaurant menu',
      'foodstuffs': 'Sell rice, oil, beans, and groceries',
      'restaurants': 'Add your restaurant and food menu',
    };
    return descMap[slug] || 'Post your listing';
  };

  const getUploadPath = (slug: string) => {
    const pathMap: { [key: string]: string } = {
      'real-estate': '/upload/real-estate',
      'rent': '/upload/real-estate',
      'sale': '/upload/real-estate',
      'shortlets': '/upload/shortlet',
      'lands': '/upload/lands',
      'commercial': '/upload/commercial',
      'vehicles': '/upload/vehicles',
      'cars-vehicles': '/upload/vehicles',
      'cars-sale': '/upload/vehicles',
      'motorcycles': '/upload/motorcycles',
      'luxury-rentals': '/upload/luxury-rentals',
      'boats-marine': '/upload/boats-marine',
      'auto-parts': '/upload/auto-parts',
      'car-parts': '/upload/auto-parts',
      'electronics': '/upload/electronics',
      'cameras': '/upload/cameras',
      'lighting': '/upload/lighting',
      'lightning-electrical': '/upload/electrical',
      'audio-equipment': '/upload/audio-equipment',
      'drones': '/upload/cameras',
      'media-creative': '/upload/media-creative',
      'studio-rentals': '/upload/shortlet',
      'fashion': '/upload/fashion',
      'men-fashion': '/upload/men-fashion',
      'women-fashion': '/upload/fashion',
      'accessories': '/upload/accessories',
      'beauty': '/upload/beauty-personal-care',
      'beauty-personal-care': '/upload/beauty-personal-care',
      'hair-beauty': '/upload/beauty-personal-care',
      'shoes': '/upload/fashion',
      'furniture': '/upload/furniture',
      'home-living': '/upload/furniture',
      'interior-design': '/upload/designers',
      'cleaning-services': '/upload/cleaning-services',
      'security': '/upload/cleaning-services',
      'jobs-services': '/upload/jobs',
      'photographers': '/upload/photographers',
      'videographers': '/upload/photographers',
      'editors': '/upload/designers',
      'designers': '/upload/designers',
      'performers': '/upload/performers',
      'music-entertainment': '/upload/media-creative',
      'dj-equipment': '/upload/audio-equipment',
      'stage-lights': '/upload/lighting',
      'instruments': '/upload/audio-equipment',
      'pet-store': '/upload/pet-store',
      'food-restaurants': '/food-category',
      'foodstuffs': '/upload/foodstuffs',
      'restaurants': '/upload/restaurants',
      'equipment-rental': '/upload/media-creative',
      'travel-hospitality': '/upload/shortlet',
      'hotels': '/upload/shortlet',
      'tours': '/upload/pet-store',
      'event-spaces': '/upload/commercial',
    };
    return pathMap[slug] || '/create-listing';
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex flex-col">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex-1 flex items-center justify-center px-4">
          <div className="text-center bg-white rounded-3xl shadow-2xl p-12 max-w-md">
            <Sparkles className="w-20 h-20 text-orange-500 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Sign In to Post Ads</h2>
            <p className="text-gray-600 mb-8">Create an account to start selling</p>
            <a
              href="/register"
              className="block w-full px-8 py-4 bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-xl font-bold hover:from-orange-600 hover:to-amber-600 transition-all shadow-lg"
            >
              Get Started
            </a>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-3 bg-gradient-to-r from-orange-500 to-amber-500 rounded-2xl mb-4">
            <Zap className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            What do you want to sell?
          </h1>
          <p className="text-xl text-gray-600">
            Choose a category to get started with your listing
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category) => {
              const Icon = category.icon;
              return (
                <a
                  key={category.id}
                  href={getUploadPath(category.slug)}
                  className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-2 border-transparent hover:border-orange-300"
                >
                  <div className={`w-16 h-16 bg-gradient-to-br ${category.gradient} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors">
                    {category.name}
                  </h3>
                  <p className="text-sm text-gray-600 mb-4">{category.description}</p>
                  <div className="flex items-center text-orange-600 font-semibold group-hover:gap-3 gap-2 transition-all">
                    <span>Post Now</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </a>
              );
            })}
          </div>
        )}

        <div className="mt-16 bg-white rounded-3xl shadow-xl p-8 border-2 border-orange-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Quick & Easy</h3>
              <p className="text-gray-600 text-sm">
                Post your ad in minutes with our guided process
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Reach Thousands</h3>
              <p className="text-gray-600 text-sm">
                Get your listing in front of millions of buyers
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Secure & Safe</h3>
              <p className="text-gray-600 text-sm">
                Verified buyers and secure payment options
              </p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};
