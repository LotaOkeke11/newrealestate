import { useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Sparkles, Upload, X, ArrowLeft, Check } from 'lucide-react';

type BeautyCategory =
  | 'Hair Salon Services'
  | 'Wigs & Extensions'
  | 'Makeup Services'
  | 'Makeup Products'
  | 'Skincare Products'
  | 'Perfumes & Fragrances'
  | 'Spa & Wellness';

type ServiceType = 'product' | 'service';

export const UploadBeautyPage = () => {
  const { user } = useAuth();

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    window.dispatchEvent(new PopStateEvent('popstate'));
  };
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);

  const [formData, setFormData] = useState({
    serviceType: 'product' as ServiceType,
    beautyCategory: '' as BeautyCategory | '',
    title: '',
    description: '',
    price: '',
    brandName: '',
    condition: 'New',
    ingredients: '',
    volume: '',
    productType: '',
    skinType: '',
    hairType: '',
    shadeColor: '',
    scentProfile: '',
    certifications: [] as string[],
    expiryDate: '',
    batchNumber: '',
    businessName: '',
    location: '',
    serviceArea: '',
    yearsExperience: '',
    specializations: [] as string[],
    operatingHours: '',
    appointmentRequired: false,
    homeService: false,
    portfolioLinks: '',
    contactPhone: '',
    contactEmail: '',
    images: [] as File[],
  });

  const beautyCategories = [
    { value: 'Hair Salon Services', label: 'Hair Salon Services', icon: '💇' },
    { value: 'Wigs & Extensions', label: 'Wigs & Extensions', icon: '👩‍🦱' },
    { value: 'Makeup Services', label: 'Makeup Services', icon: '💄' },
    { value: 'Makeup Products', label: 'Makeup Products', icon: '💋' },
    { value: 'Skincare Products', label: 'Skincare Products', icon: '🧴' },
    { value: 'Perfumes & Fragrances', label: 'Perfumes & Fragrances', icon: '🌸' },
    { value: 'Spa & Wellness', label: 'Spa & Wellness', icon: '🧖' },
  ];

  const conditions = ['New', 'Like New', 'Gently Used', 'Opened/Tested'];

  const skinTypes = ['All Skin Types', 'Oily', 'Dry', 'Combination', 'Sensitive', 'Normal', 'Mature'];
  const hairTypes = ['All Hair Types', 'Straight', 'Wavy', 'Curly', 'Coily', 'Fine', 'Thick', 'Color-Treated'];

  const certifications = [
    'FDA Approved',
    'Cruelty-Free',
    'Vegan',
    'Organic',
    'Halal Certified',
    'Dermatologist Tested',
    'Hypoallergenic',
    'Paraben-Free',
    'Sulfate-Free',
  ];

  const specializationOptions = [
    'Hair Cutting & Styling',
    'Hair Coloring',
    'Balayage/Highlights',
    'Keratin Treatment',
    'Hair Extensions',
    'Braiding',
    'Natural Hair Care',
    'Bridal Makeup',
    'Special Effects Makeup',
    'Airbrush Makeup',
    'Lash Extensions',
    'Microblading',
    'Facials',
    'Massage Therapy',
    'Nail Art',
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (formData.images.length + files.length > 8) {
      alert('Maximum 8 images allowed');
      return;
    }
    setFormData({ ...formData, images: [...formData.images, ...files] });
  };

  const removeImage = (index: number) => {
    setFormData({
      ...formData,
      images: formData.images.filter((_, i) => i !== index),
    });
  };

  const toggleCertification = (cert: string) => {
    setFormData({
      ...formData,
      certifications: formData.certifications.includes(cert)
        ? formData.certifications.filter(c => c !== cert)
        : [...formData.certifications, cert],
    });
  };

  const toggleSpecialization = (spec: string) => {
    setFormData({
      ...formData,
      specializations: formData.specializations.includes(spec)
        ? formData.specializations.filter(s => s !== spec)
        : [...formData.specializations, spec],
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      alert('Please login to post an ad');
      navigate('/login');
      return;
    }

    if (!formData.beautyCategory || !formData.title || !formData.price) {
      alert('Please fill in all required fields');
      return;
    }

    setUploading(true);

    try {
      const imageUrls: string[] = [];

      for (const image of formData.images) {
        const fileExt = image.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `${user.id}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('listing-images')
          .upload(filePath, image);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('listing-images')
          .getPublicUrl(filePath);

        imageUrls.push(publicUrl);
      }

      const listingData = {
        user_id: user.id,
        category: 'Beauty & Personal Care',
        subcategory: formData.beautyCategory,
        title: formData.title,
        description: formData.description,
        price: parseFloat(formData.price),
        condition: formData.condition,
        images: imageUrls,
        brand: formData.brandName,
        location: formData.location,
        contact_phone: formData.contactPhone,
        contact_email: formData.contactEmail,
        specifications: {
          serviceType: formData.serviceType,
          ...(formData.serviceType === 'product' ? {
            ingredients: formData.ingredients,
            volume: formData.volume,
            productType: formData.productType,
            skinType: formData.skinType,
            hairType: formData.hairType,
            shadeColor: formData.shadeColor,
            scentProfile: formData.scentProfile,
            certifications: formData.certifications,
            expiryDate: formData.expiryDate,
            batchNumber: formData.batchNumber,
          } : {
            businessName: formData.businessName,
            serviceArea: formData.serviceArea,
            yearsExperience: formData.yearsExperience,
            specializations: formData.specializations,
            operatingHours: formData.operatingHours,
            appointmentRequired: formData.appointmentRequired,
            homeService: formData.homeService,
            portfolioLinks: formData.portfolioLinks,
          }),
        },
        seller_type: 'individual',
        status: 'active',
      };

      const { error } = await supabase.from('listings').insert([listingData]);

      if (error) throw error;

      alert('Beauty listing posted successfully!');
      navigate('/');
    } catch (error) {
      console.error('Error creating listing:', error);
      alert('Failed to post listing. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50 flex flex-col">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex-1 flex items-center justify-center px-4">
          <div className="text-center bg-white rounded-3xl shadow-2xl p-12 max-w-md">
            <Sparkles className="w-20 h-20 text-pink-500 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Sign In Required</h2>
            <p className="text-gray-600 mb-8 text-lg">Please sign in to post your beauty listing</p>
            <a
              href="/login"
              className="block w-full px-8 py-4 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-xl font-bold hover:from-pink-600 hover:to-rose-600 transition-all shadow-lg"
            >
              Sign In
            </a>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1 max-w-5xl mx-auto px-4 py-8 w-full">
        <button
          onClick={() => navigate('/post-ad')}
          className="flex items-center gap-2 text-pink-600 hover:text-pink-700 font-semibold mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Categories
        </button>

        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-pink-500 via-rose-500 to-purple-500 p-8 text-white">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                <Sparkles className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">Post Beauty Listing</h1>
                <p className="text-pink-100 mt-1">Share your beauty products or services</p>
              </div>
            </div>

            <div className="flex items-center gap-2 mt-6">
              {[1, 2, 3].map((step) => (
                <div key={step} className="flex items-center flex-1">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                      currentStep >= step
                        ? 'bg-white text-pink-500'
                        : 'bg-white/30 text-white'
                    }`}
                  >
                    {currentStep > step ? <Check className="w-5 h-5" /> : step}
                  </div>
                  {step < 3 && (
                    <div
                      className={`flex-1 h-1 mx-2 rounded transition-all ${
                        currentStep > step ? 'bg-white' : 'bg-white/30'
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
            <div className="flex justify-between mt-2 text-sm text-pink-100">
              <span>Type & Category</span>
              <span>Details</span>
              <span>Images & Contact</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="p-8">
            {currentStep === 1 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-gray-900 mb-3">
                    Listing Type <span className="text-pink-500">*</span>
                  </label>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { value: 'product', label: 'Product', desc: 'Sell beauty products' },
                      { value: 'service', label: 'Service', desc: 'Offer beauty services' },
                    ].map((type) => (
                      <button
                        key={type.value}
                        type="button"
                        onClick={() => setFormData({ ...formData, serviceType: type.value as ServiceType })}
                        className={`p-6 rounded-2xl border-2 transition-all text-left ${
                          formData.serviceType === type.value
                            ? 'border-pink-500 bg-pink-50 shadow-lg'
                            : 'border-gray-200 hover:border-pink-300'
                        }`}
                      >
                        <div className="font-bold text-gray-900 mb-1">{type.label}</div>
                        <div className="text-sm text-gray-600">{type.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-900 mb-3">
                    Beauty Category <span className="text-pink-500">*</span>
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {beautyCategories.map((cat) => (
                      <button
                        key={cat.value}
                        type="button"
                        onClick={() => setFormData({ ...formData, beautyCategory: cat.value as BeautyCategory })}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          formData.beautyCategory === cat.value
                            ? 'border-pink-500 bg-pink-50 shadow-md'
                            : 'border-gray-200 hover:border-pink-300'
                        }`}
                      >
                        <div className="text-3xl mb-2">{cat.icon}</div>
                        <div className="text-sm font-bold text-gray-900">{cat.label}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    disabled={!formData.beautyCategory}
                    className="px-8 py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-xl font-bold hover:from-pink-600 hover:to-rose-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg"
                  >
                    Continue
                  </button>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-gray-900 mb-2">
                    Title <span className="text-pink-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="e.g., Professional Hair Cutting Service or Luxury Face Cream"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-900 mb-2">
                    Description <span className="text-pink-500">*</span>
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe your beauty product or service in detail..."
                    rows={5}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all resize-none"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-2">
                      Price (₦) <span className="text-pink-500">*</span>
                    </label>
                    <input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      placeholder="0.00"
                      step="0.01"
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-2">
                      {formData.serviceType === 'product' ? 'Brand Name' : 'Business Name'}
                    </label>
                    <input
                      type="text"
                      value={formData.serviceType === 'product' ? formData.brandName : formData.businessName}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          [formData.serviceType === 'product' ? 'brandName' : 'businessName']: e.target.value,
                        })
                      }
                      placeholder={formData.serviceType === 'product' ? 'e.g., Nivea, MAC' : 'e.g., Glamour Salon'}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                    />
                  </div>
                </div>

                {formData.serviceType === 'product' ? (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-bold text-gray-900 mb-2">Condition</label>
                        <select
                          value={formData.condition}
                          onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
                          className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                        >
                          {conditions.map((cond) => (
                            <option key={cond} value={cond}>
                              {cond}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-bold text-gray-900 mb-2">
                          Volume/Size
                        </label>
                        <input
                          type="text"
                          value={formData.volume}
                          onChange={(e) => setFormData({ ...formData, volume: e.target.value })}
                          placeholder="e.g., 50ml, 100g"
                          className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {(formData.beautyCategory === 'Skincare Products' || formData.beautyCategory === 'Makeup Products') && (
                        <div>
                          <label className="block text-sm font-bold text-gray-900 mb-2">Skin Type</label>
                          <select
                            value={formData.skinType}
                            onChange={(e) => setFormData({ ...formData, skinType: e.target.value })}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                          >
                            <option value="">Select skin type</option>
                            {skinTypes.map((type) => (
                              <option key={type} value={type}>
                                {type}
                              </option>
                            ))}
                          </select>
                        </div>
                      )}

                      {(formData.beautyCategory === 'Wigs & Extensions' || formData.beautyCategory === 'Hair Salon Services') && (
                        <div>
                          <label className="block text-sm font-bold text-gray-900 mb-2">Hair Type</label>
                          <select
                            value={formData.hairType}
                            onChange={(e) => setFormData({ ...formData, hairType: e.target.value })}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                          >
                            <option value="">Select hair type</option>
                            {hairTypes.map((type) => (
                              <option key={type} value={type}>
                                {type}
                              </option>
                            ))}
                          </select>
                        </div>
                      )}

                      {formData.beautyCategory === 'Makeup Products' && (
                        <div>
                          <label className="block text-sm font-bold text-gray-900 mb-2">Shade/Color</label>
                          <input
                            type="text"
                            value={formData.shadeColor}
                            onChange={(e) => setFormData({ ...formData, shadeColor: e.target.value })}
                            placeholder="e.g., Ruby Red, Natural Beige"
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                          />
                        </div>
                      )}

                      {formData.beautyCategory === 'Perfumes & Fragrances' && (
                        <div>
                          <label className="block text-sm font-bold text-gray-900 mb-2">Scent Profile</label>
                          <input
                            type="text"
                            value={formData.scentProfile}
                            onChange={(e) => setFormData({ ...formData, scentProfile: e.target.value })}
                            placeholder="e.g., Floral, Woody, Citrus"
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                          />
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-2">Key Ingredients</label>
                      <textarea
                        value={formData.ingredients}
                        onChange={(e) => setFormData({ ...formData, ingredients: e.target.value })}
                        placeholder="List main ingredients..."
                        rows={3}
                        className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all resize-none"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">
                        Certifications & Claims
                      </label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {certifications.map((cert) => (
                          <button
                            key={cert}
                            type="button"
                            onClick={() => toggleCertification(cert)}
                            className={`p-3 rounded-xl border-2 transition-all text-sm font-semibold ${
                              formData.certifications.includes(cert)
                                ? 'border-pink-500 bg-pink-50 text-pink-700'
                                : 'border-gray-200 text-gray-700 hover:border-pink-300'
                            }`}
                          >
                            {cert}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-bold text-gray-900 mb-2">Expiry Date</label>
                        <input
                          type="date"
                          value={formData.expiryDate}
                          onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                          className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-bold text-gray-900 mb-2">Batch/Lot Number</label>
                        <input
                          type="text"
                          value={formData.batchNumber}
                          onChange={(e) => setFormData({ ...formData, batchNumber: e.target.value })}
                          placeholder="For product verification"
                          className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                        />
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-bold text-gray-900 mb-2">Service Area</label>
                        <input
                          type="text"
                          value={formData.serviceArea}
                          onChange={(e) => setFormData({ ...formData, serviceArea: e.target.value })}
                          placeholder="e.g., Lagos, Abuja"
                          className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-bold text-gray-900 mb-2">Years of Experience</label>
                        <input
                          type="number"
                          value={formData.yearsExperience}
                          onChange={(e) => setFormData({ ...formData, yearsExperience: e.target.value })}
                          placeholder="0"
                          className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-3">Specializations</label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {specializationOptions.map((spec) => (
                          <button
                            key={spec}
                            type="button"
                            onClick={() => toggleSpecialization(spec)}
                            className={`p-3 rounded-xl border-2 transition-all text-sm font-semibold ${
                              formData.specializations.includes(spec)
                                ? 'border-pink-500 bg-pink-50 text-pink-700'
                                : 'border-gray-200 text-gray-700 hover:border-pink-300'
                            }`}
                          >
                            {spec}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-2">Operating Hours</label>
                      <input
                        type="text"
                        value={formData.operatingHours}
                        onChange={(e) => setFormData({ ...formData, operatingHours: e.target.value })}
                        placeholder="e.g., Mon-Sat 9AM-6PM"
                        className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                      />
                    </div>

                    <div className="flex flex-wrap gap-6">
                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.appointmentRequired}
                          onChange={(e) =>
                            setFormData({ ...formData, appointmentRequired: e.target.checked })
                          }
                          className="w-5 h-5 text-pink-500 border-2 border-gray-300 rounded focus:ring-2 focus:ring-pink-200"
                        />
                        <span className="text-sm font-semibold text-gray-700">Appointment Required</span>
                      </label>

                      <label className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.homeService}
                          onChange={(e) => setFormData({ ...formData, homeService: e.target.checked })}
                          className="w-5 h-5 text-pink-500 border-2 border-gray-300 rounded focus:ring-2 focus:ring-pink-200"
                        />
                        <span className="text-sm font-semibold text-gray-700">Home Service Available</span>
                      </label>
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-900 mb-2">Portfolio Links</label>
                      <textarea
                        value={formData.portfolioLinks}
                        onChange={(e) => setFormData({ ...formData, portfolioLinks: e.target.value })}
                        placeholder="Instagram, Facebook, Website links (one per line)"
                        rows={3}
                        className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all resize-none"
                      />
                    </div>
                  </>
                )}

                <div className="flex gap-4 pt-4">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(1)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(3)}
                    className="flex-1 px-8 py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-xl font-bold hover:from-pink-600 hover:to-rose-600 transition-all shadow-lg"
                  >
                    Continue
                  </button>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-gray-900 mb-3">
                    Upload Images <span className="text-pink-500">* (Max 8)</span>
                  </label>
                  <div className="border-2 border-dashed border-pink-300 rounded-2xl p-8 text-center hover:border-pink-500 transition-all bg-pink-50/50">
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      id="image-upload"
                    />
                    <label htmlFor="image-upload" className="cursor-pointer">
                      <Upload className="w-12 h-12 text-pink-500 mx-auto mb-3" />
                      <p className="text-gray-900 font-semibold mb-1">Click to upload images</p>
                      <p className="text-sm text-gray-600">PNG, JPG up to 10MB each</p>
                    </label>
                  </div>

                  {formData.images.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                      {formData.images.map((image, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={URL.createObjectURL(image)}
                            alt={`Preview ${index + 1}`}
                            className="w-full h-32 object-cover rounded-xl"
                          />
                          <button
                            type="button"
                            onClick={() => removeImage(index)}
                            className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-all hover:bg-red-600"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-2">
                      Location <span className="text-pink-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="City, State"
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-2">Contact Phone</label>
                    <input
                      type="tel"
                      value={formData.contactPhone}
                      onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                      placeholder="+234 xxx xxx xxxx"
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-900 mb-2">Contact Email</label>
                  <input
                    type="email"
                    value={formData.contactEmail}
                    onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                    placeholder="your@email.com"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
                  />
                </div>

                <div className="bg-pink-50 border-2 border-pink-200 rounded-2xl p-6">
                  <h3 className="font-bold text-gray-900 mb-2">Safety Tips</h3>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li>• For products: Always check expiry dates and authenticity</li>
                    <li>• For services: Verify certifications and qualifications</li>
                    <li>• Meet in safe, public locations for transactions</li>
                    <li>• Never share sensitive personal information</li>
                  </ul>
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={uploading || formData.images.length === 0}
                    className="flex-1 px-8 py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-xl font-bold hover:from-pink-600 hover:to-rose-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg flex items-center justify-center gap-2"
                  >
                    {uploading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Posting...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        Post Beauty Listing
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
};
