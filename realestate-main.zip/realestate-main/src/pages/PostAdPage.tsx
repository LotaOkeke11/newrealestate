import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  Home, Car, Laptop, UtensilsCrossed, Package, Armchair,
  PawPrint, ShoppingBag, Wrench, Lightbulb, Scissors, ChevronRight,
  Search, TrendingUp, Sparkles, AlertCircle, Zap, Camera, Film
} from 'lucide-react';

type Category = {
  id: string;
  name: string;
  slug: string;
  icon: string | null;
};

export const PostAdPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    const { data } = await supabase
      .from('categories')
      .select('id, name, slug, icon')
      .is('parent_id', null)
      .order('order_index');

    if (data) {
      setCategories(data);
    }
  };

  const getCategoryIcon = (slug: string) => {
    const icons: { [key: string]: any } = {
      'real-estate': Home,
      'cars-vehicles': Car,
      'electronics': Laptop,
      'food-restaurants': UtensilsCrossed,
      'equipment-rental': Package,
      'furniture': Armchair,
      'pet-store': PawPrint,
      'fashion': ShoppingBag,
      'car-parts': Wrench,
      'lightning-electrical': Lightbulb,
      'hair-beauty': Scissors,
      'cameras': Camera,
      'media-creative': Film,
    };
    return icons[slug] || ShoppingBag;
  };

  const handleCategoryClick = (slug: string) => {
    if (slug === 'real-estate') {
      window.location.href = '/list-property';
    } else if (slug === 'cameras') {
      window.location.href = '/upload/cameras';
    } else if (slug === 'media-creative') {
      window.location.href = '/upload/media-creative';
    } else if (slug === 'electronics') {
      window.location.href = '/upload/electronics';
    } else {
      window.location.href = '/create-listing';
    }
  };

  const filteredCategories = categories.filter(cat =>
    cat.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const popularCategories = ['real-estate', 'cars-vehicles', 'electronics', 'fashion'];

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex items-center justify-center min-h-[60vh] px-4">
          <div className="text-center bg-white rounded-3xl shadow-2xl p-12 max-w-md">
            <AlertCircle className="w-20 h-20 text-amber-500 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Sign In Required</h2>
            <p className="text-gray-600 mb-8 text-lg">Create an account to start selling your items</p>
            <div className="space-y-3">
              <a href="/register" className="block w-full px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-bold hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg">
                Create Account
              </a>
              <a href="/login" className="block w-full px-8 py-4 border-2 border-amber-300 text-amber-700 rounded-xl font-bold hover:bg-amber-50 transition-all">
                Sign In
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-xl">
              <Sparkles className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">Post Your Ad</h1>
              <p className="text-gray-600 text-lg">Choose a category to get started</p>
            </div>
          </div>
        </div>

        <div className="mb-8 bg-white/95 backdrop-blur-lg rounded-2xl shadow-xl border-2 border-amber-200/50 p-6">
          <div className="relative">
            <Search className="absolute left-4 top-4 w-6 h-6 text-amber-600" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search categories..."
              className="w-full pl-14 pr-4 py-4 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400 transition-colors text-lg"
            />
          </div>
        </div>

        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-6 h-6 text-amber-600" />
            <h2 className="text-2xl font-bold text-gray-900">Popular Categories</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {categories
              .filter(cat => popularCategories.includes(cat.slug))
              .map((category) => {
                const Icon = getCategoryIcon(category.slug);
                return (
                  <button
                    key={category.id}
                    onClick={() => handleCategoryClick(category.slug)}
                    className="group relative bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl p-6 text-white hover:shadow-2xl transition-all hover:scale-105 overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-white/0 to-white/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="relative z-10">
                      <Icon className="w-10 h-10 mb-3" />
                      <h3 className="font-bold text-lg">{category.name}</h3>
                      <ChevronRight className="w-5 h-5 absolute right-4 bottom-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </button>
                );
              })}
          </div>
        </div>

        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-6 h-6 text-amber-600" />
            <h2 className="text-2xl font-bold text-gray-900">All Categories</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCategories.map((category) => {
              const Icon = getCategoryIcon(category.slug);
              return (
                <button
                  key={category.id}
                  onClick={() => handleCategoryClick(category.slug)}
                  className="group bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all border-2 border-amber-100 hover:border-amber-300 hover:scale-105 text-left"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl flex items-center justify-center text-white group-hover:scale-110 transition-transform shadow-lg">
                        <Icon className="w-7 h-7" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-gray-900 group-hover:text-amber-600 transition-colors">
                          {category.name}
                        </h3>
                        <p className="text-sm text-gray-500">Post your ad here</p>
                      </div>
                    </div>
                    <ChevronRight className="w-6 h-6 text-amber-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </button>
              );
            })}
          </div>

          {filteredCategories.length === 0 && (
            <div className="text-center py-12 bg-white rounded-2xl shadow-lg">
              <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">No categories found matching "{searchTerm}"</p>
            </div>
          )}
        </div>

        <div className="bg-gradient-to-r from-blue-50 to-cyan-50 border-2 border-blue-200 rounded-2xl p-8">
          <h3 className="font-bold text-blue-900 text-xl mb-4 flex items-center gap-2">
            <AlertCircle className="w-6 h-6" />
            Tips for Success
          </h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold">1</span>
              </div>
              <div>
                <h4 className="font-bold text-blue-900 mb-1">Choose the Right Category</h4>
                <p className="text-sm text-blue-700">Select the most appropriate category for better visibility</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold">2</span>
              </div>
              <div>
                <h4 className="font-bold text-blue-900 mb-1">Use Quality Photos</h4>
                <p className="text-sm text-blue-700">Clear images help buyers make informed decisions</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold">3</span>
              </div>
              <div>
                <h4 className="font-bold text-blue-900 mb-1">Write Detailed Descriptions</h4>
                <p className="text-sm text-blue-700">Include all important details and specifications</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold">4</span>
              </div>
              <div>
                <h4 className="font-bold text-blue-900 mb-1">Set Competitive Prices</h4>
                <p className="text-sm text-blue-700">Research similar items to price yours competitively</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
