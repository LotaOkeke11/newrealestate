import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { supabase } from '../lib/supabase';
import {
  Calendar,
  MapPin,
  Filter,
  ShieldCheck,
  Star,
  Clock,
  Tag,
  Home,
  Car,
  Camera,
  Package,
} from 'lucide-react';

type RentalListing = {
  id: string;
  title: string;
  price: number;
  images: string[];
  location_city: string;
  location_state: string;
  rental_duration: string;
  condition: string;
  created_at: string;
  category: {
    name: string;
    slug: string;
  };
  profile: {
    full_name: string;
  };
  verification?: {
    verification_level: number;
    status: string;
  };
};

export const RentalsPage = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [rentals, setRentals] = useState<RentalListing[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    category: '',
    location: '',
    duration: '',
    minPrice: '',
    maxPrice: '',
    verifiedOnly: false,
  });

  const [availableCategories, setAvailableCategories] = useState<{slug: string, name: string}[]>([]);

  const rentalCategories = [
    { slug: 'real-estate', name: 'Real Estate Rentals' },
    { slug: 'vehicles', name: 'Vehicle Rentals' },
    { slug: 'cameras', name: 'Camera Rentals' },
    { slug: 'equipment-rental', name: 'Equipment Rental' },
    { slug: 'media-creative', name: 'Media & Creative' },
    { slug: 'shortlets', name: 'Shortlets' },
    { slug: 'luxury-rentals', name: 'Luxury Rentals' },
    { slug: 'studio-rentals', name: 'Studio Rentals' },
  ];

  const durations = [
    { value: 'hourly', label: 'Hourly' },
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
    { value: 'monthly', label: 'Monthly' },
  ];

  const states = ['Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo', 'Kaduna'];

  useEffect(() => {
    loadRentals();
    loadAvailableCategories();
  }, []);

  useEffect(() => {
    loadRentals();
  }, [filters]);

  const loadAvailableCategories = async () => {
    const { data } = await supabase
      .from('listings')
      .select('category:categories(name, slug)')
      .eq('status', 'active')
      .eq('is_rental', true);

    if (data) {
      const uniqueCategories = Array.from(
        new Map(
          data
            .map((item: any) => item.category)
            .filter((cat: any) => cat)
            .map((cat: any) => [cat.slug, cat])
        ).values()
      ) as {slug: string, name: string}[];
      setAvailableCategories(uniqueCategories);
    }
  };

  const loadRentals = async () => {
    setLoading(true);

    let query = supabase
      .from('listings')
      .select(`
        id,
        title,
        price,
        images,
        location_city,
        location_state,
        rental_duration,
        condition,
        created_at,
        category:categories(name, slug),
        profile:profiles(full_name),
        verification:seller_verifications(verification_level, status)
      `)
      .eq('status', 'active')
      .eq('is_rental', true);

    if (filters.category) {
      query = query.eq('categories.slug', filters.category);
    }

    if (filters.duration) {
      query = query.eq('rental_duration', filters.duration);
    }

    if (filters.location) {
      query = query.eq('location_state', filters.location);
    }

    if (filters.minPrice) {
      query = query.gte('price', parseInt(filters.minPrice));
    }

    if (filters.maxPrice) {
      query = query.lte('price', parseInt(filters.maxPrice));
    }

    query = query.order('created_at', { ascending: false }).limit(50);

    const { data, error } = await query;

    if (data) {
      let results = data as any;

      if (filters.verifiedOnly) {
        results = results.filter(
          (item: any) => item.verification?.status === 'approved'
        );
      }

      setRentals(results);
    }
    setLoading(false);
  };

  const getDurationBadge = (duration: string) => {
    const colors: Record<string, string> = {
      hourly: 'bg-blue-100 text-blue-700',
      daily: 'bg-green-100 text-green-700',
      weekly: 'bg-purple-100 text-purple-700',
      monthly: 'bg-amber-100 text-amber-700',
    };
    return colors[duration] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-xl">
              <Calendar className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">All Rentals</h1>
              <p className="text-gray-600 text-lg">
                {loading ? 'Loading...' : `${rentals.length} rental listings available`}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <button
              onClick={() => setFilters({ ...filters, category: 'real-estate' })}
              className={`p-4 rounded-xl border-2 transition-all ${
                filters.category === 'real-estate'
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200 bg-white hover:border-green-300'
              }`}
            >
              <Home className={`w-8 h-8 mx-auto mb-2 ${
                filters.category === 'real-estate' ? 'text-green-600' : 'text-gray-600'
              }`} />
              <p className="text-sm font-semibold text-gray-900 text-center">Real Estate</p>
              <p className="text-xs text-gray-500 text-center">Apartments & Houses</p>
            </button>
            <button
              onClick={() => setFilters({ ...filters, category: 'vehicles' })}
              className={`p-4 rounded-xl border-2 transition-all ${
                filters.category === 'vehicles'
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200 bg-white hover:border-green-300'
              }`}
            >
              <Car className={`w-8 h-8 mx-auto mb-2 ${
                filters.category === 'vehicles' ? 'text-green-600' : 'text-gray-600'
              }`} />
              <p className="text-sm font-semibold text-gray-900 text-center">Vehicles</p>
              <p className="text-xs text-gray-500 text-center">Cars & Motorcycles</p>
            </button>
            <button
              onClick={() => setFilters({ ...filters, category: 'cameras' })}
              className={`p-4 rounded-xl border-2 transition-all ${
                filters.category === 'cameras'
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200 bg-white hover:border-green-300'
              }`}
            >
              <Camera className={`w-8 h-8 mx-auto mb-2 ${
                filters.category === 'cameras' ? 'text-green-600' : 'text-gray-600'
              }`} />
              <p className="text-sm font-semibold text-gray-900 text-center">Cameras</p>
              <p className="text-xs text-gray-500 text-center">Photo & Video</p>
            </button>
            <button
              onClick={() => setFilters({ ...filters, category: 'equipment-rental' })}
              className={`p-4 rounded-xl border-2 transition-all ${
                filters.category === 'equipment-rental'
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200 bg-white hover:border-green-300'
              }`}
            >
              <Package className={`w-8 h-8 mx-auto mb-2 ${
                filters.category === 'equipment-rental' ? 'text-green-600' : 'text-gray-600'
              }`} />
              <p className="text-sm font-semibold text-gray-900 text-center">Equipment</p>
              <p className="text-xs text-gray-500 text-center">Tools & Gear</p>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-xl p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-6">
                <Filter className="w-5 h-5 text-amber-600" />
                <h2 className="text-lg font-bold text-gray-900">Filters</h2>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Category
                  </label>
                  <select
                    value={filters.category}
                    onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                  >
                    <option value="">All Categories</option>
                    {rentalCategories.map((cat) => (
                      <option key={cat.slug} value={cat.slug}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                  {availableCategories.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {availableCategories.map((cat) => (
                        <button
                          key={cat.slug}
                          onClick={() => setFilters({ ...filters, category: cat.slug })}
                          className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
                            filters.category === cat.slug
                              ? 'bg-amber-500 text-white'
                              : 'bg-gray-100 text-gray-700 hover:bg-amber-100'
                          }`}
                        >
                          {cat.name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Duration
                  </label>
                  <select
                    value={filters.duration}
                    onChange={(e) => setFilters({ ...filters, duration: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                  >
                    <option value="">Any Duration</option>
                    {durations.map((d) => (
                      <option key={d.value} value={d.value}>
                        {d.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Location
                  </label>
                  <select
                    value={filters.location}
                    onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                  >
                    <option value="">All Locations</option>
                    {states.map((state) => (
                      <option key={state} value={state}>
                        {state}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Price Range (per day)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      placeholder="Min"
                      value={filters.minPrice}
                      onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })}
                      className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:outline-none focus:border-amber-400"
                    />
                    <input
                      type="number"
                      placeholder="Max"
                      value={filters.maxPrice}
                      onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
                      className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 bg-green-50 border-2 border-green-200 rounded-xl">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-semibold text-green-700">
                      Verified Only
                    </span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={filters.verifiedOnly}
                      onChange={(e) =>
                        setFilters({ ...filters, verifiedOnly: e.target.checked })
                      }
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                  </label>
                </div>

                <button
                  onClick={() =>
                    setFilters({
                      category: '',
                      location: '',
                      duration: '',
                      minPrice: '',
                      maxPrice: '',
                      verifiedOnly: false,
                    })
                  }
                  className="w-full py-2 border-2 border-amber-200 text-amber-700 rounded-xl font-semibold hover:bg-amber-50 transition-all"
                >
                  Clear Filters
                </button>
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <div className="text-center">
                  <div className="animate-spin w-16 h-16 border-4 border-amber-600 border-t-transparent rounded-full mx-auto mb-4"></div>
                  <p className="text-gray-600">Loading rentals...</p>
                </div>
              </div>
            ) : rentals.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
                <Calendar className="w-24 h-24 text-gray-300 mx-auto mb-6" />
                <h2 className="text-2xl font-bold text-gray-900 mb-3">No rentals found</h2>
                <p className="text-gray-600 mb-6">
                  Try adjusting your filters to see more results
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {rentals.map((rental) => (
                  <div
                    key={rental.id}
                    className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all overflow-hidden group"
                  >
                    <div className="h-48 bg-gray-100 overflow-hidden relative">
                      {rental.images && rental.images.length > 0 ? (
                        <img
                          src={rental.images[0]}
                          alt={rental.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Calendar className="w-12 h-12 text-gray-400" />
                        </div>
                      )}

                      {rental.verification?.status === 'approved' && (
                        <div className="absolute top-3 right-3">
                          <div className="px-2 py-1 bg-green-500 text-white text-xs font-bold rounded-full flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3" />
                            Verified
                          </div>
                        </div>
                      )}

                      <div className="absolute bottom-3 left-3">
                        <span
                          className={`px-3 py-1 ${getDurationBadge(
                            rental.rental_duration
                          )} text-xs font-bold rounded-full capitalize`}
                        >
                          {rental.rental_duration}
                        </span>
                      </div>
                    </div>

                    <div className="p-4">
                      <h3 className="font-bold text-gray-900 mb-2 line-clamp-2">
                        {rental.title}
                      </h3>

                      <div className="flex items-center gap-2 mb-3 text-sm text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span>
                          {rental.location_city}, {rental.location_state}
                        </span>
                      </div>

                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <p className="text-2xl font-bold text-green-600">
                            ₦{rental.price.toLocaleString()}
                          </p>
                          <p className="text-xs text-gray-500">per {rental.rental_duration}</p>
                        </div>
                        <a
                          href={`/category/${rental.category.slug}`}
                          className="px-3 py-1 bg-amber-100 text-amber-700 text-xs font-semibold rounded-full hover:bg-amber-200 transition-colors"
                        >
                          {rental.category.name}
                        </a>
                      </div>

                      <a
                        href={`/listing/${rental.id}`}
                        className="block w-full py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl font-bold text-center hover:from-green-600 hover:to-emerald-700 transition-all"
                      >
                        Book Now
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};
