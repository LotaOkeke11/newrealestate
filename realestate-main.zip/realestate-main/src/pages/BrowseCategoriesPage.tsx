import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { supabase } from '../lib/supabase';
import { ChevronRight, TrendingUp, Grid3x3 } from 'lucide-react';

type Category = {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  listing_count?: number;
};

export const BrowseCategoriesPage = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  const categoryGroups = {
    'Real Estate': ['Rent', 'Sale', 'Shortlets', 'Lands', 'Commercial'],
    'Media & Creative': ['Cameras', 'Lighting', 'Audio Equipment', 'Drones', 'Studio Rentals'],
    'Vehicles': ['Cars for Sale', 'Luxury Rentals', 'Motorcycles', 'Boats & Marine', 'Auto Parts'],
    'Music & Entertainment': ['DJ Equipment', 'Stage Lights', 'Instruments', 'Performers'],
    'Jobs & Services': ['Videographers', 'Photographers', 'Editors', 'Designers'],
    'Home & Living': ['Furniture', 'Interior Design', 'Cleaning Services', 'Security'],
    'Fashion & Lifestyle': ['Men Fashion', 'Women Fashion', 'Accessories', 'Beauty'],
    'Travel & Hospitality': ['Shortlets', 'Hotels', 'Tours', 'Event Spaces'],
  };

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('categories')
      .select('*')
      .eq('is_active', true)
      .order('name');

    if (data) {
      setCategories(data);
    }
    setLoading(false);
  };

  const getCategoryIcon = (name: string) => {
    const icons: Record<string, string> = {
      'Real Estate': '🏘️',
      'Rent': '🏠',
      'Sale': '🏡',
      'Shortlets': '🏖️',
      'Lands': '🌄',
      'Commercial': '🏢',
      'Media & Creative': '📷',
      'Cameras': '📸',
      'Lighting': '💡',
      'Audio Equipment': '🎤',
      'Drones': '🚁',
      'Studio Rentals': '🎬',
      'Vehicles': '🚗',
      'Cars for Sale': '🚙',
      'Luxury Rentals': '🏎️',
      'Motorcycles': '🏍️',
      'Boats & Marine': '⛵',
      'Auto Parts': '🔧',
      'Music & Entertainment': '🎵',
      'DJ Equipment': '🎧',
      'Stage Lights': '✨',
      'Instruments': '🎸',
      'Performers': '🎭',
      'Jobs & Services': '💼',
      'Videographers': '🎥',
      'Photographers': '📷',
      'Editors': '✂️',
      'Designers': '🎨',
      'Home & Living': '🏠',
      'Furniture': '🛋️',
      'Interior Design': '🖼️',
      'Cleaning Services': '🧹',
      'Security': '🔒',
      'Fashion & Lifestyle': '👗',
      'Men Fashion': '👔',
      'Women Fashion': '👠',
      'Accessories': '👜',
      'Beauty': '💄',
      'Travel & Hospitality': '✈️',
      'Hotels': '🏨',
      'Tours': '🗺️',
      'Event Spaces': '🎪',
    };
    return icons[name] || '📦';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-xl">
              <Grid3x3 className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">Browse Categories</h1>
              <p className="text-gray-600 text-lg">Explore all available categories and subcategories</p>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="animate-spin w-16 h-16 border-4 border-amber-600 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-gray-600">Loading categories...</p>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            {Object.entries(categoryGroups).map(([mainCategory, subcategories]) => (
              <div key={mainCategory} className="bg-white rounded-3xl shadow-xl p-8">
                <div className="flex items-center gap-3 mb-6">
                  <span className="text-4xl">{getCategoryIcon(mainCategory)}</span>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{mainCategory}</h2>
                    <p className="text-gray-600 text-sm">
                      {subcategories.length} subcategories available
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                  {subcategories.map((subcat) => {
                    const category = categories.find((c) => c.name === subcat);
                    return (
                      <a
                        key={subcat}
                        href={`/category/${category?.slug || subcat.toLowerCase().replace(/ /g, '-')}`}
                        className="group p-4 bg-gradient-to-br from-amber-50 to-orange-50 hover:from-amber-100 hover:to-orange-100 rounded-2xl border-2 border-amber-200 hover:border-amber-400 transition-all hover:shadow-lg"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <span className="text-3xl">{getCategoryIcon(subcat)}</span>
                          <ChevronRight className="w-5 h-5 text-amber-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                        <h3 className="font-bold text-gray-900 mb-1">{subcat}</h3>
                        <p className="text-xs text-gray-600">
                          {category?.listing_count || 0} listings
                        </p>
                      </a>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-12 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 rounded-3xl shadow-2xl p-8 text-white">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex-1">
              <h2 className="text-3xl font-bold mb-2">Can't Find What You're Looking For?</h2>
              <p className="text-amber-100 text-lg">
                Post a request and let sellers come to you!
              </p>
            </div>
            <a
              href="/post-ad"
              className="px-8 py-4 bg-white text-amber-600 rounded-2xl font-bold hover:bg-gray-100 transition-all shadow-lg flex items-center gap-2 whitespace-nowrap"
            >
              <TrendingUp className="w-6 h-6" />
              Post an Ad
            </a>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};
