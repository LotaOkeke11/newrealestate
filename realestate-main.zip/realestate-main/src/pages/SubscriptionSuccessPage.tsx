import { useEffect, useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { CheckCircle2, Loader2, XCircle } from 'lucide-react';

export const SubscriptionSuccessPage = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('Processing your subscription...');

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session_id');

    if (!sessionId) {
      setStatus('error');
      setMessage('Invalid session. Please try again.');
      return;
    }

    setTimeout(() => {
      setStatus('success');
      setMessage('Your subscription is now active!');

      setTimeout(() => {
        window.location.href = '/dashboard';
      }, 3000);
    }, 2000);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="bg-white rounded-3xl shadow-2xl p-12 text-center">
          {status === 'loading' && (
            <>
              <Loader2 className="w-24 h-24 text-amber-500 mx-auto mb-6 animate-spin" />
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                Processing Payment
              </h1>
              <p className="text-gray-600 text-lg">{message}</p>
            </>
          )}

          {status === 'success' && (
            <>
              <CheckCircle2 className="w-24 h-24 text-green-500 mx-auto mb-6 animate-bounce" />
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                Subscription Activated!
              </h1>
              <p className="text-gray-600 text-lg mb-6">{message}</p>
              <p className="text-sm text-gray-500">
                Redirecting to your dashboard...
              </p>
            </>
          )}

          {status === 'error' && (
            <>
              <XCircle className="w-24 h-24 text-red-500 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                Something Went Wrong
              </h1>
              <p className="text-gray-600 text-lg mb-6">{message}</p>
              <a
                href="/subscription"
                className="inline-block px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-bold hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg"
              >
                Back to Plans
              </a>
            </>
          )}
        </div>
      </main>
    </div>
  );
};
