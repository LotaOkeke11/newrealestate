import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import {
  TrendingUp, Eye, Heart, Share2, Plus, Edit, Trash2,
  BarChart3, Package, DollarSign, MapPin, Clock
} from 'lucide-react';

type Listing = {
  id: string;
  title: string;
  price: number;
  views?: number;
  images: string[];
  status: string;
  location_city?: string;
  location_state?: string;
  created_at: string;
  categories?: {
    name: string;
  };
};

export const ImprovedSellerDashboard = () => {
  const { profile, user } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'listings'>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadListings();
    }
  }, [user]);

  const loadListings = async () => {
    if (!user) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('listings')
      .select(`
        *,
        categories(name)
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (data) {
      setListings(data);
    }
    setLoading(false);
  };

  const handleDelete = async (listingId: string) => {
    if (!confirm('Are you sure you want to delete this listing? This action cannot be undone.')) return;

    const { error } = await supabase
      .from('listings')
      .update({ status: 'deleted' })
      .eq('id', listingId)
      .eq('user_id', user!.id);

    if (!error) {
      setListings(listings.filter(l => l.id !== listingId));
      alert('Listing deleted successfully');
    } else {
      alert('Failed to delete listing. Please try again.');
    }
  };

  const handleEdit = (listingId: string) => {
    window.location.href = `/edit-listing/${listingId}`;
  };

  const stats = {
    totalListings: listings.filter(l => l.status === 'active').length,
    totalViews: listings.reduce((sum, l) => sum + (l.views || 0), 0),
    pendingListings: listings.filter(l => l.status === 'pending').length,
    avgPrice: listings.length > 0
      ? listings.reduce((sum, l) => sum + Number(l.price), 0) / listings.length
      : 0,
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const getListingImage = (listing: Listing) => {
    if (listing.images && listing.images.length > 0 && listing.images[0]) {
      return listing.images[0];
    }
    return 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=200';
  };

  const getListingLocation = (listing: Listing) => {
    if (listing.location_city && listing.location_state) {
      return `${listing.location_city}, ${listing.location_state}`;
    }
    if (listing.location_city) return listing.location_city;
    if (listing.location_state) return listing.location_state;
    return 'Nigeria';
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <p className="text-gray-600 mb-4">Please sign in to access your dashboard</p>
            <a href="/login" className="px-6 py-3 bg-amber-600 text-white rounded-lg font-semibold hover:bg-amber-700">
              Sign In
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-1">Welcome back, {profile?.full_name}</p>
          </div>
          <a
            href="/post-ad"
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-lg font-semibold hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg"
          >
            <Plus className="w-5 h-5" />
            New Listing
          </a>
        </div>

        <div className="flex gap-2 mb-6 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-6 py-3 font-semibold transition-colors ${
              activeTab === 'overview'
                ? 'text-amber-600 border-b-2 border-amber-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <BarChart3 className="w-4 h-4 inline mr-2" />
            Overview
          </button>
          <button
            onClick={() => setActiveTab('listings')}
            className={`px-6 py-3 font-semibold transition-colors ${
              activeTab === 'listings'
                ? 'text-amber-600 border-b-2 border-amber-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Package className="w-4 h-4 inline mr-2" />
            My Listings
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full"></div>
          </div>
        ) : (
          <>
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                    <div className="flex items-center justify-between mb-2">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Package className="w-6 h-6 text-blue-600" />
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{stats.totalListings}</p>
                    <p className="text-sm text-gray-600">Active Listings</p>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                    <div className="flex items-center justify-between mb-2">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <Eye className="w-6 h-6 text-purple-600" />
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{stats.totalViews.toLocaleString()}</p>
                    <p className="text-sm text-gray-600">Total Views</p>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                    <div className="flex items-center justify-between mb-2">
                      <div className="p-2 bg-orange-100 rounded-lg">
                        <Clock className="w-6 h-6 text-orange-600" />
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{stats.pendingListings}</p>
                    <p className="text-sm text-gray-600">Pending Review</p>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                    <div className="flex items-center justify-between mb-2">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <DollarSign className="w-6 h-6 text-green-600" />
                      </div>
                      <span className="text-sm text-gray-600 font-semibold">Avg</span>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{formatPrice(stats.avgPrice)}</p>
                    <p className="text-sm text-gray-600">Average Price</p>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                  <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Listings</h2>
                  {listings.length === 0 ? (
                    <div className="text-center py-12">
                      <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-600 mb-4">You haven't posted any listings yet</p>
                      <a
                        href="/post-ad"
                        className="inline-flex items-center gap-2 px-6 py-3 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors"
                      >
                        <Plus className="w-5 h-5" />
                        Create Your First Listing
                      </a>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {listings.slice(0, 5).map((listing) => (
                        <div
                          key={listing.id}
                          className="flex items-center gap-4 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                        >
                          <img
                            src={getListingImage(listing)}
                            alt={listing.title}
                            className="w-16 h-16 rounded-lg object-cover"
                          />
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900">{listing.title}</h3>
                            <p className="text-sm text-gray-600">
                              {listing.categories?.name || 'Uncategorized'}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-amber-600">{formatPrice(Number(listing.price))}</p>
                            <div className="flex items-center gap-1 text-sm text-gray-600 mt-1">
                              <MapPin className="w-3 h-3" />
                              <span>{getListingLocation(listing)}</span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleEdit(listing.id)}
                              className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(listing.id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'listings' && (
              <div className="space-y-4">
                {listings.length === 0 ? (
                  <div className="bg-white rounded-xl shadow-sm p-12 text-center">
                    <Package className="w-20 h-20 text-gray-300 mx-auto mb-4" />
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">No listings yet</h2>
                    <p className="text-gray-600 mb-6">Start selling by creating your first listing</p>
                    <a
                      href="/post-ad"
                      className="inline-flex items-center gap-2 px-8 py-4 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors font-semibold"
                    >
                      <Plus className="w-5 h-5" />
                      Create Listing
                    </a>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {listings.map((listing) => (
                      <div
                        key={listing.id}
                        className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100 hover:shadow-md transition-all"
                      >
                        <div className="relative h-48">
                          <img
                            src={getListingImage(listing)}
                            alt={listing.title}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute top-2 right-2">
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-semibold ${
                                listing.status === 'active'
                                  ? 'bg-green-500 text-white'
                                  : listing.status === 'pending'
                                  ? 'bg-yellow-500 text-white'
                                  : 'bg-gray-500 text-white'
                              }`}
                            >
                              {listing.status}
                            </span>
                          </div>
                        </div>
                        <div className="p-4">
                          <h3 className="font-bold text-gray-900 text-lg mb-2 line-clamp-1">
                            {listing.title}
                          </h3>
                          <p className="text-amber-600 font-bold text-xl mb-2">
                            {formatPrice(Number(listing.price))}
                          </p>
                          <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                            <MapPin className="w-4 h-4" />
                            <span>{getListingLocation(listing)}</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
                            <Clock className="w-3 h-3" />
                            <span>
                              {new Date(listing.created_at).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleEdit(listing.id)}
                              className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                            >
                              <Edit className="w-4 h-4" />
                              Edit
                            </button>
                            <button
                              onClick={() => handleDelete(listing.id)}
                              className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                              Delete
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
