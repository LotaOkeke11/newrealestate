import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import {
  Armchair, Upload, X, AlertCircle, CheckCircle, Sofa,
  Bed, UtensilsCrossed, BookOpen, Lamp, Plus, Trash2,
  Ruler, Package, Palette, Award, Sparkles, ShoppingBag
} from 'lucide-react';

const FURNITURE_CATEGORIES = [
  { value: 'Living Room', icon: Sofa, subcategories: ['Sofas & Couches', 'Coffee Tables', 'TV Stands', 'Recliners', 'Side Tables', 'Entertainment Units'] },
  { value: 'Bedroom', icon: Bed, subcategories: ['Bed Frames', 'Mattresses', 'Wardrobes', 'Dressers', 'Nightstands', 'Vanity Tables'] },
  { value: 'Dining', icon: UtensilsCrossed, subcategories: ['Dining Tables', 'Dining Chairs', 'Bar Stools', 'Buffets', 'China Cabinets', 'Serving Carts'] },
  { value: 'Office', icon: BookOpen, subcategories: ['Office Desks', 'Office Chairs', 'Bookshelves', 'Filing Cabinets', 'Computer Tables', 'Conference Tables'] },
  { value: 'Outdoor', icon: Lamp, subcategories: ['Patio Sets', 'Garden Chairs', 'Outdoor Tables', 'Sun Loungers', 'Swings', 'Garden Benches'] },
  { value: 'Storage', icon: Package, subcategories: ['Shelving Units', 'Cabinets', 'Storage Boxes', 'Shoe Racks', 'Display Cases', 'Organizers'] },
  { value: 'Seating', icon: Armchair, subcategories: ['Chairs', 'Benches', 'Ottomans', 'Poufs', 'Bean Bags', 'Stools'] },
];

const MATERIALS = [
  'Wood', 'Metal', 'Glass', 'Plastic', 'Leather', 'Fabric',
  'Rattan', 'Wicker', 'Marble', 'Granite', 'Bamboo', 'MDF',
  'Plywood', 'Stainless Steel', 'Aluminum', 'Upholstered'
];

const WOOD_TYPES = [
  'Oak', 'Mahogany', 'Teak', 'Pine', 'Walnut', 'Cherry',
  'Maple', 'Birch', 'Ash', 'Cedar', 'Rosewood', 'Engineered Wood'
];

const COLORS = [
  'White', 'Black', 'Brown', 'Gray', 'Beige', 'Cream',
  'Natural Wood', 'Dark Wood', 'Light Wood', 'Red', 'Blue',
  'Green', 'Yellow', 'Multi-Color', 'Metallic', 'Gold', 'Silver'
];

const STYLES = [
  'Modern', 'Contemporary', 'Traditional', 'Rustic', 'Industrial',
  'Scandinavian', 'Mid-Century', 'Vintage', 'Minimalist', 'Classic',
  'Colonial', 'Farmhouse', 'Art Deco', 'Bohemian', 'Coastal'
];

const CONDITIONS = ['Brand New', 'Like New', 'Excellent', 'Good', 'Fair'];

const ASSEMBLY_OPTIONS = ['Fully Assembled', 'Assembly Required', 'Partially Assembled'];

export const UploadFurniturePage = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    category: '',
    subcategory: '',
    title: '',
    description: '',
    brand: '',
    condition: 'Brand New',
    price: '',
    negotiable: true,
    material: '',
    woodType: '',
    color: '',
    style: '',
    length: '',
    width: '',
    height: '',
    weight: '',
    seatHeight: '',
    numberOfSeats: '',
    numberOfPieces: '1',
    assemblyRequired: 'Fully Assembled',
    careInstructions: '',
    warranty: '',
    warrantyPeriod: '',
    location_city: '',
    location_state: '',
    delivery_available: false,
    deliveryFee: '',
    installation_available: false,
    installationFee: '',
    custom_order_available: false,
  });

  const [additionalFeatures, setAdditionalFeatures] = useState<string[]>([]);
  const [images, setImages] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);

  const FEATURES_LIST = [
    'Adjustable Height',
    'Swivel Base',
    'Reclining Function',
    'Storage Compartment',
    'Extendable',
    'Foldable',
    'Stackable',
    'Weather Resistant',
    'Scratch Resistant',
    'Water Resistant',
    'Stain Resistant',
    'UV Protected',
    'Eco-Friendly',
    'Handcrafted',
    'Imported',
    'Locally Made',
    'Cushioned',
    'Ergonomic Design',
    'Easy to Clean',
    'Space Saving'
  ];

  const handleFeatureToggle = (feature: string) => {
    if (additionalFeatures.includes(feature)) {
      setAdditionalFeatures(additionalFeatures.filter(f => f !== feature));
    } else {
      setAdditionalFeatures([...additionalFeatures, feature]);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (images.length + files.length > 10) {
      setError('Maximum 10 images allowed');
      return;
    }

    setImages([...images, ...files]);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviews(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
    setPreviews(previews.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setError('Please login to post a listing');
      return;
    }

    if (images.length === 0) {
      setError('Please upload at least one image');
      return;
    }

    setUploading(true);
    setError('');

    try {
      const imageUrls: string[] = [];

      for (const image of images) {
        const fileExt = image.name.split('.').pop();
        const fileName = `${user.id}/${Date.now()}_${Math.random()}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from('listings')
          .upload(fileName, image);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('listings')
          .getPublicUrl(fileName);

        imageUrls.push(publicUrl);
      }

      const { error: insertError } = await supabase
        .from('listings')
        .insert({
          user_id: user.id,
          category_id: (await supabase.from('categories').select('id').eq('slug', 'home-garden').single()).data?.id,
          title: formData.title,
          description: formData.description,
          price: parseFloat(formData.price),
          currency: 'NGN',
          images: imageUrls,
          location_city: formData.location_city,
          location_state: formData.location_state,
          metadata: {
            furniture_category: formData.category,
            subcategory: formData.subcategory,
            brand: formData.brand,
            condition: formData.condition,
            negotiable: formData.negotiable,
            material: formData.material,
            wood_type: formData.woodType,
            color: formData.color,
            style: formData.style,
            dimensions: {
              length: formData.length,
              width: formData.width,
              height: formData.height,
              weight: formData.weight,
              seat_height: formData.seatHeight
            },
            number_of_seats: formData.numberOfSeats,
            number_of_pieces: formData.numberOfPieces,
            assembly_required: formData.assemblyRequired,
            care_instructions: formData.careInstructions,
            warranty: formData.warranty,
            warranty_period: formData.warrantyPeriod,
            delivery_available: formData.delivery_available,
            delivery_fee: formData.deliveryFee,
            installation_available: formData.installation_available,
            installation_fee: formData.installationFee,
            custom_order_available: formData.custom_order_available,
            additional_features: additionalFeatures
          }
        });

      if (insertError) throw insertError;

      setSuccess(true);
      setTimeout(() => {
        window.location.href = '/';
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to create listing');
    } finally {
      setUploading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-4">Login Required</h2>
          <p className="text-gray-600 mb-4">Please login to list your furniture</p>
          <a href="/login" className="px-6 py-3 bg-amber-500 text-white rounded-lg hover:bg-amber-600">
            Login
          </a>
        </div>
      </div>
    );
  }

  const selectedCategory = FURNITURE_CATEGORIES.find(cat => cat.value === formData.category);

  const steps = [
    { number: 1, title: 'Category & Details', icon: Armchair },
    { number: 2, title: 'Specifications', icon: Ruler },
    { number: 3, title: 'Features & Care', icon: Award },
    { number: 4, title: 'Images & Submit', icon: Sparkles }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 flex flex-col">
      <Header />

      <main className="flex-1 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl shadow-lg">
                <Armchair className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                  List Your Furniture
                </h1>
                <p className="text-gray-600">Chairs, sofas, tables, beds & more</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mb-8">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center flex-1">
                <div className="flex flex-col items-center flex-1">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold transition-all ${
                    currentStep >= step.number
                      ? 'bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-lg scale-110'
                      : 'bg-gray-200 text-gray-400'
                  }`}>
                    {currentStep > step.number ? (
                      <CheckCircle className="w-6 h-6" />
                    ) : (
                      <step.icon className="w-6 h-6" />
                    )}
                  </div>
                  <span className={`text-xs mt-2 font-semibold ${
                    currentStep >= step.number ? 'text-amber-600' : 'text-gray-400'
                  }`}>
                    {step.title}
                  </span>
                </div>
                {index < steps.length - 1 && (
                  <div className={`h-1 flex-1 mx-2 rounded transition-all ${
                    currentStep > step.number ? 'bg-gradient-to-r from-amber-500 to-orange-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 border-2 border-amber-100">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border-2 border-red-200 rounded-xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <span className="text-red-700">{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-6 p-4 bg-green-50 border-2 border-green-200 rounded-xl flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
              <span className="text-green-700">Furniture listed successfully! Redirecting...</span>
            </div>
          )}

          <form onSubmit={handleSubmit}>
            {currentStep === 1 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Armchair className="w-6 h-6 text-amber-600" />
                  Category & Basic Details
                </h2>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Furniture Category *
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {FURNITURE_CATEGORIES.map((cat) => {
                      const Icon = cat.icon;
                      return (
                        <button
                          key={cat.value}
                          type="button"
                          onClick={() => setFormData({...formData, category: cat.value, subcategory: ''})}
                          className={`p-4 rounded-xl border-2 transition-all ${
                            formData.category === cat.value
                              ? 'bg-amber-500 text-white border-amber-500 shadow-lg'
                              : 'bg-white text-gray-700 border-amber-200 hover:border-amber-400'
                          }`}
                        >
                          <Icon className="w-6 h-6 mx-auto mb-2" />
                          <span className="text-sm font-semibold">{cat.value}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {selectedCategory && (
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Subcategory *
                    </label>
                    <select
                      value={formData.subcategory}
                      onChange={(e) => setFormData({...formData, subcategory: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                    >
                      <option value="">Select subcategory</option>
                      {selectedCategory.subcategories.map(sub => (
                        <option key={sub} value={sub}>{sub}</option>
                      ))}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Product Title *
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    required
                    className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                    placeholder="e.g., Modern Leather Sofa 3-Seater"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Description *
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    required
                    rows={4}
                    className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                    placeholder="Describe the furniture, its features, condition..."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Brand
                    </label>
                    <input
                      type="text"
                      value={formData.brand}
                      onChange={(e) => setFormData({...formData, brand: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                      placeholder="e.g., IKEA, Ashley, Custom"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Condition *
                    </label>
                    <select
                      value={formData.condition}
                      onChange={(e) => setFormData({...formData, condition: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                    >
                      {CONDITIONS.map(cond => (
                        <option key={cond} value={cond}>{cond}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Price (NGN) *
                    </label>
                    <input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({...formData, price: e.target.value})}
                      required
                      min="0"
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                      placeholder="0"
                    />
                  </div>

                  <div className="flex items-center">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.negotiable}
                        onChange={(e) => setFormData({...formData, negotiable: e.target.checked})}
                        className="w-5 h-5 text-amber-500 border-gray-300 rounded focus:ring-amber-500"
                      />
                      <span className="text-sm font-semibold text-gray-700">Price Negotiable</span>
                    </label>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      City *
                    </label>
                    <input
                      type="text"
                      value={formData.location_city}
                      onChange={(e) => setFormData({...formData, location_city: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                      placeholder="e.g., Lagos"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      State *
                    </label>
                    <input
                      type="text"
                      value={formData.location_state}
                      onChange={(e) => setFormData({...formData, location_state: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                      placeholder="e.g., Lagos"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="px-8 py-3 bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                  >
                    Next: Specifications
                  </button>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Ruler className="w-6 h-6 text-amber-600" />
                  Specifications
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Primary Material *
                    </label>
                    <select
                      value={formData.material}
                      onChange={(e) => setFormData({...formData, material: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                    >
                      <option value="">Select material</option>
                      {MATERIALS.map(mat => (
                        <option key={mat} value={mat}>{mat}</option>
                      ))}
                    </select>
                  </div>

                  {formData.material === 'Wood' && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Wood Type
                      </label>
                      <select
                        value={formData.woodType}
                        onChange={(e) => setFormData({...formData, woodType: e.target.value})}
                        className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                      >
                        <option value="">Select wood type</option>
                        {WOOD_TYPES.map(wood => (
                          <option key={wood} value={wood}>{wood}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Color *
                    </label>
                    <select
                      value={formData.color}
                      onChange={(e) => setFormData({...formData, color: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                    >
                      <option value="">Select color</option>
                      {COLORS.map(color => (
                        <option key={color} value={color}>{color}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Style
                    </label>
                    <select
                      value={formData.style}
                      onChange={(e) => setFormData({...formData, style: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                    >
                      <option value="">Select style</option>
                      {STYLES.map(style => (
                        <option key={style} value={style}>{style}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <Ruler className="w-5 h-5 text-amber-600" />
                    Dimensions
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Length (cm)
                      </label>
                      <input
                        type="number"
                        value={formData.length}
                        onChange={(e) => setFormData({...formData, length: e.target.value})}
                        min="0"
                        className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                        placeholder="0"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Width (cm)
                      </label>
                      <input
                        type="number"
                        value={formData.width}
                        onChange={(e) => setFormData({...formData, width: e.target.value})}
                        min="0"
                        className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                        placeholder="0"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Height (cm)
                      </label>
                      <input
                        type="number"
                        value={formData.height}
                        onChange={(e) => setFormData({...formData, height: e.target.value})}
                        min="0"
                        className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                        placeholder="0"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Weight (kg)
                      </label>
                      <input
                        type="number"
                        value={formData.weight}
                        onChange={(e) => setFormData({...formData, weight: e.target.value})}
                        min="0"
                        step="0.1"
                        className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                        placeholder="0"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                  {(formData.category === 'Seating' || formData.category === 'Living Room' || formData.category === 'Dining') && (
                    <>
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Seat Height (cm)
                        </label>
                        <input
                          type="number"
                          value={formData.seatHeight}
                          onChange={(e) => setFormData({...formData, seatHeight: e.target.value})}
                          min="0"
                          className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                          placeholder="0"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Number of Seats
                        </label>
                        <input
                          type="number"
                          value={formData.numberOfSeats}
                          onChange={(e) => setFormData({...formData, numberOfSeats: e.target.value})}
                          min="1"
                          className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                          placeholder="1"
                        />
                      </div>
                    </>
                  )}

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Number of Pieces
                    </label>
                    <input
                      type="number"
                      value={formData.numberOfPieces}
                      onChange={(e) => setFormData({...formData, numberOfPieces: e.target.value})}
                      min="1"
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                      placeholder="1"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Assembly
                    </label>
                    <select
                      value={formData.assemblyRequired}
                      onChange={(e) => setFormData({...formData, assemblyRequired: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                    >
                      {ASSEMBLY_OPTIONS.map(opt => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(1)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(3)}
                    className="px-8 py-3 bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                  >
                    Next: Features & Care
                  </button>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Award className="w-6 h-6 text-amber-600" />
                  Features & Care
                </h2>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Additional Features
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {FEATURES_LIST.map(feature => (
                      <button
                        key={feature}
                        type="button"
                        onClick={() => handleFeatureToggle(feature)}
                        className={`px-3 py-2 rounded-lg border-2 font-semibold text-sm transition-colors ${
                          additionalFeatures.includes(feature)
                            ? 'bg-amber-500 text-white border-amber-500'
                            : 'bg-white text-gray-700 border-amber-200 hover:border-amber-400'
                        }`}
                      >
                        {feature}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Care Instructions
                  </label>
                  <textarea
                    value={formData.careInstructions}
                    onChange={(e) => setFormData({...formData, careInstructions: e.target.value})}
                    rows={3}
                    className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                    placeholder="How to clean and maintain this furniture..."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Warranty Available?
                    </label>
                    <select
                      value={formData.warranty}
                      onChange={(e) => setFormData({...formData, warranty: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                    >
                      <option value="">No Warranty</option>
                      <option value="Manufacturer Warranty">Manufacturer Warranty</option>
                      <option value="Store Warranty">Store Warranty</option>
                      <option value="Extended Warranty">Extended Warranty</option>
                    </select>
                  </div>

                  {formData.warranty && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Warranty Period
                      </label>
                      <input
                        type="text"
                        value={formData.warrantyPeriod}
                        onChange={(e) => setFormData({...formData, warrantyPeriod: e.target.value})}
                        className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:border-amber-500 focus:outline-none"
                        placeholder="e.g., 1 year, 6 months"
                      />
                    </div>
                  )}
                </div>

                <div className="bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-200 rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <ShoppingBag className="w-5 h-5 text-amber-600" />
                    Delivery & Services
                  </h3>

                  <div className="space-y-4">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.delivery_available}
                        onChange={(e) => setFormData({...formData, delivery_available: e.target.checked})}
                        className="w-5 h-5 text-amber-500 border-gray-300 rounded focus:ring-amber-500 mt-0.5"
                      />
                      <div className="flex-1">
                        <span className="font-semibold text-gray-900">Delivery Available</span>
                        {formData.delivery_available && (
                          <input
                            type="number"
                            value={formData.deliveryFee}
                            onChange={(e) => setFormData({...formData, deliveryFee: e.target.value})}
                            min="0"
                            className="w-full mt-2 px-4 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-500 focus:outline-none"
                            placeholder="Delivery fee (NGN)"
                          />
                        )}
                      </div>
                    </label>

                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.installation_available}
                        onChange={(e) => setFormData({...formData, installation_available: e.target.checked})}
                        className="w-5 h-5 text-amber-500 border-gray-300 rounded focus:ring-amber-500 mt-0.5"
                      />
                      <div className="flex-1">
                        <span className="font-semibold text-gray-900">Installation Service Available</span>
                        {formData.installation_available && (
                          <input
                            type="number"
                            value={formData.installationFee}
                            onChange={(e) => setFormData({...formData, installationFee: e.target.value})}
                            min="0"
                            className="w-full mt-2 px-4 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-500 focus:outline-none"
                            placeholder="Installation fee (NGN)"
                          />
                        )}
                      </div>
                    </label>

                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.custom_order_available}
                        onChange={(e) => setFormData({...formData, custom_order_available: e.target.checked})}
                        className="w-5 h-5 text-amber-500 border-gray-300 rounded focus:ring-amber-500"
                      />
                      <span className="font-semibold text-gray-900">Custom Orders Available</span>
                    </label>
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(4)}
                    className="px-8 py-3 bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                  >
                    Next: Images
                  </button>
                </div>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-amber-600" />
                  Product Images
                </h2>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Upload Images (Max 10) *
                  </label>
                  <p className="text-sm text-gray-600 mb-4">
                    Show your furniture from multiple angles, close-ups of details
                  </p>
                  <div className="border-2 border-dashed border-amber-300 rounded-2xl p-8 text-center hover:border-amber-500 transition-colors bg-amber-50/30">
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleImageSelect}
                      className="hidden"
                      id="image-upload"
                    />
                    <label htmlFor="image-upload" className="cursor-pointer">
                      <Upload className="w-16 h-16 text-amber-400 mx-auto mb-3" />
                      <span className="text-gray-700 font-semibold block mb-1">Click to upload furniture images</span>
                      <span className="text-sm text-gray-500">PNG, JPG up to 10 images</span>
                    </label>
                  </div>

                  {previews.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
                      {previews.map((preview, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={preview}
                            alt={`Preview ${index + 1}`}
                            className="w-full h-32 object-cover rounded-xl border-2 border-amber-200"
                          />
                          <button
                            type="button"
                            onClick={() => removeImage(index)}
                            className="absolute -top-2 -right-2 p-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-200 rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Package className="w-5 h-5 text-amber-600" />
                    Listing Summary
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Category:</span>
                      <span className="font-semibold text-gray-900">{formData.category || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Subcategory:</span>
                      <span className="font-semibold text-gray-900">{formData.subcategory || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Material:</span>
                      <span className="font-semibold text-gray-900">{formData.material || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Price:</span>
                      <span className="font-semibold text-gray-900">
                        {formData.price ? `NGN ${parseFloat(formData.price).toLocaleString()}` : 'Not set'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Features:</span>
                      <span className="font-semibold text-gray-900">{additionalFeatures.length} selected</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Images:</span>
                      <span className="font-semibold text-gray-900">{images.length} uploaded</span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(3)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={uploading || images.length === 0}
                    className="px-8 py-4 bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-xl font-bold hover:shadow-2xl disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
                  >
                    {uploading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        Publish Listing
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
};
