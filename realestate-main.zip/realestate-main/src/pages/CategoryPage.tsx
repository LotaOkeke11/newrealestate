import { useEffect, useState } from 'react';
import { Header } from '../components/Header';
import { CategoryNav } from '../components/CategoryNav';
import { Sidebar } from '../components/Sidebar';
import { Star, MapPin, Heart } from 'lucide-react';
import { supabase, Category } from '../lib/supabase';

type Listing = {
  id: string;
  title: string;
  price: number;
  images: string[];
  location_city: string;
  location_state: string;
  created_at: string;
  is_featured: boolean;
};

export const CategoryPage = ({ slug }: { slug: string }) => {
  const [category, setCategory] = useState<Category | null>(null);
  const [listings, setListings] = useState<Listing[]>([]);
  const [featuredListings, setFeaturedListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    loadCategory();
  }, [slug]);

  const loadCategory = async () => {
    setLoading(true);
    const { data: categoryData } = await supabase
      .from('categories')
      .select('*')
      .eq('slug', slug)
      .eq('is_active', true)
      .maybeSingle();

    if (categoryData) {
      setCategory(categoryData);
      loadListings(categoryData.id);
    } else {
      setLoading(false);
    }
  };

  const loadListings = async (categoryId: string) => {
    // First, check if this category has subcategories
    const { data: subcategories } = await supabase
      .from('categories')
      .select('id')
      .eq('parent_id', categoryId)
      .eq('is_active', true);

    let query = supabase
      .from('listings')
      .select('id, title, price, images, location_city, location_state, created_at, is_featured, category_id, categories(slug)')
      .eq('status', 'active');

    // Special handling for "Car Parts" category - include all auto parts
    if (slug === 'car-parts') {
      const { data: autoPartsCategory } = await supabase
        .from('categories')
        .select('id')
        .eq('slug', 'auto-parts')
        .maybeSingle();

      if (autoPartsCategory) {
        query = query.or(`category_id.eq.${categoryId},category_id.eq.${autoPartsCategory.id}`);
      } else {
        query = query.eq('category_id', categoryId);
      }
    } else if (slug === 'sale') {
      // Get the Real Estate category ID
      const { data: realEstateCategory } = await supabase
        .from('categories')
        .select('id')
        .eq('slug', 'real-estate')
        .maybeSingle();

      if (realEstateCategory) {
        // Include both Sale category listings and Real Estate listings
        query = query.or(`category_id.eq.${categoryId},category_id.eq.${realEstateCategory.id}`);
      } else {
        query = query.eq('category_id', categoryId);
      }
    } else if (subcategories && subcategories.length > 0) {
      // If category has subcategories, show listings from all subcategories
      const allCategoryIds = [categoryId, ...subcategories.map(sub => sub.id)];
      query = query.in('category_id', allCategoryIds);
    } else {
      query = query.eq('category_id', categoryId);
    }

    const { data: listingsData } = await query
      .order('is_featured', { ascending: false, nullsFirst: false })
      .order('created_at', { ascending: false })
      .limit(100);

    if (listingsData) {
      const featured = listingsData.filter(l => l.is_featured);
      const regular = listingsData.filter(l => !l.is_featured);
      setFeaturedListings(featured);
      setListings(regular);
    }
    setLoading(false);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const getListingImage = (listing: Listing) => {
    if (listing.images && listing.images.length > 0) {
      return listing.images[0];
    }
    return 'https://images.pexels.com/photos/380768/pexels-photo-380768.jpeg?auto=compress&cs=tinysrgb&w=400';
  };

  const getListingUrl = (listing: Listing) => {
    return `/product/${listing.id}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <CategoryNav />
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin w-12 h-12 border-4 border-gray-300 border-t-gray-900 rounded-full"></div>
        </div>
      </div>
    );
  }

  if (!category) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <CategoryNav />
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900 mb-2">Category not found</p>
            <a href="/" className="text-gray-600 hover:text-gray-900 underline">Go to homepage</a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />
      <CategoryNav />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{category.name}</h1>
          {category.description && (
            <p className="text-gray-600">{category.description}</p>
          )}
          <p className="text-sm text-gray-500 mt-2">{featuredListings.length + listings.length} listing(s) found</p>
        </div>

        {listings.length === 0 && featuredListings.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-gray-400 mb-4">
              <svg className="w-24 h-24 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
              </svg>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">No listings yet</h3>
            <p className="text-gray-600 mb-4">Be the first to post in this category!</p>
            <a
              href="/post-ad"
              className="inline-block px-6 py-3 bg-gray-900 text-white rounded-lg font-semibold hover:bg-gray-800 transition-colors"
            >
              Post an Ad
            </a>
          </div>
        ) : (
          <>
            {featuredListings.length > 0 && (
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-4">
                  <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                  <h2 className="text-xl font-bold text-gray-900">Featured Listings</h2>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {featuredListings.map((listing) => (
                    <a
                      key={listing.id}
                      href={getListingUrl(listing)}
                      className="group bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden border-2 border-amber-300"
                    >
                      <div className="relative aspect-square overflow-hidden">
                        <img
                          src={getListingImage(listing)}
                          alt={listing.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                        <div className="absolute top-2 left-2 bg-amber-500 text-white px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                          <Star className="w-3 h-3 fill-white" />
                          Featured
                        </div>
                        <button
                          className="absolute top-2 right-2 p-1.5 bg-white/90 rounded-full hover:bg-white transition-colors"
                          onClick={(e) => e.preventDefault()}
                        >
                          <Heart className="w-4 h-4 text-gray-600" />
                        </button>
                      </div>
                      <div className="p-3">
                        <h3 className="font-medium text-sm text-gray-900 line-clamp-2 mb-1">
                          {listing.title}
                        </h3>
                        <p className="text-amber-600 font-bold text-base mb-2">
                          {formatPrice(listing.price)}
                        </p>
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center text-gray-500">
                            <MapPin className="w-3 h-3 mr-1" />
                            <span>{listing.location_city}</span>
                          </div>
                          <div className="text-gray-400 text-xs">
                            {new Date(listing.created_at).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            )}

            {listings.length > 0 && (
              <div>
                {featuredListings.length > 0 && (
                  <h2 className="text-xl font-bold text-gray-900 mb-4">All Listings</h2>
                )}
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {listings.map((listing) => (
              <a
                key={listing.id}
                href={getListingUrl(listing)}
                className="group bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden border border-gray-100"
              >
                <div className="relative aspect-square overflow-hidden">
                  <img
                    src={getListingImage(listing)}
                    alt={listing.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <button
                    className="absolute top-2 right-2 p-1.5 bg-white/90 rounded-full hover:bg-white transition-colors"
                    onClick={(e) => e.preventDefault()}
                  >
                    <Heart className="w-4 h-4 text-gray-600" />
                  </button>
                </div>
                <div className="p-3">
                  <h3 className="font-medium text-sm text-gray-900 line-clamp-2 mb-1">
                    {listing.title}
                  </h3>
                  <p className="text-amber-600 font-bold text-base mb-2">
                    {formatPrice(listing.price)}
                  </p>
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center text-gray-500">
                      <MapPin className="w-3 h-3 mr-1" />
                      <span>{listing.location_city}</span>
                    </div>
                    <div className="text-gray-400 text-xs">
                      {new Date(listing.created_at).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </a>
            ))}
                </div>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};
