import { useState, useEffect, useRef } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Send, MessageCircle, User, Loader, Package, Search, ArrowLeft, Phone, Video, MoreVertical, Smile, Paperclip, Check, CheckCheck } from 'lucide-react';

type ConversationGroup = {
  id: string;
  otherUserId: string;
  otherUserName: string;
  listingId: string | null;
  listingTitle: string | null;
  lastMessage: string;
  lastMessageAt: string;
  unreadCount: number;
};

type Message = {
  id: string;
  content: string;
  sender_id: string;
  recipient_id: string;
  created_at: string;
  is_read: boolean;
  conversation_id: string;
};

export const MessagesPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [conversations, setConversations] = useState<ConversationGroup[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<ConversationGroup | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      loadConversations();

      const conversationChannel = supabase
        .channel('conversations-realtime')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'conversations',
          },
          () => {
            loadConversations();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(conversationChannel);
      };
    }
  }, [user]);

  useEffect(() => {
    if (selectedConversation && user) {
      loadMessages();

      const messagesChannel = supabase
        .channel(`messages-${selectedConversation.id}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
            filter: `conversation_id=eq.${selectedConversation.id}`,
          },
          (payload) => {
            const newMsg = payload.new as Message;
            if (newMsg.sender_id !== user.id) {
              setMessages((current) => [...current, newMsg]);
              markMessagesAsRead([newMsg]);
            }
          }
        )
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'messages',
            filter: `conversation_id=eq.${selectedConversation.id}`,
          },
          (payload) => {
            const updatedMsg = payload.new as Message;
            setMessages((current) =>
              current.map((msg) => (msg.id === updatedMsg.id ? updatedMsg : msg))
            );
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(messagesChannel);
      };
    }
  }, [selectedConversation, user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadConversations = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data: conversationsData } = await supabase
        .from('conversations')
        .select('*')
        .or(`buyer_id.eq.${user.id},seller_id.eq.${user.id}`)
        .order('last_message_at', { ascending: false, nullsFirst: false });

      if (!conversationsData) {
        setLoading(false);
        return;
      }

      const conversationGroups = await Promise.all(
        conversationsData.map(async (conv) => {
          const otherUserId = conv.buyer_id === user.id ? conv.seller_id : conv.buyer_id;

          const { data: profile } = await supabase
            .from('profiles')
            .select('full_name, email')
            .eq('id', otherUserId)
            .maybeSingle();

          const { data: listing } = conv.listing_id
            ? await supabase
                .from('listings')
                .select('title')
                .eq('id', conv.listing_id)
                .maybeSingle()
            : { data: null };

          const unreadCount = conv.buyer_id === user.id ? conv.buyer_unread_count : conv.seller_unread_count;

          return {
            id: conv.id,
            otherUserId,
            otherUserName: profile?.full_name || profile?.email || 'User',
            listingId: conv.listing_id,
            listingTitle: listing?.title || null,
            lastMessage: conv.last_message || '',
            lastMessageAt: conv.last_message_at || conv.created_at,
            unreadCount: unreadCount || 0,
          };
        })
      );

      setConversations(conversationGroups);
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadMessages = async () => {
    if (!user || !selectedConversation) return;

    try {
      const { data } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', selectedConversation.id)
        .order('created_at', { ascending: true });

      if (data) {
        setMessages(data);
        markMessagesAsRead(data);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  };

  const markMessagesAsRead = async (msgs: Message[]) => {
    if (!user || !selectedConversation) return;

    const unreadMessages = msgs.filter(msg => msg.recipient_id === user.id && !msg.is_read);

    if (unreadMessages.length > 0) {
      const ids = unreadMessages.map(msg => msg.id);
      await supabase.from('messages').update({ is_read: true }).in('id', ids);

      const updateField = selectedConversation.otherUserId === selectedConversation.otherUserId
        ? (user.id === selectedConversation.otherUserId ? 'buyer_unread_count' : 'seller_unread_count')
        : 'buyer_unread_count';

      await supabase
        .from('conversations')
        .update({ [updateField]: 0 })
        .eq('id', selectedConversation.id);

      loadConversations();
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newMessage.trim() || !user || !selectedConversation || sending) return;

    const messageContent = newMessage.trim();
    setSending(true);
    setNewMessage('');

    try {
      const messageData = {
        conversation_id: selectedConversation.id,
        topic: 'chat',
        sender_id: user.id,
        recipient_id: selectedConversation.otherUserId,
        listing_id: selectedConversation.listingId,
        content: messageContent,
        extension: 'text',
        is_read: false,
      };

      const { data, error } = await supabase.from('messages').insert(messageData).select().maybeSingle();

      if (error) throw error;

      if (data) {
        setMessages([...messages, data]);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      setNewMessage(messageContent);
      alert('Failed to send message. Please try again.');
    } finally {
      setSending(false);
    }
  };

  const startNewConversation = async () => {
    if (!user) return;

    const otherUserEmail = prompt('Enter the email of the person you want to chat with:');
    if (!otherUserEmail) return;

    try {
      const { data: otherUserProfile } = await supabase
        .from('profiles')
        .select('id, email, full_name')
        .eq('email', otherUserEmail.trim())
        .maybeSingle();

      if (!otherUserProfile) {
        alert('User not found. Please check the email and try again.');
        return;
      }

      const { data: existingConv } = await supabase
        .from('conversations')
        .select('*')
        .or(`and(buyer_id.eq.${user.id},seller_id.eq.${otherUserProfile.id}),and(buyer_id.eq.${otherUserProfile.id},seller_id.eq.${user.id})`)
        .is('listing_id', null)
        .maybeSingle();

      if (existingConv) {
        const conv = {
          id: existingConv.id,
          otherUserId: otherUserProfile.id,
          otherUserName: otherUserProfile.full_name || otherUserProfile.email,
          listingId: null,
          listingTitle: null,
          lastMessage: existingConv.last_message || '',
          lastMessageAt: existingConv.last_message_at || existingConv.created_at,
          unreadCount: 0,
        };
        setSelectedConversation(conv);
        return;
      }

      const { data: newConv, error } = await supabase
        .from('conversations')
        .insert({
          buyer_id: user.id,
          seller_id: otherUserProfile.id,
          last_message: 'Conversation started',
          last_message_at: new Date().toISOString(),
        })
        .select()
        .maybeSingle();

      if (error) throw error;

      if (newConv) {
        await loadConversations();
        setSelectedConversation({
          id: newConv.id,
          otherUserId: otherUserProfile.id,
          otherUserName: otherUserProfile.full_name || otherUserProfile.email,
          listingId: null,
          listingTitle: null,
          lastMessage: 'Conversation started',
          lastMessageAt: newConv.last_message_at,
          unreadCount: 0,
        });
      }
    } catch (error) {
      console.error('Error starting conversation:', error);
      alert('Failed to start conversation. Please try again.');
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));

    if (hours < 24) {
      return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    } else if (hours < 48) {
      return 'Yesterday';
    } else if (hours < 168) {
      return date.toLocaleDateString('en-US', { weekday: 'short' });
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  const filteredConversations = conversations.filter(conv => {
    if (!searchQuery) return true;
    const searchLower = searchQuery.toLowerCase();
    return (
      conv.otherUserName.toLowerCase().includes(searchLower) ||
      conv.listingTitle?.toLowerCase().includes(searchLower) ||
      conv.lastMessage.toLowerCase().includes(searchLower)
    );
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex-1 flex items-center justify-center px-4">
          <div className="text-center bg-white rounded-3xl shadow-xl p-12 max-w-md">
            <MessageCircle className="w-20 h-20 text-amber-500 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Sign In Required</h2>
            <p className="text-gray-600 mb-8 text-lg">Please sign in to view your messages</p>
            <a href="/login" className="block w-full px-8 py-4 bg-amber-500 text-white rounded-xl font-bold hover:bg-amber-600 transition-all">
              Sign In
            </a>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1 max-w-7xl mx-auto px-4 py-6 w-full">
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden h-[calc(100vh-180px)]">
          <div className="flex h-full">
            <div className={`${selectedConversation ? 'hidden md:flex' : 'flex'} w-full md:w-1/3 border-r border-gray-200 flex-col`}>
              <div className="p-4 bg-gradient-to-r from-amber-500 to-orange-600">
                <div className="flex items-center justify-between mb-4">
                  <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                    <MessageCircle className="w-7 h-7" />
                    Messages
                  </h1>
                  <button
                    onClick={startNewConversation}
                    className="px-4 py-2 bg-white text-amber-600 rounded-xl font-bold hover:bg-amber-50 transition-all text-sm"
                  >
                    New Chat
                  </button>
                </div>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search conversations..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-white/90 rounded-xl focus:outline-none focus:ring-2 focus:ring-white"
                  />
                </div>
              </div>

              <div className="flex-1 overflow-y-auto">
                {loading ? (
                  <div className="flex items-center justify-center h-64">
                    <Loader className="w-8 h-8 text-amber-500 animate-spin" />
                  </div>
                ) : filteredConversations.length === 0 ? (
                  <div className="text-center py-16 px-4">
                    <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 font-semibold mb-2">No messages yet</p>
                    <p className="text-sm text-gray-500 mb-4">Start chatting with sellers or buyers!</p>
                    <button
                      onClick={startNewConversation}
                      className="px-6 py-3 bg-amber-500 text-white rounded-xl font-bold hover:bg-amber-600 transition-all"
                    >
                      Start New Chat
                    </button>
                  </div>
                ) : (
                  filteredConversations.map((conv) => (
                    <button
                      key={conv.id}
                      onClick={() => setSelectedConversation(conv)}
                      className={`w-full p-4 border-b border-gray-100 hover:bg-gray-50 transition-all text-left ${
                        selectedConversation?.id === conv.id
                          ? 'bg-amber-50 border-l-4 border-l-amber-500'
                          : ''
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">
                          {conv.otherUserName[0].toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h3 className="font-bold text-gray-900 truncate">{conv.otherUserName}</h3>
                            {conv.unreadCount > 0 && (
                              <span className="ml-2 px-2 py-1 bg-amber-500 text-white text-xs font-bold rounded-full">
                                {conv.unreadCount}
                              </span>
                            )}
                          </div>
                          {conv.listingTitle && (
                            <p className="text-xs text-gray-600 mb-1 flex items-center gap-1">
                              <Package className="w-3 h-3" />
                              <span className="truncate">{conv.listingTitle}</span>
                            </p>
                          )}
                          <p className="text-sm text-gray-600 truncate">{conv.lastMessage}</p>
                          <p className="text-xs text-gray-400 mt-1">
                            {formatTime(conv.lastMessageAt)}
                          </p>
                        </div>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>

            <div className={`${selectedConversation ? 'flex' : 'hidden md:flex'} flex-1 flex-col`}>
              {selectedConversation ? (
                <>
                  <div className="p-4 border-b border-gray-200 bg-white">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => setSelectedConversation(null)}
                          className="md:hidden p-2 hover:bg-gray-100 rounded-full transition-colors"
                        >
                          <ArrowLeft className="w-5 h-5 text-gray-600" />
                        </button>
                        <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-full flex items-center justify-center text-white font-bold">
                          {selectedConversation.otherUserName[0].toUpperCase()}
                        </div>
                        <div>
                          <h2 className="text-xl font-bold text-gray-900">{selectedConversation.otherUserName}</h2>
                          {selectedConversation.listingTitle && (
                            <p className="text-sm text-gray-600">{selectedConversation.listingTitle}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                          onClick={() => alert('Voice call feature coming soon!')}
                        >
                          <Phone className="w-5 h-5 text-gray-600" />
                        </button>
                        <button
                          type="button"
                          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                          onClick={() => alert('Video call feature coming soon!')}
                        >
                          <Video className="w-5 h-5 text-gray-600" />
                        </button>
                        <button
                          type="button"
                          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                          onClick={() => alert('More options coming soon!')}
                        >
                          <MoreVertical className="w-5 h-5 text-gray-600" />
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
                    {messages.length === 0 ? (
                      <div className="text-center py-12">
                        <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600 font-semibold">No messages yet</p>
                        <p className="text-sm text-gray-500">Start the conversation!</p>
                      </div>
                    ) : (
                      messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.sender_id === user.id ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                              message.sender_id === user.id
                                ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white'
                                : 'bg-white text-gray-900 border-2 border-gray-200'
                            }`}
                          >
                            <p className="text-sm break-words">{message.content}</p>
                            <div
                              className={`flex items-center gap-1 mt-1 text-xs ${
                                message.sender_id === user.id ? 'text-white/80 justify-end' : 'text-gray-500'
                              }`}
                            >
                              <span>
                                {new Date(message.created_at).toLocaleTimeString([], {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </span>
                              {message.sender_id === user.id && (
                                message.is_read ? (
                                  <CheckCheck className="w-4 h-4" />
                                ) : (
                                  <Check className="w-4 h-4" />
                                )
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-200 bg-white">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                        onClick={() => alert('Emoji picker coming soon!')}
                      >
                        <Smile className="w-6 h-6 text-gray-500" />
                      </button>
                      <button
                        type="button"
                        className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                        onClick={() => alert('File attachment coming soon!')}
                      >
                        <Paperclip className="w-6 h-6 text-gray-500" />
                      </button>
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage(e);
                          }
                        }}
                        placeholder="Type your message..."
                        disabled={sending}
                        className="flex-1 px-4 py-3 bg-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
                      />
                      <button
                        type="submit"
                        disabled={sending || !newMessage.trim()}
                        className="px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-xl font-bold hover:from-amber-600 hover:to-orange-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2 shadow-lg"
                      >
                        {sending ? <Loader className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                      </button>
                    </div>
                  </form>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <MessageCircle className="w-20 h-20 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Select a Conversation</h3>
                    <p className="text-gray-600">Choose a conversation to view messages</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};
