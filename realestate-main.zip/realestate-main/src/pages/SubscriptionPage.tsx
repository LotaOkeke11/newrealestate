import { useEffect, useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Check, Crown, Star, Zap, Rocket, Building2, Loader2 } from 'lucide-react';

type Tier = {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
  max_listings: number;
  level: number;
};

export const SubscriptionPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingTierId, setProcessingTierId] = useState<string | null>(null);

  useEffect(() => {
    loadTiers();
  }, []);

  const loadTiers = async () => {
    const { data } = await supabase
      .from('subscription_tiers')
      .select('*')
      .order('level');

    if (data) {
      setTiers(data);
    }
    setLoading(false);
  };

  const getTierIcon = (level: number) => {
    switch (level) {
      case 1: return Star;
      case 2: return Zap;
      case 3: return Crown;
      case 4: return Rocket;
      case 5: return Building2;
      default: return Star;
    }
  };

  const getTierColor = (level: number) => {
    switch (level) {
      case 1: return 'from-gray-400 to-gray-500';
      case 2: return 'from-blue-400 to-blue-500';
      case 3: return 'from-amber-400 to-amber-500';
      case 4: return 'from-purple-400 to-purple-500';
      case 5: return 'from-emerald-400 to-emerald-500';
      default: return 'from-gray-400 to-gray-500';
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const handleSubscribe = async (tier: Tier) => {
    if (!user) {
      if (confirm('Please sign in to subscribe. Go to login page?')) {
        window.location.href = '/login';
      }
      return;
    }

    if (tier.level === 1) {
      alert('You are already on the free Starter plan!');
      return;
    }

    setProcessingTierId(tier.id);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Please sign in to continue');
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-subscription-checkout`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            tierId: tier.id,
            tierName: tier.name,
            tierPrice: tier.price,
          }),
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Edge function error response:', errorText);
        try {
          const error = JSON.parse(errorText);
          throw new Error(error.error || 'Failed to create checkout session');
        } catch {
          throw new Error(`Failed to create checkout session: ${errorText}`);
        }
      }

      const result = await response.json();
      console.log('Paystack response:', result);
      const { authorizationUrl } = result;

      if (authorizationUrl) {
        window.location.href = authorizationUrl;
      } else {
        throw new Error('No authorization URL returned from payment gateway');
      }
    } catch (error: any) {
      console.error('Subscription error:', error);
      alert(error.message || 'Failed to start subscription process. Please try again.');
    } finally {
      setProcessingTierId(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-amber-50">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Choose Your Plan
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Unlock more categories and features as you grow your business
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-gray-500">Loading plans...</div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {tiers.map((tier) => {
              const Icon = getTierIcon(tier.level);
              const isPopular = tier.level === 3;

              return (
                <div
                  key={tier.id}
                  className={`relative bg-white rounded-2xl shadow-xl overflow-hidden transition-all hover:scale-105 hover:shadow-2xl ${
                    isPopular ? 'ring-4 ring-amber-500' : ''
                  }`}
                >
                  {isPopular && (
                    <div className="absolute top-0 right-0 bg-amber-500 text-white px-4 py-1 text-sm font-bold rounded-bl-lg">
                      POPULAR
                    </div>
                  )}

                  <div className={`bg-gradient-to-br ${getTierColor(tier.level)} p-6 text-white`}>
                    <div className="flex items-center justify-center mb-4">
                      <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                        <Icon className="w-8 h-8" />
                      </div>
                    </div>
                    <h3 className="text-2xl font-bold text-center mb-2">{tier.name}</h3>
                    <div className="text-center">
                      <span className="text-4xl font-bold">{formatPrice(tier.price)}</span>
                      <span className="text-sm opacity-80">/month</span>
                    </div>
                  </div>

                  <div className="p-6">
                    <p className="text-gray-600 text-center mb-6 h-12">{tier.description}</p>

                    <div className="space-y-3 mb-6">
                      {tier.features.map((feature, index) => (
                        <div key={index} className="flex items-start gap-2">
                          <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>

                    <button
                      onClick={() => handleSubscribe(tier)}
                      disabled={processingTierId === tier.id}
                      className={`w-full py-3 rounded-lg font-bold transition-all flex items-center justify-center gap-2 ${
                        isPopular
                          ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white hover:from-amber-600 hover:to-amber-700 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed'
                      }`}
                    >
                      {processingTierId === tier.id ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        tier.level === 1 ? 'Current Plan' : 'Subscribe Now'
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-16 bg-white rounded-2xl shadow-lg p-8 border border-amber-100">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-center">
            Frequently Asked Questions
          </h2>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <div>
              <h3 className="font-bold text-gray-900 mb-2">Can I upgrade or downgrade?</h3>
              <p className="text-gray-600 text-sm">Yes! You can change your plan at any time. Changes take effect immediately.</p>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-2">What payment methods do you accept?</h3>
              <p className="text-gray-600 text-sm">We accept all major cards, bank transfers, and mobile payments.</p>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-2">Is there a long-term contract?</h3>
              <p className="text-gray-600 text-sm">No contracts! Pay monthly and cancel anytime without penalties.</p>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-2">Can I try before buying?</h3>
              <p className="text-gray-600 text-sm">Absolutely! Start with our Free plan and upgrade when you are ready.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
