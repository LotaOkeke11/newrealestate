import { useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { ShoppingBag, X, CheckCircle2, AlertCircle, Image as ImageIcon, Check, Sparkles } from 'lucide-react';

export const UploadFashionPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    category: '',
    itemName: '',
    brand: '',
    condition: '',
    size: '',
    color: '',
    material: '',
    gender: '',
    price: '',
    description: '',
    locationState: '',
    locationCity: '',
    priceNegotiable: false,
    contactPhone: '',
    contactWhatsapp: ''
  });

  const fashionCategories = [
    'Clothing - Men',
    'Clothing - Women',
    'Clothing - Kids',
    'Shoes - Men',
    'Shoes - Women',
    'Shoes - Kids',
    'Bags & Accessories',
    'Jewelry & Watches',
    'Sunglasses & Eyewear',
    'Belts & Wallets',
    'Hats & Caps',
    'Sportswear',
    'Traditional Wear',
    'Vintage/Second Hand',
    'Designer Fashion',
    'Wedding & Events',
    'Maternity',
    'Plus Size',
    'Other'
  ];

  const brands = [
    'Nike',
    'Adidas',
    'Zara',
    'H&M',
    'Gucci',
    'Louis Vuitton',
    'Prada',
    'Versace',
    'Calvin Klein',
    'Tommy Hilfiger',
    'Ralph Lauren',
    'Levi\'s',
    'Puma',
    'Reebok',
    'New Balance',
    'Balenciaga',
    'Fendi',
    'Burberry',
    'Chanel',
    'Dior',
    'Local Brand',
    'Unbranded',
    'Other'
  ];

  const conditions = ['Brand New with Tags', 'Brand New without Tags', 'Excellent', 'Good', 'Fair'];
  const sizes = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '16', '18', '20', 'One Size', 'Custom'];
  const colors = ['Black', 'White', 'Red', 'Blue', 'Green', 'Yellow', 'Orange', 'Pink', 'Purple', 'Brown', 'Gray', 'Beige', 'Navy', 'Multicolor', 'Other'];
  const materials = ['Cotton', 'Polyester', 'Silk', 'Wool', 'Leather', 'Denim', 'Linen', 'Nylon', 'Spandex', 'Velvet', 'Suede', 'Canvas', 'Mixed', 'Other'];
  const genders = ['Men', 'Women', 'Unisex', 'Boys', 'Girls'];

  const nigeriaStates = [
    'Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo', 'Kaduna', 'Anambra', 'Enugu',
    'Delta', 'Edo', 'Ogun', 'Ondo', 'Osun', 'Kwara', 'Plateau', 'Benue'
  ];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + imageFiles.length > 10) {
      setError('Maximum 10 images allowed');
      return;
    }
    setImageFiles((prev) => [...prev, ...files]);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreviews((prev) => [...prev, reader.result as string]);
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImageFiles((prev) => prev.filter((_, i) => i !== index));
    setImagePreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (!user) throw new Error('Please sign in');
      if (imageFiles.length < 2) throw new Error('Upload at least 2 images');

      const imageUrls: string[] = [];
      for (let i = 0; i < imageFiles.length; i++) {
        const file = imageFiles[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/fashion-${Date.now()}-${i}.${fileExt}`;
        const { error: uploadError } = await supabase.storage.from('listing-images').upload(fileName, file);
        if (!uploadError) {
          const { data: urlData } = supabase.storage.from('listing-images').getPublicUrl(fileName);
          imageUrls.push(urlData.publicUrl);
        }
      }

      const { data: category } = await supabase.from('categories').select('id, slug').eq('slug', 'fashion').maybeSingle();

      const listingData = {
        user_id: user.id,
        category_id: category?.id,
        title: `${formData.brand} ${formData.itemName}`,
        description: formData.description,
        price: parseFloat(formData.price),
        currency: 'NGN',
        condition: formData.condition,
        images: imageUrls,
        item_type: formData.category,
        brand: formData.brand,
        specifications: {
          size: formData.size,
          color: formData.color,
          material: formData.material,
          gender: formData.gender
        },
        price_negotiable: formData.priceNegotiable,
        location_state: formData.locationState,
        location_city: formData.locationCity,
        contact_phone: formData.contactPhone,
        contact_whatsapp: formData.contactWhatsapp,
        status: 'active'
      };

      const { data: listing, error: listingError } = await supabase.from('listings').insert(listingData).select().single();
      if (listingError) throw listingError;
      setSuccess(true);
      setTimeout(() => {
        window.location.href = category?.slug ? `/category/${category.slug}` : '/';
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    window.location.href = '/post-ad';
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />
      <main className="flex-1">
        <div className="bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white py-12 px-4 shadow-2xl">
          <div className="max-w-5xl mx-auto">
            <a href="/post-ad" className="text-white/90 hover:text-white text-sm font-bold mb-4 inline-block">← Back</a>
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <Sparkles className="w-10 h-10 text-yellow-300 animate-pulse" />
                  <h1 className="text-5xl font-black">Sell Fashion</h1>
                </div>
                <p className="text-white/95 text-xl font-semibold">List your fashion items and reach millions of buyers</p>
              </div>
              <div className="hidden md:flex w-24 h-24 bg-white/20 rounded-3xl items-center justify-center backdrop-blur-sm">
                <ShoppingBag className="w-12 h-12 text-white" />
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-5xl mx-auto px-4 py-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {success && (
              <div className="p-6 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-300 rounded-2xl flex items-start gap-4 shadow-lg">
                <CheckCircle2 className="w-7 h-7 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-black text-green-900 text-xl">Success!</p>
                  <p className="text-green-800 text-sm font-semibold">Your fashion item is now live</p>
                </div>
              </div>
            )}
            {error && (
              <div className="p-6 bg-gradient-to-r from-red-50 to-pink-50 border-2 border-red-300 rounded-2xl flex items-start gap-4 shadow-lg">
                <AlertCircle className="w-7 h-7 text-red-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-red-800 font-semibold">{error}</span>
              </div>
            )}

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-orange-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-orange-400 to-pink-400">Item Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Category *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 font-semibold"
                  >
                    <option value="">Select category</option>
                    {fashionCategories.map((cat) => <option key={cat} value={cat}>{cat}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Item Name *</label>
                  <input
                    type="text"
                    value={formData.itemName}
                    onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                    placeholder="e.g., Leather Jacket, Running Shoes"
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Brand *</label>
                  <select
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 font-semibold"
                  >
                    <option value="">Select brand</option>
                    {brands.map((brand) => <option key={brand} value={brand}>{brand}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Condition *</label>
                  <select
                    value={formData.condition}
                    onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 font-semibold"
                  >
                    <option value="">Select condition</option>
                    {conditions.map((cond) => <option key={cond} value={cond}>{cond}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Size *</label>
                  <select
                    value={formData.size}
                    onChange={(e) => setFormData({ ...formData, size: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 font-semibold"
                  >
                    <option value="">Select size</option>
                    {sizes.map((size) => <option key={size} value={size}>{size}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Color *</label>
                  <select
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 font-semibold"
                  >
                    <option value="">Select color</option>
                    {colors.map((color) => <option key={color} value={color}>{color}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Material *</label>
                  <select
                    value={formData.material}
                    onChange={(e) => setFormData({ ...formData, material: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 font-semibold"
                  >
                    <option value="">Select material</option>
                    {materials.map((material) => <option key={material} value={material}>{material}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Gender/Category *</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 font-semibold"
                  >
                    <option value="">Select</option>
                    {genders.map((gender) => <option key={gender} value={gender}>{gender}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-pink-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-pink-400 to-purple-400">Photos</h2>
              <div className="border-4 border-dashed border-pink-300 rounded-2xl p-10 text-center hover:border-pink-500 bg-gradient-to-br from-pink-50 to-purple-50 transition-all">
                <ImageIcon className="w-20 h-20 text-pink-400 mx-auto mb-5" />
                <p className="text-gray-900 mb-2 font-black text-xl">Upload fashion photos</p>
                <p className="text-sm text-gray-600 mb-5 font-semibold">Up to 10 images (Min 2 required)</p>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                  id="image-upload"
                />
                <label
                  htmlFor="image-upload"
                  className="px-10 py-4 bg-gradient-to-r from-orange-500 to-pink-600 text-white rounded-xl cursor-pointer hover:from-orange-600 hover:to-pink-700 inline-block font-black text-lg transition-all shadow-lg"
                >
                  Choose Photos
                </label>
              </div>
              {imagePreviews.length > 0 && (
                <div className="mt-8">
                  <p className="font-black text-gray-900 mb-4 text-xl">{imagePreviews.length} photo(s) selected</p>
                  <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative aspect-square rounded-2xl overflow-hidden border-4 border-pink-200 group shadow-lg">
                        <img src={preview} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full hover:bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-purple-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-purple-400 to-pink-400">Description</h2>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe your item: condition, style, fit, measurements, any defects..."
                rows={6}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 font-semibold"
              />
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-orange-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-orange-400 to-pink-400">Location</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">State *</label>
                  <select
                    value={formData.locationState}
                    onChange={(e) => setFormData({ ...formData, locationState: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 font-semibold"
                  >
                    <option value="">Select state</option>
                    {nigeriaStates.map((state) => <option key={state} value={state}>{state}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">City/Area *</label>
                  <input
                    type="text"
                    value={formData.locationCity}
                    onChange={(e) => setFormData({ ...formData, locationCity: e.target.value })}
                    placeholder="e.g., Lekki, Ikeja"
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 font-semibold"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-pink-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-pink-400 to-purple-400">Price & Contact</h2>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Price (₦) *</label>
                  <div className="relative">
                    <div className="absolute left-5 top-1/2 -translate-y-1/2 text-3xl font-black text-pink-500">₦</div>
                    <input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      placeholder="0"
                      required
                      min="0"
                      className="w-full pl-16 pr-4 py-5 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 text-2xl font-black"
                    />
                  </div>
                </div>
                <label className="flex items-center gap-4 p-5 border-4 border-pink-200 rounded-xl cursor-pointer hover:border-pink-400 transition-all bg-pink-50">
                  <input
                    type="checkbox"
                    checked={formData.priceNegotiable}
                    onChange={(e) => setFormData({ ...formData, priceNegotiable: e.target.checked })}
                    className="w-6 h-6 text-pink-600 rounded focus:ring-pink-500"
                  />
                  <span className="font-black text-gray-900 text-lg">Price is negotiable</span>
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-black text-gray-800 mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      value={formData.contactPhone}
                      onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                      placeholder="+234 800 000 0000"
                      required
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-black text-gray-800 mb-2">WhatsApp (Optional)</label>
                    <input
                      type="tel"
                      value={formData.contactWhatsapp}
                      onChange={(e) => setFormData({ ...formData, contactWhatsapp: e.target.value })}
                      placeholder="+234 800 000 0000"
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-pink-500 focus:border-pink-500 font-semibold"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-8 border-t-4 border-gray-200">
              <a
                href="/post-ad"
                className="px-10 py-4 border-4 border-gray-300 text-gray-700 rounded-xl font-black text-lg hover:bg-gray-50 transition-all"
              >
                Cancel
              </a>
              <button
                type="submit"
                disabled={loading || imageFiles.length < 2}
                className="px-16 py-4 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-white rounded-xl font-black text-lg hover:from-orange-600 hover:via-pink-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl flex items-center gap-3 transition-all"
              >
                {loading ? (
                  <>
                    <div className="animate-spin w-6 h-6 border-3 border-white border-t-transparent rounded-full"></div>
                    Publishing...
                  </>
                ) : (
                  <>
                    <Check className="w-6 h-6" />
                    Publish Listing
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
};
