import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { ChatBox } from '../components/ChatBox';
import {
  MapPin, Phone, Mail, Share2, Heart, ShoppingCart, MessageCircle,
  Calendar, Eye, Star, CheckCircle, AlertCircle, ChevronLeft,
  ChevronRight, X
} from 'lucide-react';

type Listing = {
  id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  images: string[];
  location_city?: string;
  location_state?: string;
  contact_phone?: string;
  contact_email?: string;
  condition?: string;
  created_at: string;
  status: string;
  views?: number;
  user_id: string;
  categories?: {
    name: string;
    slug: string;
  };
  profiles?: {
    full_name?: string;
    phone_number?: string;
    avatar_url?: string;
  };
  average_rating?: number;
  review_count?: number;
};

type Review = {
  id: string;
  user_id: string;
  rating: number;
  comment: string;
  created_at: string;
  profiles?: {
    full_name?: string;
    avatar_url?: string;
  };
};

export const ProductDetailPage = () => {
  const { user } = useAuth();
  const [listing, setListing] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showImageModal, setShowImageModal] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const [favorited, setFavorited] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [userReview, setUserReview] = useState<Review | null>(null);
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    loadListing();
    incrementViews();
    loadReviews();
  }, []);

  const loadListing = async () => {
    const listingId = window.location.pathname.split('/product/')[1];

    if (!listingId) {
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('listings')
        .select(`
          *,
          categories(name, slug)
        `)
        .eq('id', listingId)
        .maybeSingle();

      if (error) {
        console.error('Error loading listing:', error);
      }

      if (data) {
        console.log('Listing loaded:', data);

        // Try to load profile separately
        const { data: profile } = await supabase
          .from('profiles')
          .select('full_name, phone_number, avatar_url')
          .eq('id', data.user_id)
          .maybeSingle();

        if (profile) {
          data.profiles = profile;
        }

        setListing(data);
      } else {
        console.log('No listing data found for ID:', listingId);
      }
    } catch (err) {
      console.error('Exception loading listing:', err);
    }

    setLoading(false);
  };

  const loadReviews = async () => {
    const listingId = window.location.pathname.split('/product/')[1];
    if (!listingId) return;

    const { data: reviewsData } = await supabase
      .from('listing_reviews')
      .select(`
        *,
        profiles:user_id(full_name, avatar_url)
      `)
      .eq('listing_id', listingId)
      .order('created_at', { ascending: false });

    if (reviewsData) {
      setReviews(reviewsData as any);
      if (user) {
        const userReviewData = reviewsData.find((r: any) => r.user_id === user.id);
        if (userReviewData) {
          setUserReview(userReviewData as any);
          setNewRating(userReviewData.rating);
          setNewComment(userReviewData.comment || '');
        }
      }
    }
  };

  const submitReview = async () => {
    if (!user || !listing) return;
    setSubmittingReview(true);

    if (userReview) {
      await supabase
        .from('listing_reviews')
        .update({
          rating: newRating,
          comment: newComment,
          updated_at: new Date().toISOString()
        })
        .eq('id', userReview.id);
    } else {
      await supabase
        .from('listing_reviews')
        .insert({
          listing_id: listing.id,
          user_id: user.id,
          rating: newRating,
          comment: newComment
        });
    }

    setSubmittingReview(false);
    loadReviews();
    loadListing();
  };

  const deleteReview = async () => {
    if (!userReview) return;
    await supabase.from('listing_reviews').delete().eq('id', userReview.id);
    setUserReview(null);
    setNewRating(5);
    setNewComment('');
    loadReviews();
    loadListing();
  };

  const incrementViews = async () => {
    const listingId = window.location.pathname.split('/product/')[1];
    await supabase.rpc('increment_listing_views', { listing_id: listingId }).catch(() => {});
  };

  const handleAddToCart = async () => {
    if (!user || !listing) return;

    const { error } = await supabase
      .from('cart_items')
      .insert({
        user_id: user.id,
        listing_id: listing.id,
        quantity: 1
      });

    if (!error) {
      setAddedToCart(true);
      setTimeout(() => setAddedToCart(false), 3000);
    }
  };

  const handleMessageSeller = () => {
    setShowChat(true);
  };

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({
        title: listing?.title,
        text: listing?.description,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  const nextImage = () => {
    if (listing && listing.images.length > 0) {
      setCurrentImageIndex((prev) => (prev + 1) % listing.images.length);
    }
  };

  const prevImage = () => {
    if (listing && listing.images.length > 0) {
      setCurrentImageIndex((prev) => (prev - 1 + listing.images.length) % listing.images.length);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full"></div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex-1 flex items-center justify-center px-4">
          <div className="text-center">
            <AlertCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Listing Not Found</h2>
            <p className="text-gray-600 mb-6">This listing may have been removed or is no longer available.</p>
            <a href="/" className="px-6 py-3 bg-orange-500 text-white rounded-xl hover:bg-orange-600 transition-colors inline-block">
              Back to Home
            </a>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const sellerName = listing.profiles?.full_name || 'Anonymous Seller';
  const isVerified = false;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Images */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6">
              {listing.images && listing.images.length > 0 && listing.images[0] ? (
                <div className="relative">
                  <img
                    src={listing.images[currentImageIndex]}
                    alt={listing.title}
                    className="w-full h-96 object-cover cursor-pointer"
                    onClick={() => setShowImageModal(true)}
                  />
                  {listing.images.length > 1 && (
                    <>
                      <button
                        onClick={prevImage}
                        className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg transition-colors"
                      >
                        <ChevronLeft className="w-6 h-6 text-gray-800" />
                      </button>
                      <button
                        onClick={nextImage}
                        className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg transition-colors"
                      >
                        <ChevronRight className="w-6 h-6 text-gray-800" />
                      </button>
                      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
                        {currentImageIndex + 1} / {listing.images.length}
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <div className="w-full h-96 bg-gray-200 flex items-center justify-center">
                  <span className="text-gray-400 text-lg">No image available</span>
                </div>
              )}

              {listing.images && listing.images.length > 1 && (
                <div className="p-4 flex gap-2 overflow-x-auto">
                  {listing.images.map((img, idx) => (
                    <img
                      key={idx}
                      src={img}
                      alt={`${listing.title} ${idx + 1}`}
                      className={`w-20 h-20 object-cover rounded-lg cursor-pointer border-2 transition-all ${
                        idx === currentImageIndex ? 'border-orange-500 ring-2 ring-orange-200' : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setCurrentImageIndex(idx)}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Description */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Description</h2>
              <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{listing.description}</p>

              {listing.condition && (
                <div className="mt-6 flex items-center gap-2">
                  <span className="text-gray-600 font-semibold">Condition:</span>
                  <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                    {listing.condition}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Right Column - Details & Actions */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg p-6 sticky top-8">
              {listing.categories && (
                <div className="text-sm text-orange-600 font-semibold mb-2">
                  {listing.categories.name}
                </div>
              )}

              <h1 className="text-3xl font-bold text-gray-900 mb-4">{listing.title}</h1>

              {/* Rating Display */}
              {listing.average_rating && listing.review_count ? (
                <button
                  onClick={() => {
                    document.getElementById('reviews-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="flex items-center gap-2 mb-4 px-4 py-2 bg-amber-50 border-2 border-amber-200 rounded-xl hover:bg-amber-100 transition-colors"
                >
                  <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                  <span className="font-bold text-gray-900">{listing.average_rating}</span>
                  <span className="text-gray-600">({listing.review_count} reviews)</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    document.getElementById('reviews-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="flex items-center gap-2 mb-4 px-4 py-2 bg-gray-50 border-2 border-gray-200 rounded-xl hover:bg-gray-100 transition-colors"
                >
                  <Star className="w-5 h-5 text-gray-400" />
                  <span className="text-gray-600">No reviews yet</span>
                </button>
              )}

              <div className="text-4xl font-bold text-orange-600 mb-6">
                {listing.currency} {listing.price.toLocaleString()}
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 mb-6">
                {listing.contact_phone && (
                  <div className="grid grid-cols-2 gap-3">
                    <a
                      href={`tel:${listing.contact_phone}`}
                      className="px-6 py-3 bg-green-600 text-white rounded-xl font-semibold hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <Phone className="w-5 h-5" />
                      Call
                    </a>
                    <a
                      href={`https://wa.me/${(listing.profiles?.phone_number || listing.contact_phone || '').replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                        `Hi, I'm interested in your listing on RentSaleStay:\n\n` +
                        `*${listing.title}*\n` +
                        `Price: ${listing.currency} ${listing.price.toLocaleString()}\n` +
                        `Location: ${listing.location_city || ''}, ${listing.location_state || ''}\n\n` +
                        `Link: ${window.location.href}`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 bg-[#25D366] text-white rounded-xl font-semibold hover:bg-[#20BD5A] transition-colors flex items-center justify-center gap-2"
                    >
                      <MessageCircle className="w-5 h-5" />
                      WhatsApp
                    </a>
                  </div>
                )}
                {user && user.id !== listing.user_id && (
                  <>
                    <button
                      onClick={handleAddToCart}
                      className="w-full px-6 py-3 bg-orange-500 text-white rounded-xl font-semibold hover:bg-orange-600 transition-colors flex items-center justify-center gap-2"
                    >
                      <ShoppingCart className="w-5 h-5" />
                      {addedToCart ? 'Added to Cart!' : 'Add to Cart'}
                    </button>
                    <button
                      onClick={handleMessageSeller}
                      className="w-full px-6 py-3 bg-blue-500 text-white rounded-xl font-semibold hover:bg-blue-600 transition-colors flex items-center justify-center gap-2"
                    >
                      <MessageCircle className="w-5 h-5" />
                      Message Seller
                    </button>
                  </>
                )}
                <button
                  onClick={handleShare}
                  className="w-full px-6 py-3 bg-gray-100 text-gray-700 rounded-xl font-semibold hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
                >
                  <Share2 className="w-5 h-5" />
                  Share
                </button>
              </div>

              {/* Seller Info */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-bold text-gray-900 mb-3">Seller Information</h3>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    {sellerName[0].toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-gray-900 text-lg">{sellerName}</span>
                      {isVerified && (
                        <CheckCircle className="w-5 h-5 text-blue-500" title="Verified Seller" />
                      )}
                    </div>
                    {listing.average_rating && listing.review_count ? (
                      <div className="flex items-center gap-1 mt-1">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                        <span className="font-semibold text-gray-900">{listing.average_rating}</span>
                        <span className="text-sm text-gray-500">({listing.review_count} reviews)</span>
                      </div>
                    ) : null}
                  </div>
                </div>
              </div>

              {/* Location */}
              {(listing.location_city || listing.location_state) && (
                <div className="border-t pt-6">
                  <div className="flex items-start gap-2 text-gray-700">
                    <MapPin className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                    <span>
                      {[listing.location_city, listing.location_state].filter(Boolean).join(', ')}
                    </span>
                  </div>
                </div>
              )}

              {/* Contact */}
              {(listing.contact_phone || listing.contact_email) && (
                <div className="border-t pt-6 space-y-3">
                  {listing.contact_phone && (
                    <div className="flex items-center gap-2 text-gray-700">
                      <Phone className="w-5 h-5 text-gray-400 flex-shrink-0" />
                      <a href={`tel:${listing.contact_phone}`} className="hover:text-orange-600 transition-colors">
                        {listing.contact_phone}
                      </a>
                    </div>
                  )}
                  {listing.contact_email && (
                    <div className="flex items-center gap-2 text-gray-700">
                      <Mail className="w-5 h-5 text-gray-400 flex-shrink-0" />
                      <a href={`mailto:${listing.contact_email}`} className="hover:text-orange-600 transition-colors break-all">
                        {listing.contact_email}
                      </a>
                    </div>
                  )}
                </div>
              )}

              {/* Posted Date */}
              <div className="border-t pt-6">
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Calendar className="w-4 h-4" />
                  Posted {new Date(listing.created_at).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews and Ratings Section */}
        <div id="reviews-section" className="mt-8 bg-white rounded-2xl shadow-lg p-6 scroll-mt-20">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Reviews & Ratings</h2>

          {/* Overall Rating Summary */}
          {listing.review_count && listing.review_count > 0 ? (
            <div className="flex items-center gap-6 mb-8 pb-8 border-b">
              <div className="text-center">
                <div className="text-5xl font-bold text-gray-900 mb-2">{listing.average_rating}</div>
                <div className="flex items-center justify-center gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-5 h-5 ${
                        star <= (listing.average_rating || 0)
                          ? 'text-amber-400 fill-amber-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <div className="text-sm text-gray-500">{listing.review_count} reviews</div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 mb-8 border-b">
              <div className="text-gray-400 mb-2">No reviews yet</div>
              <div className="text-sm text-gray-500">Be the first to review this listing</div>
            </div>
          )}

          {/* Write/Edit Review */}
          {user && user.id !== listing.user_id && (
            <div className="mb-8 pb-8 border-b">
              <h3 className="text-lg font-bold text-gray-900 mb-4">
                {userReview ? 'Edit Your Review' : 'Write a Review'}
              </h3>
              <div className="mb-4">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Rating</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setNewRating(star)}
                      className="focus:outline-none"
                    >
                      <Star
                        className={`w-8 h-8 transition-colors ${
                          star <= newRating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-gray-300 hover:text-amber-200'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Comment</label>
                <textarea
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Share your experience with this product..."
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-orange-500 focus:outline-none resize-none"
                  rows={4}
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={submitReview}
                  disabled={submittingReview}
                  className="px-6 py-3 bg-orange-500 text-white rounded-xl font-semibold hover:bg-orange-600 transition-colors disabled:opacity-50"
                >
                  {submittingReview ? 'Submitting...' : userReview ? 'Update Review' : 'Submit Review'}
                </button>
                {userReview && (
                  <button
                    onClick={deleteReview}
                    className="px-6 py-3 bg-red-500 text-white rounded-xl font-semibold hover:bg-red-600 transition-colors"
                  >
                    Delete Review
                  </button>
                )}
              </div>
            </div>
          )}

          {!user && (
            <div className="mb-8 pb-8 border-b text-center">
              <p className="text-gray-600 mb-4">Sign in to write a review</p>
              <a
                href="/login"
                className="inline-block px-6 py-3 bg-orange-500 text-white rounded-xl font-semibold hover:bg-orange-600 transition-colors"
              >
                Sign In
              </a>
            </div>
          )}

          {/* Reviews List */}
          <div className="space-y-6">
            {reviews.map((review) => (
              <div key={review.id} className="border-b pb-6 last:border-b-0">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-gray-400 to-gray-600 rounded-full flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                    {review.profiles?.full_name?.[0]?.toUpperCase() || 'U'}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <div className="font-bold text-gray-900">
                          {review.profiles?.full_name || 'Anonymous User'}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="flex items-center gap-1">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-4 h-4 ${
                                  star <= review.rating
                                    ? 'text-amber-400 fill-amber-400'
                                    : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-500">
                            {new Date(review.created_at).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                    {review.comment && (
                      <p className="text-gray-700 leading-relaxed">{review.comment}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Image Modal */}
      {showImageModal && listing.images && listing.images.length > 0 && listing.images[0] && (
        <div
          className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4"
          onClick={() => setShowImageModal(false)}
        >
          <button
            onClick={() => setShowImageModal(false)}
            className="absolute top-4 right-4 text-white hover:text-gray-300 transition-colors"
          >
            <X className="w-8 h-8" />
          </button>
          <img
            src={listing.images[currentImageIndex]}
            alt={listing.title}
            className="max-w-full max-h-full object-contain"
            onClick={(e) => e.stopPropagation()}
          />
          {listing.images.length > 1 && (
            <>
              <button
                onClick={(e) => { e.stopPropagation(); prevImage(); }}
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 p-3 rounded-full transition-colors"
              >
                <ChevronLeft className="w-8 h-8 text-white" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); nextImage(); }}
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 p-3 rounded-full transition-colors"
              >
                <ChevronRight className="w-8 h-8 text-white" />
              </button>
            </>
          )}
        </div>
      )}

      {/* Chat Modal */}
      {showChat && listing && (
        <ChatBox
          listingId={listing.id}
          sellerId={listing.user_id}
          sellerName={sellerName}
          listingTitle={listing.title}
          onClose={() => setShowChat(false)}
        />
      )}

      <Footer />
    </div>
  );
};
