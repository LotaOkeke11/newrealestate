import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  Car, MapPin, Calendar, Gauge, Fuel, Settings, Heart, Share2,
  Shield, Phone, MessageCircle, ChevronLeft, ChevronRight, Check, X
} from 'lucide-react';

type CarListing = {
  id: string;
  title: string;
  description: string;
  price: number;
  images: string[];
  vehicle_make: string;
  vehicle_model: string;
  vehicle_year: number;
  vehicle_condition: string;
  mileage: number;
  transmission: string;
  fuel_type: string;
  body_type: string;
  exterior_color: string;
  interior_color: string;
  engine_size: string;
  seats: number;
  doors: number;
  registered_city: string;
  customs_duty: string;
  accident_history: string;
  vin: string;
  features: any;
  price_negotiable: boolean;
  location_state: string;
  location_city: string;
  contact_phone: string;
  contact_whatsapp: string;
  created_at: string;
  user_id: string;
  profiles: {
    full_name: string;
    verification_level: number;
  };
};

export const CarDetailPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [listing, setListing] = useState<CarListing | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showPhone, setShowPhone] = useState(false);

  useEffect(() => {
    loadListing();
  }, []);

  const loadListing = async () => {
    const id = window.location.pathname.split('/car/')[1];
    const { data, error } = await supabase
      .from('listings')
      .select(`
        *,
        profiles:user_id (
          full_name,
          verification_level
        )
      `)
      .eq('id', id)
      .maybeSingle();

    if (data) setListing(data);
    setLoading(false);
  };

  const nextImage = () => {
    if (listing) {
      setCurrentImageIndex((prev) => (prev + 1) % listing.images.length);
    }
  };

  const prevImage = () => {
    if (listing) {
      setCurrentImageIndex((prev) => (prev - 1 + listing.images.length) % listing.images.length);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center"><p className="text-2xl font-bold text-gray-900">Car not found</p></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <a href="/" className="inline-flex items-center text-orange-600 hover:text-orange-700 font-semibold mb-4">
            ← Back to listings
          </a>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-xl shadow-md overflow-hidden">
                <div className="relative aspect-video bg-gray-900">
                  {listing.images && listing.images.length > 0 && (
                    <>
                      <img
                        src={listing.images[currentImageIndex]}
                        alt={listing.title}
                        className="w-full h-full object-contain"
                      />
                      {listing.images.length > 1 && (
                        <>
                          <button
                            onClick={prevImage}
                            className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center backdrop-blur-sm"
                          >
                            <ChevronLeft className="w-6 h-6" />
                          </button>
                          <button
                            onClick={nextImage}
                            className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center backdrop-blur-sm"
                          >
                            <ChevronRight className="w-6 h-6" />
                          </button>
                          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                            {listing.images.map((_, idx) => (
                              <button
                                key={idx}
                                onClick={() => setCurrentImageIndex(idx)}
                                className={`w-2 h-2 rounded-full transition-all ${
                                  idx === currentImageIndex ? 'bg-white w-8' : 'bg-white/50'
                                }`}
                              />
                            ))}
                          </div>
                        </>
                      )}
                    </>
                  )}
                </div>

                <div className="grid grid-cols-6 gap-2 p-4 bg-gray-100">
                  {listing.images?.slice(0, 6).map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentImageIndex(idx)}
                      className={`aspect-video rounded-lg overflow-hidden border-2 ${
                        idx === currentImageIndex ? 'border-orange-500' : 'border-transparent'
                      }`}
                    >
                      <img src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-gray-900 mb-3">{listing.title}</h1>
                    <div className="flex items-center gap-4 text-gray-600 mb-3">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {listing.location_city}, {listing.location_state}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {new Date(listing.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        const reviewsSection = document.querySelector('[data-reviews-section]');
                        reviewsSection?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="inline-flex items-center gap-2 px-4 py-2 bg-amber-50 border-2 border-amber-200 rounded-xl hover:bg-amber-100 transition-colors"
                    >
                      <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                      <span className="font-bold text-gray-900">View Reviews</span>
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <button className="p-3 border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Heart className="w-5 h-5" />
                    </button>
                    <button className="p-3 border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h2 className="text-xl font-bold text-gray-900 mb-4">Vehicle Details</h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Make</div>
                      <div className="font-bold text-gray-900">{listing.vehicle_make}</div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Model</div>
                      <div className="font-bold text-gray-900">{listing.vehicle_model}</div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Year</div>
                      <div className="font-bold text-gray-900">{listing.vehicle_year}</div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Condition</div>
                      <div className="font-bold text-gray-900">{listing.vehicle_condition}</div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Mileage</div>
                      <div className="font-bold text-gray-900">{listing.mileage?.toLocaleString()} km</div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Transmission</div>
                      <div className="font-bold text-gray-900">{listing.transmission}</div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Fuel Type</div>
                      <div className="font-bold text-gray-900">{listing.fuel_type}</div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Body Type</div>
                      <div className="font-bold text-gray-900">{listing.body_type}</div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Exterior Color</div>
                      <div className="font-bold text-gray-900">{listing.exterior_color}</div>
                    </div>
                    {listing.interior_color && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Interior Color</div>
                        <div className="font-bold text-gray-900">{listing.interior_color}</div>
                      </div>
                    )}
                    {listing.engine_size && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Engine Size</div>
                        <div className="font-bold text-gray-900">{listing.engine_size}</div>
                      </div>
                    )}
                    {listing.registered_city && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Registered</div>
                        <div className="font-bold text-gray-900">{listing.registered_city}</div>
                      </div>
                    )}
                    {listing.customs_duty && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Customs Duty</div>
                        <div className="font-bold text-gray-900 capitalize">{listing.customs_duty}</div>
                      </div>
                    )}
                    {listing.accident_history && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600 mb-1">Accident History</div>
                        <div className="font-bold text-gray-900 capitalize">{listing.accident_history}</div>
                      </div>
                    )}
                  </div>
                </div>

                {listing.features && Object.values(listing.features).some((v) => v) && (
                  <div className="border-t pt-6 mt-6">
                    <h2 className="text-xl font-bold text-gray-900 mb-4">Features</h2>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {Object.entries(listing.features).map(([key, value]) =>
                        value ? (
                          <div key={key} className="flex items-center gap-2 p-3 bg-green-50 rounded-lg">
                            <Check className="w-5 h-5 text-green-600" />
                            <span className="font-semibold text-gray-900 capitalize">
                              {key.replace(/([A-Z])/g, ' $1').trim()}
                            </span>
                          </div>
                        ) : null
                      )}
                    </div>
                  </div>
                )}

                {listing.description && (
                  <div className="border-t pt-6 mt-6">
                    <h2 className="text-xl font-bold text-gray-900 mb-4">Description</h2>
                    <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{listing.description}</p>
                  </div>
                )}

                <div className="border-t pt-6 mt-6">
                  <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
                    <Shield className="w-6 h-6 text-blue-600" />
                    <div>
                      <p className="font-bold text-gray-900">Safety Tips</p>
                      <p className="text-sm text-gray-700">Meet in a safe public place. Check vehicle documents. Test drive before payment.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-md p-6 sticky top-6">
                <div className="mb-6">
                  <div className="text-3xl font-bold text-orange-600 mb-2">
                    ₦{listing.price.toLocaleString()}
                    {listing.price_negotiable && (
                      <span className="text-sm text-gray-600 font-normal ml-2">(Negotiable)</span>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  {listing.contact_phone && (
                    <div className="grid grid-cols-2 gap-3">
                      <a
                        href={`tel:${listing.contact_phone}`}
                        className="py-4 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
                      >
                        <Phone className="w-5 h-5" />
                        Call
                      </a>
                      <a
                        href={`https://wa.me/${(listing.contact_whatsapp || listing.contact_phone).replace(/\D/g, '')}?text=${encodeURIComponent(`Hi, I'm interested in: ${listing.title}`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-4 bg-[#25D366] hover:bg-[#20BD5A] text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
                      >
                        <MessageCircle className="w-5 h-5" />
                        WhatsApp
                      </a>
                    </div>
                  )}
                </div>

                <div className="mt-6 pt-6 border-t">
                  <p className="text-sm text-gray-600 mb-3 font-semibold">Seller Information</p>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                      {listing.profiles?.full_name?.charAt(0)?.toUpperCase() || 'U'}
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-gray-900 text-lg">{listing.profiles?.full_name || 'Anonymous Seller'}</p>
                      {listing.profiles?.verification_level > 0 && (
                        <div className="flex items-center gap-1 text-sm text-green-600 mt-1">
                          <Shield className="w-4 h-4" />
                          Verified Seller
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-orange-50 border-2 border-orange-200 rounded-xl p-6">
                <h3 className="font-bold text-gray-900 mb-3">Safety First</h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Meet seller in public place</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Verify vehicle documents</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Test drive before payment</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <X className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                    <span>Never pay in advance</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};
