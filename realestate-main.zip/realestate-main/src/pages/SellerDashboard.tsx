import { useAuth } from '../contexts/AuthContext';
import { Header } from '../components/Header';
import { Package } from 'lucide-react';

export const SellerDashboard = () => {
  const { profile } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Seller Dashboard</h1>
            <p className="text-gray-600 mt-1">Welcome back, {profile?.full_name}</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md border border-amber-100 p-12">
          <div className="text-center">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600 mb-4">Your dashboard is ready! Start posting ads to see analytics here.</p>
            <a
              href="/register"
              className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-lg font-semibold hover:from-amber-600 hover:to-amber-700 transition-all"
            >
              Get Started
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
