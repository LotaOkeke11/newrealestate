import { useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Video, X, CheckCircle2, AlertCircle, Image as ImageIcon, Sparkles, Zap, Film } from 'lucide-react';

export const UploadMediaCreativePage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [videoFile, setVideoFile] = useState<File | null>(null);

  const [formData, setFormData] = useState({
    equipmentType: '',
    brand: '',
    model: '',
    condition: '',
    price: '',
    specifications: '',
    accessories: '',
    warranty: '',
    description: '',
    locationState: '',
    locationCity: '',
    isRental: false,
    dailyRate: '',
    weeklyRate: '',
    monthlyRate: '',
    depositRequired: '',
    contactPhone: '',
    contactWhatsapp: '',
    priceNegotiable: false
  });

  const equipmentTypes = [
    'Lighting Equipment', 'Softboxes & Reflectors', 'LED Panels', 'Studio Lights',
    'Audio Equipment', 'Microphones', 'Audio Interfaces', 'Mixers', 'Studio Monitors',
    'DJ Equipment', 'Turntables', 'Controllers', 'Drones', 'Gimbals', 'Stabilizers',
    'Tripods', 'Monopods', 'Sliders', 'Jibs & Cranes', 'Green Screens', 'Backdrops',
    'Props', 'Editing Software', 'Plugins', 'Other'
  ];

  const brands = [
    'Godox', 'Aputure', 'Nanlite', 'Neewer', 'Shure', 'Sennheiser', 'Rode',
    'Audio-Technica', 'Behringer', 'Focusrite', 'Yamaha', 'Pioneer', 'Numark',
    'DJI', 'Zhiyun', 'Manfrotto', 'Benro', 'Adobe', 'Final Cut Pro', 'DaVinci Resolve', 'Other'
  ];

  const conditions = ['Brand New', 'Like New', 'Excellent', 'Good', 'Fair'];

  const warrantyOptions = ['No Warranty', 'Manufacturer Warranty', 'Seller Warranty', 'Extended Warranty'];

  const nigeriaStates = [
    'Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo', 'Kaduna', 'Anambra', 'Enugu',
    'Delta', 'Edo', 'Ogun', 'Ondo', 'Osun', 'Kwara', 'Plateau', 'Benue'
  ];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + imageFiles.length > 10) {
      setError('Maximum 10 images allowed');
      return;
    }
    setImageFiles((prev) => [...prev, ...files]);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreviews((prev) => [...prev, reader.result as string]);
      reader.readAsDataURL(file);
    });
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 100 * 1024 * 1024) {
        setError('Video must be less than 100MB');
        return;
      }
      setVideoFile(file);
    }
  };

  const removeImage = (index: number) => {
    setImageFiles((prev) => prev.filter((_, i) => i !== index));
    setImagePreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (!user) throw new Error('Please sign in');
      if (imageFiles.length < 2) throw new Error('Upload at least 2 images');

      const imageUrls: string[] = [];
      for (let i = 0; i < imageFiles.length; i++) {
        const file = imageFiles[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/media-${Date.now()}-${i}.${fileExt}`;
        const { error: uploadError } = await supabase.storage.from('listing-images').upload(fileName, file);
        if (!uploadError) {
          const { data: urlData } = supabase.storage.from('listing-images').getPublicUrl(fileName);
          imageUrls.push(urlData.publicUrl);
        }
      }

      let videoUrl = null;
      if (videoFile) {
        const videoExt = videoFile.name.split('.').pop();
        const videoFileName = `${user.id}/video-${Date.now()}.${videoExt}`;
        const { error: videoError } = await supabase.storage.from('listing-images').upload(videoFileName, videoFile);
        if (!videoError) {
          const { data: urlData } = supabase.storage.from('listing-images').getPublicUrl(videoFileName);
          videoUrl = urlData.publicUrl;
        }
      }

      const { data: category } = await supabase.from('categories').select('id, slug').eq('slug', 'media-creative').maybeSingle();

      const listingData = {
        user_id: user.id,
        category_id: category?.id,
        title: `${formData.brand} ${formData.model || formData.equipmentType}`.trim(),
        description: formData.description,
        price: formData.isRental ? 0 : parseFloat(formData.price),
        currency: 'NGN',
        condition: formData.condition,
        images: imageUrls,
        video_url: videoUrl,
        equipment_type: formData.equipmentType,
        brand: formData.brand,
        model: formData.model,
        specifications: {
          specs: formData.specifications,
          accessories: formData.accessories
        },
        warranty_status: formData.warranty,
        is_rental: formData.isRental,
        daily_rate: formData.dailyRate ? parseFloat(formData.dailyRate) : null,
        price_per_unit: formData.weeklyRate,
        monthly_rate: formData.monthlyRate ? parseFloat(formData.monthlyRate) : null,
        deposit_required: formData.depositRequired ? parseFloat(formData.depositRequired) : null,
        price_negotiable: formData.priceNegotiable,
        location_state: formData.locationState,
        location_city: formData.locationCity,
        contact_phone: formData.contactPhone,
        contact_whatsapp: formData.contactWhatsapp,
        status: 'active'
      };

      const { data: listing, error: listingError } = await supabase.from('listings').insert(listingData).select().single();
      if (listingError) throw listingError;
      setSuccess(true);
      setTimeout(() => {
        window.location.href = category?.slug ? `/category/${category.slug}` : '/';
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    window.location.href = '/post-ad';
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-yellow-50 to-amber-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />
      <main className="flex-1">
        <div className="bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-600 text-white py-12 px-4 shadow-2xl">
          <div className="max-w-5xl mx-auto">
            <a href="/post-ad" className="text-white/90 hover:text-white text-sm font-bold mb-4 inline-block">← Back</a>
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <Sparkles className="w-10 h-10 text-yellow-300 animate-pulse" />
                  <h1 className="text-5xl font-black">Media & Creative Equipment</h1>
                </div>
                <p className="text-white/95 text-xl font-semibold">Professional gear for videographers, photographers & content creators</p>
              </div>
              <div className="hidden md:flex w-24 h-24 bg-white/20 rounded-3xl items-center justify-center backdrop-blur-sm">
                <Film className="w-12 h-12 text-white" />
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-5xl mx-auto px-4 py-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {success && (
              <div className="p-6 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-300 rounded-2xl flex items-start gap-4 shadow-lg">
                <CheckCircle2 className="w-7 h-7 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-black text-green-900 text-xl">Success!</p>
                  <p className="text-green-800 text-sm font-semibold">Your equipment listing is now live</p>
                </div>
              </div>
            )}
            {error && (
              <div className="p-6 bg-gradient-to-r from-red-50 to-pink-50 border-2 border-red-300 rounded-2xl flex items-start gap-4 shadow-lg">
                <AlertCircle className="w-7 h-7 text-red-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-red-800 font-semibold">{error}</span>
              </div>
            )}

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-orange-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-orange-400 to-amber-400">Equipment Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Equipment Type *</label>
                  <select
                    value={formData.equipmentType}
                    onChange={(e) => setFormData({ ...formData, equipmentType: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                  >
                    <option value="">Select type</option>
                    {equipmentTypes.map((type) => <option key={type} value={type}>{type}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Brand *</label>
                  <select
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                  >
                    <option value="">Select brand</option>
                    {brands.map((brand) => <option key={brand} value={brand}>{brand}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Model *</label>
                  <input
                    type="text"
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    placeholder="e.g., 300D II, SM7B, Mavic 3"
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Condition *</label>
                  <select
                    value={formData.condition}
                    onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                  >
                    <option value="">Select condition</option>
                    {conditions.map((cond) => <option key={cond} value={cond}>{cond}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-amber-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-amber-400 to-yellow-400">Specifications & Accessories</h2>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Specifications</label>
                  <textarea
                    value={formData.specifications}
                    onChange={(e) => setFormData({ ...formData, specifications: e.target.value })}
                    placeholder="Technical specs, features, capabilities..."
                    rows={3}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Included Accessories</label>
                  <textarea
                    value={formData.accessories}
                    onChange={(e) => setFormData({ ...formData, accessories: e.target.value })}
                    placeholder="Cases, cables, batteries, mounts, etc..."
                    rows={3}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Warranty</label>
                  <select
                    value={formData.warranty}
                    onChange={(e) => setFormData({ ...formData, warranty: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                  >
                    <option value="">Select warranty</option>
                    {warrantyOptions.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-orange-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-orange-400 to-amber-400">Photos & Video</h2>
              <div className="border-4 border-dashed border-amber-300 rounded-2xl p-10 text-center hover:border-amber-500 bg-gradient-to-br from-amber-50 to-yellow-50 transition-all mb-6">
                <ImageIcon className="w-20 h-20 text-amber-400 mx-auto mb-5" />
                <p className="text-gray-900 mb-2 font-black text-xl">Upload equipment photos</p>
                <p className="text-sm text-gray-600 mb-5 font-semibold">Up to 10 images (Min 2 required)</p>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                  id="image-upload"
                />
                <label
                  htmlFor="image-upload"
                  className="px-10 py-4 bg-gradient-to-r from-orange-500 to-amber-600 text-white rounded-xl cursor-pointer hover:from-orange-600 hover:to-amber-700 inline-block font-black text-lg transition-all shadow-lg"
                >
                  Choose Photos
                </label>
              </div>
              {imagePreviews.length > 0 && (
                <div className="mb-6">
                  <p className="font-black text-gray-900 mb-4 text-xl">{imagePreviews.length} photo(s) selected</p>
                  <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative aspect-square rounded-2xl overflow-hidden border-4 border-amber-200 group shadow-lg">
                        <img src={preview} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full hover:bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <div className="border-4 border-dashed border-orange-300 rounded-2xl p-10 text-center hover:border-orange-500 bg-gradient-to-br from-orange-50 to-amber-50 transition-all">
                <Video className="w-20 h-20 text-orange-400 mx-auto mb-5" />
                <p className="text-gray-900 mb-2 font-black text-xl">Upload demo video (Optional)</p>
                <p className="text-sm text-gray-600 mb-5 font-semibold">Max 100MB</p>
                <input
                  type="file"
                  accept="video/*"
                  onChange={handleVideoChange}
                  className="hidden"
                  id="video-upload"
                />
                <label
                  htmlFor="video-upload"
                  className="px-10 py-4 bg-gradient-to-r from-orange-500 to-amber-600 text-white rounded-xl cursor-pointer hover:from-orange-600 hover:to-amber-700 inline-block font-black text-lg transition-all shadow-lg"
                >
                  {videoFile ? `Video Selected: ${videoFile.name}` : 'Choose Video'}
                </label>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-amber-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-amber-400 to-yellow-400">Description</h2>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe your equipment: usage history, condition details, why you're selling, ideal use cases..."
                rows={6}
                required
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
              />
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-orange-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-orange-400 to-amber-400">Location</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">State *</label>
                  <select
                    value={formData.locationState}
                    onChange={(e) => setFormData({ ...formData, locationState: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 font-semibold"
                  >
                    <option value="">Select state</option>
                    {nigeriaStates.map((state) => <option key={state} value={state}>{state}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">City/Area *</label>
                  <input
                    type="text"
                    value={formData.locationCity}
                    onChange={(e) => setFormData({ ...formData, locationCity: e.target.value })}
                    placeholder="e.g., Lekki, Ikeja"
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 font-semibold"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-amber-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-amber-400 to-yellow-400">Pricing & Contact</h2>
              <div className="space-y-6">
                <label className="flex items-center gap-4 p-5 border-4 border-amber-200 rounded-xl cursor-pointer hover:border-amber-400 transition-all bg-amber-50">
                  <input
                    type="checkbox"
                    checked={formData.isRental}
                    onChange={(e) => setFormData({ ...formData, isRental: e.target.checked })}
                    className="w-6 h-6 text-amber-600 rounded focus:ring-amber-500"
                  />
                  <span className="font-black text-gray-900 text-lg">Available for Rent</span>
                </label>

                {!formData.isRental ? (
                  <div>
                    <label className="block text-sm font-black text-gray-800 mb-2">Price (₦) *</label>
                    <div className="relative">
                      <div className="absolute left-5 top-1/2 -translate-y-1/2 text-3xl font-black text-amber-500">₦</div>
                      <input
                        type="number"
                        value={formData.price}
                        onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                        placeholder="0"
                        required={!formData.isRental}
                        min="0"
                        className="w-full pl-16 pr-4 py-5 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-2xl font-black"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-black text-gray-800 mb-2">Daily Rate (₦)</label>
                      <input
                        type="number"
                        value={formData.dailyRate}
                        onChange={(e) => setFormData({ ...formData, dailyRate: e.target.value })}
                        placeholder="0"
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-black text-gray-800 mb-2">Weekly Rate (₦)</label>
                      <input
                        type="text"
                        value={formData.weeklyRate}
                        onChange={(e) => setFormData({ ...formData, weeklyRate: e.target.value })}
                        placeholder="0"
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-black text-gray-800 mb-2">Monthly Rate (₦)</label>
                      <input
                        type="number"
                        value={formData.monthlyRate}
                        onChange={(e) => setFormData({ ...formData, monthlyRate: e.target.value })}
                        placeholder="0"
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-black text-gray-800 mb-2">Deposit Required (₦)</label>
                      <input
                        type="number"
                        value={formData.depositRequired}
                        onChange={(e) => setFormData({ ...formData, depositRequired: e.target.value })}
                        placeholder="0"
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                      />
                    </div>
                  </div>
                )}

                <label className="flex items-center gap-4 p-5 border-4 border-amber-200 rounded-xl cursor-pointer hover:border-amber-400 transition-all bg-amber-50">
                  <input
                    type="checkbox"
                    checked={formData.priceNegotiable}
                    onChange={(e) => setFormData({ ...formData, priceNegotiable: e.target.checked })}
                    className="w-6 h-6 text-amber-600 rounded focus:ring-amber-500"
                  />
                  <span className="font-black text-gray-900 text-lg">Price is negotiable</span>
                </label>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-black text-gray-800 mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      value={formData.contactPhone}
                      onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                      placeholder="+234 800 000 0000"
                      required
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-black text-gray-800 mb-2">WhatsApp (Optional)</label>
                    <input
                      type="tel"
                      value={formData.contactWhatsapp}
                      onChange={(e) => setFormData({ ...formData, contactWhatsapp: e.target.value })}
                      placeholder="+234 800 000 0000"
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-semibold"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-8 border-t-4 border-gray-200">
              <a
                href="/post-ad"
                className="px-10 py-4 border-4 border-gray-300 text-gray-700 rounded-xl font-black text-lg hover:bg-gray-50 transition-all"
              >
                Cancel
              </a>
              <button
                type="submit"
                disabled={loading || imageFiles.length < 2}
                className="px-16 py-4 bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-600 text-white rounded-xl font-black text-lg hover:from-orange-600 hover:via-amber-600 hover:to-yellow-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl flex items-center gap-3 transition-all"
              >
                {loading ? (
                  <>
                    <div className="animate-spin w-6 h-6 border-3 border-white border-t-transparent rounded-full"></div>
                    Publishing...
                  </>
                ) : (
                  <>
                    <Zap className="w-6 h-6" />
                    Publish Listing
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
};
