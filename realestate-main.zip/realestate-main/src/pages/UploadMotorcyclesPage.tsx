import { useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Bike, X, CheckCircle2, AlertCircle, Image as ImageIcon, Check } from 'lucide-react';

export const UploadMotorcyclesPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    make: '', model: '', year: '', condition: '', price: '', mileage: '', engineSize: '',
    transmission: '', fuelType: '', color: '', titleStatus: '', vin: '',
    registrationStatus: '', insuranceStatus: '', modifications: '', description: '',
    locationState: '', locationCity: '', priceNegotiable: false,
    contactPhone: '', contactWhatsapp: '',
    accessories: { helmet: false, jacket: false, gloves: false, bootsCoverIncluded: false, toolkit: false, extraKeys: false }
  });

  const bikeMakes = ['Honda', 'Yamaha', 'Suzuki', 'Kawasaki', 'Bajaj', 'TVS', 'Royal Enfield', 'Harley-Davidson', 'Ducati', 'KTM', 'BMW', 'Triumph', 'Indian', 'Benelli', 'Qlink', 'Zongshen', 'Jincheng', 'Haojue', 'Other'];
  const years = Array.from({ length: 40 }, (_, i) => new Date().getFullYear() - i);
  const conditions = ['Brand New', 'Foreign Used', 'Nigerian Used', 'Repaired'];
  const transmissions = ['Manual', 'Automatic', 'Semi-Automatic'];
  const fuelTypes = ['Petrol', 'Diesel', 'Electric', 'Hybrid'];
  const colors = ['Black', 'White', 'Red', 'Blue', 'Green', 'Silver', 'Yellow', 'Orange', 'Brown', 'Custom Paint', 'Other'];
  const titleStatuses = ['Clean Title', 'Salvage Title', 'Rebuilt Title', 'No Title'];
  const nigeriaStates = ['Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo', 'Kaduna', 'Anambra', 'Enugu', 'Delta', 'Edo', 'Ogun'];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + imageFiles.length > 12) { setError('Maximum 12 images'); return; }
    setImageFiles((prev) => [...prev, ...files]);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreviews((prev) => [...prev, reader.result as string]);
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImageFiles((prev) => prev.filter((_, i) => i !== index));
    setImagePreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (!user) throw new Error('Please sign in');
      if (imageFiles.length < 3) throw new Error('Upload at least 3 images');

      const imageUrls: string[] = [];
      for (let i = 0; i < imageFiles.length; i++) {
        const file = imageFiles[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/motorcycle-${Date.now()}-${i}.${fileExt}`;
        const { error: uploadError } = await supabase.storage.from('listing-images').upload(fileName, file);
        if (!uploadError) {
          const { data: urlData } = supabase.storage.from('listing-images').getPublicUrl(fileName);
          imageUrls.push(urlData.publicUrl);
        }
      }

      const { data: category } = await supabase.from('categories').select('id, slug').eq('slug', 'motorcycles').maybeSingle();

      const listingData = {
        user_id: user.id, category_id: category?.id,
        title: `${formData.make} ${formData.model} ${formData.year} - ${formData.engineSize}`.trim(),
        description: formData.description, price: parseFloat(formData.price), currency: 'NGN',
        images: imageUrls, vehicle_make: formData.make, vehicle_model: formData.model,
        vehicle_year: parseInt(formData.year), condition: formData.condition,
        mileage: formData.mileage ? parseInt(formData.mileage) : null,
        transmission: formData.transmission, fuel_type: formData.fuelType,
        exterior_color: formData.color, vin: formData.vin,
        specifications: {
          engine_size: formData.engineSize,
          title_status: formData.titleStatus,
          registration_status: formData.registrationStatus,
          insurance_status: formData.insuranceStatus,
          modifications: formData.modifications,
          accessories: formData.accessories
        },
        features: formData.accessories, price_negotiable: formData.priceNegotiable,
        location_state: formData.locationState, location_city: formData.locationCity,
        contact_phone: formData.contactPhone, contact_whatsapp: formData.contactWhatsapp, status: 'active'
      };

      const { data: listing, error: listingError } = await supabase.from('listings').insert(listingData).select().single();
      if (listingError) throw listingError;
      setSuccess(true);
      setTimeout(() => {
        window.location.href = category?.slug ? `/category/${category.slug}` : '/';
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) { window.location.href = '/post-ad'; return null; }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />
      <main className="flex-1">
        <div className="bg-gradient-to-r from-blue-600 via-blue-700 to-cyan-600 text-white py-8 px-4 shadow-xl">
          <div className="max-w-5xl mx-auto">
            <a href="/post-ad" className="text-white/90 hover:text-white text-sm font-semibold mb-3 inline-block">← Back</a>
            <div className="flex items-center justify-between">
              <div><h1 className="text-4xl font-bold mb-2">Sell Your Motorcycle</h1><p className="text-white/95 text-lg">List your bike and reach thousands of buyers</p></div>
              <div className="hidden md:block w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center"><Bike className="w-10 h-10 text-white" /></div>
            </div>
          </div>
        </div>

        <div className="max-w-5xl mx-auto px-4 py-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {success && <div className="p-5 bg-green-50 border-2 border-green-200 rounded-xl flex items-start gap-3"><CheckCircle2 className="w-6 h-6 text-green-500" /><div><p className="font-bold text-green-800 text-lg">Success!</p></div></div>}
            {error && <div className="p-5 bg-red-50 border-2 border-red-200 rounded-xl flex items-start gap-3"><AlertCircle className="w-6 h-6 text-red-500" /><span className="text-sm text-red-700">{error}</span></div>}

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-blue-200">Motorcycle Info</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Make *</label>
                  <select value={formData.make} onChange={(e) => setFormData({...formData, make: e.target.value})} required className="w-full px-4 py-3 border rounded-lg focus:border-blue-500">
                    <option value="">Select</option>{bikeMakes.map((m) => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Model *</label>
                  <input type="text" value={formData.model} onChange={(e) => setFormData({...formData, model: e.target.value})} placeholder="e.g., CBR 600" required className="w-full px-4 py-3 border rounded-lg focus:border-blue-500" />
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Year *</label>
                  <select value={formData.year} onChange={(e) => setFormData({...formData, year: e.target.value})} required className="w-full px-4 py-3 border rounded-lg focus:border-blue-500">
                    <option value="">Select</option>{years.map((y) => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Engine Size (CC) *</label>
                  <input type="text" value={formData.engineSize} onChange={(e) => setFormData({...formData, engineSize: e.target.value})} placeholder="e.g., 150cc, 250cc" required className="w-full px-4 py-3 border rounded-lg focus:border-blue-500" />
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Condition *</label>
                  <select value={formData.condition} onChange={(e) => setFormData({...formData, condition: e.target.value})} required className="w-full px-4 py-3 border rounded-lg focus:border-blue-500">
                    <option value="">Select</option>{conditions.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Mileage (km)</label>
                  <input type="number" value={formData.mileage} onChange={(e) => setFormData({...formData, mileage: e.target.value})} placeholder="25000" className="w-full px-4 py-3 border rounded-lg focus:border-blue-500" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-blue-200">Specifications</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Transmission</label>
                  <select value={formData.transmission} onChange={(e) => setFormData({...formData, transmission: e.target.value})} className="w-full px-4 py-3 border rounded-lg focus:border-blue-500">
                    <option value="">Select</option>{transmissions.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Fuel Type</label>
                  <select value={formData.fuelType} onChange={(e) => setFormData({...formData, fuelType: e.target.value})} className="w-full px-4 py-3 border rounded-lg focus:border-blue-500">
                    <option value="">Select</option>{fuelTypes.map((f) => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Color</label>
                  <select value={formData.color} onChange={(e) => setFormData({...formData, color: e.target.value})} className="w-full px-4 py-3 border rounded-lg focus:border-blue-500">
                    <option value="">Select</option>{colors.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Title Status</label>
                  <select value={formData.titleStatus} onChange={(e) => setFormData({...formData, titleStatus: e.target.value})} className="w-full px-4 py-3 border rounded-lg focus:border-blue-500">
                    <option value="">Select</option>{titleStatuses.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">VIN Number</label>
                  <input type="text" value={formData.vin} onChange={(e) => setFormData({...formData, vin: e.target.value})} placeholder="VIN" className="w-full px-4 py-3 border rounded-lg focus:border-blue-500" />
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Registration Status</label>
                  <input type="text" value={formData.registrationStatus} onChange={(e) => setFormData({...formData, registrationStatus: e.target.value})} placeholder="e.g., Lagos Registered" className="w-full px-4 py-3 border rounded-lg focus:border-blue-500" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-blue-200">Photos</h2>
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-blue-400 bg-gray-50">
                <ImageIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600 mb-2 font-semibold">Upload up to 12 images (Min 3)</p>
                <input type="file" multiple accept="image/*" onChange={handleImageChange} className="hidden" id="image-upload" />
                <label htmlFor="image-upload" className="px-6 py-3 bg-blue-600 text-white rounded-lg cursor-pointer hover:bg-blue-700 inline-block font-bold">Choose Images</label>
              </div>
              {imagePreviews.length > 0 && (
                <div className="mt-5">
                  <p className="font-bold text-gray-900 mb-3">{imagePreviews.length} image(s)</p>
                  <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative aspect-square rounded-lg overflow-hidden border-2 border-gray-200 group">
                        <img src={preview} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                        <button type="button" onClick={() => removeImage(index)} className="absolute top-1 right-1 p-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 opacity-0 group-hover:opacity-100"><X className="w-3 h-3" /></button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-blue-200">Description</h2>
              <textarea value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} placeholder="Describe your motorcycle, modifications, service history..." rows={5} required className="w-full px-4 py-3 border rounded-lg focus:border-blue-500" />
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-blue-200">Location</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div><label className="block text-sm font-bold text-gray-700 mb-2">State *</label>
                  <select value={formData.locationState} onChange={(e) => setFormData({...formData, locationState: e.target.value})} required className="w-full px-4 py-3 border rounded-lg focus:border-blue-500">
                    <option value="">Select</option>{nigeriaStates.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">City *</label>
                  <input type="text" value={formData.locationCity} onChange={(e) => setFormData({...formData, locationCity: e.target.value})} placeholder="Ikeja" required className="w-full px-4 py-3 border rounded-lg focus:border-blue-500" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-blue-200">Price & Contact</h2>
              <div className="space-y-5">
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Price (₦) *</label>
                  <div className="relative"><div className="absolute left-4 top-1/2 -translate-y-1/2 text-xl font-bold text-gray-400">₦</div>
                    <input type="number" value={formData.price} onChange={(e) => setFormData({...formData, price: e.target.value})} placeholder="0" required min="0" className="w-full pl-10 pr-4 py-4 border rounded-lg focus:border-blue-500 text-xl font-bold" />
                  </div>
                </div>
                <label className="flex items-center gap-2 p-3 border rounded-lg cursor-pointer hover:border-blue-400">
                  <input type="checkbox" checked={formData.priceNegotiable} onChange={(e) => setFormData({...formData, priceNegotiable: e.target.checked})} className="w-4 h-4 text-blue-600 rounded" />
                  <span className="font-semibold text-gray-900">Price negotiable</span>
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div><label className="block text-sm font-bold text-gray-700 mb-2">Phone *</label>
                    <input type="tel" value={formData.contactPhone} onChange={(e) => setFormData({...formData, contactPhone: e.target.value})} placeholder="+234" required className="w-full px-4 py-3 border rounded-lg focus:border-blue-500" />
                  </div>
                  <div><label className="block text-sm font-bold text-gray-700 mb-2">WhatsApp</label>
                    <input type="tel" value={formData.contactWhatsapp} onChange={(e) => setFormData({...formData, contactWhatsapp: e.target.value})} placeholder="+234" className="w-full px-4 py-3 border rounded-lg focus:border-blue-500" />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4">
              <a href="/post-ad" className="px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg font-bold hover:bg-gray-50">Cancel</a>
              <button type="submit" disabled={loading || imageFiles.length < 3} className="px-10 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg font-bold hover:from-blue-700 hover:to-cyan-700 disabled:opacity-50 shadow-lg flex items-center gap-2">
                {loading ? <><div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>Publishing...</> : <><Check className="w-5 h-5" />Publish</>}
              </button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
};
