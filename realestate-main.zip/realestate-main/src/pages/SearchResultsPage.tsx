import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { AdvancedSearchBar } from '../components/AdvancedSearchBar';
import { supabase } from '../lib/supabase';
import {
  SlidersHorizontal,
  Grid,
  List,
  MapPin,
  Star,
  Heart,
  TrendingUp,
  Filter,
  X,
  ChevronDown,
} from 'lucide-react';

type Listing = {
  id: string;
  title: string;
  price: number;
  images: string[];
  location_city: string;
  location_state: string;
  created_at: string;
  condition: string;
  category: {
    name: string;
  };
  profile: {
    full_name: string;
  };
};

export const SearchResultsPage = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);

  const [filters, setFilters] = useState({
    query: '',
    category: '',
    minPrice: '',
    maxPrice: '',
    condition: '',
    location: '',
    sortBy: 'newest',
  });

  const [categories, setCategories] = useState<{ id: string; name: string }[]>([]);
  const [states] = useState([
    'Lagos',
    'Abuja',
    'Kano',
    'Rivers',
    'Oyo',
    'Kaduna',
    'Anambra',
    'Enugu',
    'Delta',
    'Edo',
  ]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const searchQuery = params.get('q') || '';
    setFilters((prev) => ({ ...prev, query: searchQuery }));
    loadCategories();
  }, []);

  useEffect(() => {
    searchListings();
  }, [filters]);

  const loadCategories = async () => {
    const { data } = await supabase
      .from('categories')
      .select('id, name')
      .eq('is_active', true)
      .order('name');

    if (data) {
      setCategories(data);
    }
  };

  const searchListings = async () => {
    setLoading(true);

    let query = supabase
      .from('listings')
      .select(`
        id,
        title,
        price,
        images,
        location_city,
        location_state,
        created_at,
        condition,
        category:categories(name),
        profile:profiles(full_name)
      `)
      .eq('status', 'active');

    if (filters.query) {
      query = query.or(`title.ilike.%${filters.query}%,description.ilike.%${filters.query}%`);
    }

    if (filters.category) {
      const { data: cat } = await supabase
        .from('categories')
        .select('id')
        .eq('name', filters.category)
        .single();
      if (cat) {
        query = query.eq('category_id', cat.id);
      }
    }

    if (filters.minPrice) {
      query = query.gte('price', parseInt(filters.minPrice));
    }

    if (filters.maxPrice) {
      query = query.lte('price', parseInt(filters.maxPrice));
    }

    if (filters.condition) {
      query = query.eq('condition', filters.condition);
    }

    if (filters.location) {
      query = query.eq('location_state', filters.location);
    }

    switch (filters.sortBy) {
      case 'newest':
        query = query.order('created_at', { ascending: false });
        break;
      case 'price_low':
        query = query.order('price', { ascending: true });
        break;
      case 'price_high':
        query = query.order('price', { ascending: false });
        break;
      case 'popular':
        query = query.order('views_count', { ascending: false });
        break;
    }

    const { data, error } = await query.limit(50);

    if (data) {
      setListings(data as any);
    }
    setLoading(false);
  };

  const clearFilters = () => {
    setFilters({
      query: filters.query,
      category: '',
      minPrice: '',
      maxPrice: '',
      condition: '',
      location: '',
      sortBy: 'newest',
    });
  };

  const activeFiltersCount = [
    filters.category,
    filters.minPrice,
    filters.maxPrice,
    filters.condition,
    filters.location,
  ].filter(Boolean).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <AdvancedSearchBar
            onSearch={(query) => setFilters((prev) => ({ ...prev, query }))}
            showFilters={true}
          />
        </div>

        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {filters.query ? `Search results for "${filters.query}"` : 'Browse All Listings'}
            </h1>
            <p className="text-gray-600 mt-1">
              {loading ? 'Searching...' : `${listings.length} results found`}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 py-2 bg-white border-2 border-amber-200 rounded-xl hover:border-amber-400 transition-colors"
            >
              <SlidersHorizontal className="w-5 h-5 text-amber-600" />
              <span className="font-semibold text-gray-700">Filters</span>
              {activeFiltersCount > 0 && (
                <span className="px-2 py-0.5 bg-amber-600 text-white text-xs rounded-full font-bold">
                  {activeFiltersCount}
                </span>
              )}
            </button>

            <div className="flex items-center gap-1 bg-white border-2 border-amber-200 rounded-xl p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === 'grid' ? 'bg-amber-500 text-white' : 'text-gray-600 hover:bg-amber-50'
                }`}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === 'list' ? 'bg-amber-500 text-white' : 'text-gray-600 hover:bg-amber-50'
                }`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {showFilters && (
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl shadow-xl p-6 sticky top-24">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                    <Filter className="w-5 h-5 text-amber-600" />
                    Filters
                  </h2>
                  {activeFiltersCount > 0 && (
                    <button
                      onClick={clearFilters}
                      className="text-sm text-amber-600 hover:text-amber-700 font-semibold"
                    >
                      Clear All
                    </button>
                  )}
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Category</label>
                    <select
                      value={filters.category}
                      onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                      className="w-full px-4 py-2 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                    >
                      <option value="">All Categories</option>
                      {categories.map((cat) => (
                        <option key={cat.id} value={cat.name}>
                          {cat.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Price Range</label>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="number"
                        placeholder="Min"
                        value={filters.minPrice}
                        onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })}
                        className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:outline-none focus:border-amber-400"
                      />
                      <input
                        type="number"
                        placeholder="Max"
                        value={filters.maxPrice}
                        onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
                        className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Condition</label>
                    <select
                      value={filters.condition}
                      onChange={(e) => setFilters({ ...filters, condition: e.target.value })}
                      className="w-full px-4 py-2 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                    >
                      <option value="">Any Condition</option>
                      <option value="new">New</option>
                      <option value="used">Used</option>
                      <option value="refurbished">Refurbished</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Location</label>
                    <select
                      value={filters.location}
                      onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                      className="w-full px-4 py-2 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                    >
                      <option value="">All Locations</option>
                      {states.map((state) => (
                        <option key={state} value={state}>
                          {state}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Sort By</label>
                    <select
                      value={filters.sortBy}
                      onChange={(e) => setFilters({ ...filters, sortBy: e.target.value })}
                      className="w-full px-4 py-2 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                    >
                      <option value="newest">Newest First</option>
                      <option value="price_low">Price: Low to High</option>
                      <option value="price_high">Price: High to Low</option>
                      <option value="popular">Most Popular</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className={showFilters ? 'lg:col-span-3' : 'lg:col-span-4'}>
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <div className="text-center">
                  <div className="animate-spin w-16 h-16 border-4 border-amber-600 border-t-transparent rounded-full mx-auto mb-4"></div>
                  <p className="text-gray-600">Loading results...</p>
                </div>
              </div>
            ) : listings.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
                <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <TrendingUp className="w-12 h-12 text-gray-400" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-3">No results found</h2>
                <p className="text-gray-600 mb-6">
                  Try adjusting your filters or search with different keywords
                </p>
                <button
                  onClick={clearFilters}
                  className="px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-bold hover:from-amber-600 hover:to-amber-700 transition-all"
                >
                  Clear Filters
                </button>
              </div>
            ) : (
              <div
                className={
                  viewMode === 'grid'
                    ? 'grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6'
                    : 'space-y-4'
                }
              >
                {listings.map((listing) => (
                  <a
                    key={listing.id}
                    href={`/listing/${listing.id}`}
                    className={`bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all overflow-hidden group ${
                      viewMode === 'list' ? 'flex items-start gap-4 p-4' : ''
                    }`}
                  >
                    <div
                      className={`bg-gray-100 overflow-hidden relative ${
                        viewMode === 'list' ? 'w-48 h-32 rounded-xl flex-shrink-0' : 'h-56'
                      }`}
                    >
                      {listing.images && listing.images.length > 0 ? (
                        <img
                          src={listing.images[0]}
                          alt={listing.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <TrendingUp className="w-12 h-12 text-gray-400" />
                        </div>
                      )}
                      <button className="absolute top-3 right-3 p-2 bg-white/90 backdrop-blur-sm rounded-full hover:bg-white transition-colors">
                        <Heart className="w-5 h-5 text-gray-700" />
                      </button>
                      <div className="absolute bottom-3 left-3">
                        <span className="px-3 py-1 bg-amber-500 text-white text-xs font-bold rounded-full">
                          {listing.condition}
                        </span>
                      </div>
                    </div>

                    <div className={viewMode === 'list' ? 'flex-1' : 'p-4'}>
                      <h3 className="font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-amber-600 transition-colors">
                        {listing.title}
                      </h3>

                      <div className="flex items-center gap-2 mb-2 text-sm text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span>
                          {listing.location_city}, {listing.location_state}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-2xl font-bold text-amber-600">
                            ₦{listing.price.toLocaleString()}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">{listing.category.name}</p>
                        </div>
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};
