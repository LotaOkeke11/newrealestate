import { useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Smartphone, X, CheckCircle2, AlertCircle, Image as ImageIcon, Check, Sparkles, Zap } from 'lucide-react';

export const UploadElectronicsPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    category: '',
    itemName: '',
    brand: '',
    model: '',
    condition: '',
    color: '',
    storage: '',
    ram: '',
    screenSize: '',
    processor: '',
    price: '',
    description: '',
    locationState: '',
    locationCity: '',
    warrantyStatus: '',
    warrantyMonths: '',
    priceNegotiable: false,
    contactPhone: '',
    contactWhatsapp: ''
  });

  const electronicsCategories = [
    'Smartphones',
    'Tablets',
    'Laptops',
    'Desktop Computers',
    'Smartwatches',
    'Headphones & Earbuds',
    'Speakers & Audio',
    'Televisions',
    'Gaming Consoles',
    'Gaming Accessories',
    'Printers & Scanners',
    'Computer Accessories',
    'Phone Accessories',
    'Chargers & Cables',
    'Power Banks',
    'Smart Home Devices',
    'Air Conditioners',
    'Refrigerators',
    'Washing Machines',
    'Microwaves',
    'Kitchen Appliances',
    'Other Electronics'
  ];

  const brands = [
    'Apple',
    'Samsung',
    'Huawei',
    'Xiaomi',
    'Oppo',
    'Vivo',
    'Tecno',
    'Infinix',
    'Itel',
    'Nokia',
    'OnePlus',
    'Google',
    'Sony',
    'LG',
    'HP',
    'Dell',
    'Lenovo',
    'Asus',
    'Acer',
    'Microsoft',
    'Bose',
    'JBL',
    'Beats',
    'Anker',
    'Other'
  ];

  const conditions = ['Brand New', 'Like New', 'Excellent', 'Good', 'Fair', 'Used'];
  const colors = ['Black', 'White', 'Silver', 'Gold', 'Blue', 'Red', 'Green', 'Purple', 'Pink', 'Gray', 'Rose Gold', 'Midnight', 'Starlight', 'Other'];
  const storageOptions = ['16GB', '32GB', '64GB', '128GB', '256GB', '512GB', '1TB', '2TB', 'Other'];
  const ramOptions = ['2GB', '3GB', '4GB', '6GB', '8GB', '12GB', '16GB', '32GB', '64GB', 'Other'];
  const screenSizes = ['5-6 inches', '6-6.5 inches', '6.5-7 inches', '10-11 inches', '12-13 inches', '13-14 inches', '15-16 inches', '17+ inches', 'Other'];
  const warrantyOptions = ['No Warranty', 'Manufacturer Warranty', 'Seller Warranty', 'Extended Warranty'];

  const nigeriaStates = [
    'Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo', 'Kaduna', 'Anambra', 'Enugu',
    'Delta', 'Edo', 'Ogun', 'Ondo', 'Osun', 'Kwara', 'Plateau', 'Benue'
  ];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + imageFiles.length > 10) {
      setError('Maximum 10 images allowed');
      return;
    }
    setImageFiles((prev) => [...prev, ...files]);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreviews((prev) => [...prev, reader.result as string]);
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImageFiles((prev) => prev.filter((_, i) => i !== index));
    setImagePreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (!user) throw new Error('Please sign in');
      if (imageFiles.length < 2) throw new Error('Upload at least 2 images');

      const imageUrls: string[] = [];
      for (let i = 0; i < imageFiles.length; i++) {
        const file = imageFiles[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/electronics-${Date.now()}-${i}.${fileExt}`;
        const { error: uploadError } = await supabase.storage.from('listing-images').upload(fileName, file);
        if (!uploadError) {
          const { data: urlData } = supabase.storage.from('listing-images').getPublicUrl(fileName);
          imageUrls.push(urlData.publicUrl);
        }
      }

      const { data: category } = await supabase.from('categories').select('id, slug').eq('slug', 'electronics').maybeSingle();

      const listingData = {
        user_id: user.id,
        category_id: category?.id,
        title: `${formData.brand} ${formData.itemName} ${formData.model}`.trim(),
        description: formData.description,
        price: parseFloat(formData.price),
        currency: 'NGN',
        condition: formData.condition,
        images: imageUrls,
        item_type: formData.category,
        brand: formData.brand,
        specifications: {
          model: formData.model,
          color: formData.color,
          storage: formData.storage,
          ram: formData.ram,
          screen_size: formData.screenSize,
          processor: formData.processor
        },
        warranty_status: formData.warrantyStatus,
        warranty_months: formData.warrantyMonths ? parseInt(formData.warrantyMonths) : null,
        price_negotiable: formData.priceNegotiable,
        location_state: formData.locationState,
        location_city: formData.locationCity,
        contact_phone: formData.contactPhone,
        contact_whatsapp: formData.contactWhatsapp,
        status: 'active'
      };

      const { data: listing, error: listingError } = await supabase.from('listings').insert(listingData).select().single();
      if (listingError) throw listingError;
      setSuccess(true);
      setTimeout(() => {
        window.location.href = category?.slug ? `/category/${category.slug}` : '/';
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    window.location.href = '/post-ad';
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />
      <main className="flex-1">
        <div className="bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-600 text-white py-12 px-4 shadow-2xl">
          <div className="max-w-5xl mx-auto">
            <a href="/post-ad" className="text-white/90 hover:text-white text-sm font-bold mb-4 inline-block">← Back</a>
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <Sparkles className="w-10 h-10 text-yellow-300 animate-pulse" />
                  <h1 className="text-5xl font-black">Sell Electronics</h1>
                </div>
                <p className="text-white/95 text-xl font-semibold">List your gadgets and reach millions of buyers</p>
              </div>
              <div className="hidden md:flex w-24 h-24 bg-white/20 rounded-3xl items-center justify-center backdrop-blur-sm">
                <Smartphone className="w-12 h-12 text-white" />
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-5xl mx-auto px-4 py-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {success && (
              <div className="p-6 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-300 rounded-2xl flex items-start gap-4 shadow-lg">
                <CheckCircle2 className="w-7 h-7 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-black text-green-900 text-xl">Success!</p>
                  <p className="text-green-800 text-sm font-semibold">Your electronics listing is now live</p>
                </div>
              </div>
            )}
            {error && (
              <div className="p-6 bg-gradient-to-r from-red-50 to-pink-50 border-2 border-red-300 rounded-2xl flex items-start gap-4 shadow-lg">
                <AlertCircle className="w-7 h-7 text-red-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-red-800 font-semibold">{error}</span>
              </div>
            )}

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-blue-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-blue-400 to-cyan-400">Product Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Category *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                  >
                    <option value="">Select category</option>
                    {electronicsCategories.map((cat) => <option key={cat} value={cat}>{cat}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Item Name *</label>
                  <input
                    type="text"
                    value={formData.itemName}
                    onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                    placeholder="e.g., iPhone 14 Pro"
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Brand *</label>
                  <select
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                  >
                    <option value="">Select brand</option>
                    {brands.map((brand) => <option key={brand} value={brand}>{brand}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Model</label>
                  <input
                    type="text"
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    placeholder="e.g., Pro Max 256GB"
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Condition *</label>
                  <select
                    value={formData.condition}
                    onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                  >
                    <option value="">Select condition</option>
                    {conditions.map((cond) => <option key={cond} value={cond}>{cond}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Color</label>
                  <select
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                  >
                    <option value="">Select color</option>
                    {colors.map((color) => <option key={color} value={color}>{color}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-cyan-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-cyan-400 to-teal-400">Specifications</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Storage</label>
                  <select
                    value={formData.storage}
                    onChange={(e) => setFormData({ ...formData, storage: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                  >
                    <option value="">Select storage</option>
                    {storageOptions.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">RAM</label>
                  <select
                    value={formData.ram}
                    onChange={(e) => setFormData({ ...formData, ram: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                  >
                    <option value="">Select RAM</option>
                    {ramOptions.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Screen Size</label>
                  <select
                    value={formData.screenSize}
                    onChange={(e) => setFormData({ ...formData, screenSize: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                  >
                    <option value="">Select size</option>
                    {screenSizes.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Processor</label>
                  <input
                    type="text"
                    value={formData.processor}
                    onChange={(e) => setFormData({ ...formData, processor: e.target.value })}
                    placeholder="e.g., A16 Bionic, Snapdragon 8"
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-teal-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-teal-400 to-blue-400">Warranty</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Warranty Status</label>
                  <select
                    value={formData.warrantyStatus}
                    onChange={(e) => setFormData({ ...formData, warrantyStatus: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 font-semibold"
                  >
                    <option value="">Select warranty</option>
                    {warrantyOptions.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Warranty Months</label>
                  <input
                    type="number"
                    value={formData.warrantyMonths}
                    onChange={(e) => setFormData({ ...formData, warrantyMonths: e.target.value })}
                    placeholder="0"
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 font-semibold"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-blue-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-blue-400 to-cyan-400">Photos</h2>
              <div className="border-4 border-dashed border-cyan-300 rounded-2xl p-10 text-center hover:border-cyan-500 bg-gradient-to-br from-cyan-50 to-teal-50 transition-all">
                <ImageIcon className="w-20 h-20 text-cyan-400 mx-auto mb-5" />
                <p className="text-gray-900 mb-2 font-black text-xl">Upload product photos</p>
                <p className="text-sm text-gray-600 mb-5 font-semibold">Up to 10 images (Min 2 required)</p>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                  id="image-upload"
                />
                <label
                  htmlFor="image-upload"
                  className="px-10 py-4 bg-gradient-to-r from-blue-500 to-cyan-600 text-white rounded-xl cursor-pointer hover:from-blue-600 hover:to-cyan-700 inline-block font-black text-lg transition-all shadow-lg"
                >
                  Choose Photos
                </label>
              </div>
              {imagePreviews.length > 0 && (
                <div className="mt-8">
                  <p className="font-black text-gray-900 mb-4 text-xl">{imagePreviews.length} photo(s) selected</p>
                  <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative aspect-square rounded-2xl overflow-hidden border-4 border-cyan-200 group shadow-lg">
                        <img src={preview} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full hover:bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-cyan-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-cyan-400 to-teal-400">Description</h2>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe your product: features, condition, accessories included, reason for selling..."
                rows={6}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
              />
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-blue-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-blue-400 to-cyan-400">Location</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">State *</label>
                  <select
                    value={formData.locationState}
                    onChange={(e) => setFormData({ ...formData, locationState: e.target.value })}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-semibold"
                  >
                    <option value="">Select state</option>
                    {nigeriaStates.map((state) => <option key={state} value={state}>{state}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">City/Area *</label>
                  <input
                    type="text"
                    value={formData.locationCity}
                    onChange={(e) => setFormData({ ...formData, locationCity: e.target.value })}
                    placeholder="e.g., Lekki, Ikeja"
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-semibold"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-xl p-8 border-2 border-cyan-100">
              <h2 className="text-2xl font-black text-gray-900 mb-6 pb-4 border-b-4 border-gradient-to-r from-cyan-400 to-teal-400">Price & Contact</h2>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-black text-gray-800 mb-2">Price (₦) *</label>
                  <div className="relative">
                    <div className="absolute left-5 top-1/2 -translate-y-1/2 text-3xl font-black text-cyan-500">₦</div>
                    <input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      placeholder="0"
                      required
                      min="0"
                      className="w-full pl-16 pr-4 py-5 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 text-2xl font-black"
                    />
                  </div>
                </div>
                <label className="flex items-center gap-4 p-5 border-4 border-cyan-200 rounded-xl cursor-pointer hover:border-cyan-400 transition-all bg-cyan-50">
                  <input
                    type="checkbox"
                    checked={formData.priceNegotiable}
                    onChange={(e) => setFormData({ ...formData, priceNegotiable: e.target.checked })}
                    className="w-6 h-6 text-cyan-600 rounded focus:ring-cyan-500"
                  />
                  <span className="font-black text-gray-900 text-lg">Price is negotiable</span>
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-black text-gray-800 mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      value={formData.contactPhone}
                      onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                      placeholder="+234 800 000 0000"
                      required
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-black text-gray-800 mb-2">WhatsApp (Optional)</label>
                    <input
                      type="tel"
                      value={formData.contactWhatsapp}
                      onChange={(e) => setFormData({ ...formData, contactWhatsapp: e.target.value })}
                      placeholder="+234 800 000 0000"
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-semibold"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-8 border-t-4 border-gray-200">
              <a
                href="/post-ad"
                className="px-10 py-4 border-4 border-gray-300 text-gray-700 rounded-xl font-black text-lg hover:bg-gray-50 transition-all"
              >
                Cancel
              </a>
              <button
                type="submit"
                disabled={loading || imageFiles.length < 2}
                className="px-16 py-4 bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-600 text-white rounded-xl font-black text-lg hover:from-blue-600 hover:via-cyan-600 hover:to-teal-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl flex items-center gap-3 transition-all"
              >
                {loading ? (
                  <>
                    <div className="animate-spin w-6 h-6 border-3 border-white border-t-transparent rounded-full"></div>
                    Publishing...
                  </>
                ) : (
                  <>
                    <Zap className="w-6 h-6" />
                    Publish Listing
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
};
