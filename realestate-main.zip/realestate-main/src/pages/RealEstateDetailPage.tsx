import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  MapPin, Bed, Bath, Maximize, Heart, Share2, Phone, MessageCircle,
  Wifi, Car, Droplet, Wind, Tv, Coffee, Building, Shield, Calendar,
  ChevronLeft, ChevronRight, Star, User, Clock, CheckCircle2, X, Play,
  Home, Video as VideoIcon, DollarSign, TrendingUp, Award
} from 'lucide-react';

type RealEstateListing = {
  id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  images: string[];
  video_url: string;
  property_type: string;
  bedrooms: number;
  bathrooms: number;
  square_feet: number;
  is_furnished: boolean;
  amenities: string[];
  location_city: string;
  location_state: string;
  location_area: string;
  seller_type: string;
  payment_frequency: string;
  nightly_rate: number;
  weekly_rate: number;
  monthly_rate: number;
  house_rules: string;
  contact_phone: string;
  contact_whatsapp: string;
  created_at: string;
  views_count: number;
  is_rental: boolean;
  rental_duration: string;
  profile: {
    full_name: string;
    avatar_url: string;
  };
  verification?: {
    status: string;
  };
};

const amenityIcons: { [key: string]: any } = {
  wifi: Wifi,
  parking: Car,
  pool: Droplet,
  ac: Wind,
  tv: Tv,
  kitchen: Coffee,
  generator: Building,
  security: Shield,
};

export const RealEstateDetailPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [listing, setListing] = useState<RealEstateListing | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showAllImages, setShowAllImages] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState(1);

  const listingId = window.location.pathname.split('/property/')[1];

  useEffect(() => {
    loadListing();
    incrementViewCount();
  }, [listingId]);

  const loadListing = async () => {
    const { data, error } = await supabase
      .from('listings')
      .select(`
        *,
        profile:profiles!user_id(full_name, avatar_url),
        verification:seller_verifications(status)
      `)
      .eq('id', listingId)
      .single();

    if (data) {
      setListing(data as any);
    }
    setLoading(false);
  };

  const incrementViewCount = async () => {
    await supabase.rpc('increment_listing_views', { listing_id: listingId });
  };

  const calculateNights = () => {
    if (!checkIn || !checkOut) return 0;
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const nights = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    return nights > 0 ? nights : 0;
  };

  const getTotalPrice = () => {
    if (!listing) return 0;
    const nights = calculateNights();
    if (nights === 0) return 0;

    if (nights >= 30 && listing.monthly_rate) {
      return listing.monthly_rate * Math.ceil(nights / 30);
    } else if (nights >= 7 && listing.weekly_rate) {
      return listing.weekly_rate * Math.ceil(nights / 7);
    } else {
      return (listing.nightly_rate || listing.price) * nights;
    }
  };

  const nextImage = () => {
    if (listing && listing.images.length > 0) {
      setCurrentImageIndex((prev) =>
        prev === listing.images.length - 1 ? 0 : prev + 1
      );
    }
  };

  const prevImage = () => {
    if (listing && listing.images.length > 0) {
      setCurrentImageIndex((prev) =>
        prev === 0 ? listing.images.length - 1 : prev - 1
      );
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading property...</p>
        </div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Home className="w-20 h-20 text-gray-300 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Property Not Found</h2>
            <a href="/real-estate" className="text-blue-600 hover:text-blue-700">
              Browse all properties
            </a>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const isShortlet = listing.rental_duration === 'daily';

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="mb-4">
            <h1 className="text-3xl font-bold text-gray-900 mb-3">{listing.title}</h1>
            <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
              <button
                onClick={() => {
                  const reviewsSection = document.querySelector('[data-reviews-section]');
                  reviewsSection?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="flex items-center gap-1 px-3 py-1.5 bg-amber-50 border-2 border-amber-200 rounded-lg hover:bg-amber-100 transition-colors"
              >
                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span className="font-semibold text-gray-900">4.8</span>
                <span className="text-gray-600">(24 reviews)</span>
              </button>
              <span>•</span>
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {listing.location_area && `${listing.location_area}, `}
                {listing.location_city}, {listing.location_state}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 mb-6 rounded-2xl overflow-hidden">
            <div className="col-span-4 md:col-span-2 md:row-span-2 relative cursor-pointer group"
              onClick={() => setShowAllImages(true)}>
              <img
                src={listing.images[0]}
                alt={listing.title}
                className="w-full h-full object-cover aspect-[4/3] md:aspect-auto"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
            </div>
            {listing.images.slice(1, 5).map((image, index) => (
              <div key={index} className="relative cursor-pointer group hidden md:block"
                onClick={() => setShowAllImages(true)}>
                <img
                  src={image}
                  alt={`${listing.title} ${index + 2}`}
                  className="w-full h-full object-cover aspect-square"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
                {index === 3 && listing.images.length > 5 && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                    <span className="text-white font-bold text-lg">
                      +{listing.images.length - 5} photos
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div className="border-b pb-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">
                      {listing.property_type} hosted by {listing.profile.full_name}
                    </h2>
                    <div className="flex items-center gap-4 text-gray-600">
                      {listing.bedrooms > 0 && (
                        <span className="flex items-center gap-1">
                          <Bed className="w-4 h-4" />
                          {listing.bedrooms} bed{listing.bedrooms > 1 ? 's' : ''}
                        </span>
                      )}
                      {listing.bathrooms > 0 && (
                        <span className="flex items-center gap-1">
                          <Bath className="w-4 h-4" />
                          {listing.bathrooms} bath{listing.bathrooms > 1 ? 's' : ''}
                        </span>
                      )}
                      {listing.square_feet > 0 && (
                        <span className="flex items-center gap-1">
                          <Maximize className="w-4 h-4" />
                          {listing.square_feet.toLocaleString()} sq ft
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full overflow-hidden">
                    {listing.profile.avatar_url ? (
                      <img
                        src={listing.profile.avatar_url}
                        alt={listing.profile.full_name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-white text-xl font-bold">
                        {listing.profile.full_name.charAt(0)}
                      </div>
                    )}
                  </div>
                </div>

                {listing.verification?.status === 'approved' && (
                  <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-xl">
                    <Award className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-semibold text-green-800">
                      Verified {listing.seller_type === 'agent' ? 'Agent' : 'Owner'}
                    </span>
                  </div>
                )}
              </div>

              <div className="border-b pb-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">What this place offers</h3>
                <div className="grid grid-cols-2 gap-4">
                  {listing.amenities.map((amenityId) => {
                    const Icon = amenityIcons[amenityId] || CheckCircle2;
                    const label = amenityId.charAt(0).toUpperCase() + amenityId.slice(1);
                    return (
                      <div key={amenityId} className="flex items-center gap-3">
                        <Icon className="w-6 h-6 text-gray-700" />
                        <span className="text-gray-900">{label}</span>
                      </div>
                    );
                  })}
                  {listing.is_furnished && (
                    <div className="flex items-center gap-3">
                      <Home className="w-6 h-6 text-gray-700" />
                      <span className="text-gray-900">Fully Furnished</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-b pb-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">About this property</h3>
                <p className="text-gray-700 whitespace-pre-line leading-relaxed">
                  {listing.description}
                </p>
              </div>

              {listing.video_url && (
                <div className="border-b pb-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Video Tour</h3>
                  <button
                    onClick={() => setShowVideoModal(true)}
                    className="relative w-full aspect-video rounded-2xl overflow-hidden group"
                  >
                    <img
                      src={listing.images[0]}
                      alt="Video thumbnail"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition-colors flex items-center justify-center">
                      <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
                        <Play className="w-8 h-8 text-blue-600 ml-1" />
                      </div>
                    </div>
                  </button>
                </div>
              )}

              {isShortlet && listing.house_rules && (
                <div className="border-b pb-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">House Rules</h3>
                  <p className="text-gray-700 whitespace-pre-line">{listing.house_rules}</p>
                </div>
              )}

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Location</h3>
                <div className="h-64 bg-gray-200 rounded-2xl flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600">Map integration placeholder</p>
                    <p className="text-sm text-gray-500">
                      {listing.location_area && `${listing.location_area}, `}
                      {listing.location_city}, {listing.location_state}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <div className="border-2 border-gray-200 rounded-2xl p-6 shadow-xl">
                  <div className="mb-6">
                    <div className="flex items-baseline gap-2 mb-1">
                      <span className="text-3xl font-bold text-gray-900">
                        ₦{(isShortlet ? listing.nightly_rate : listing.price).toLocaleString()}
                      </span>
                      {isShortlet && <span className="text-gray-600">/ night</span>}
                      {listing.is_rental && !isShortlet && (
                        <span className="text-gray-600">/ {listing.payment_frequency}</span>
                      )}
                    </div>
                    {isShortlet && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        {listing.weekly_rate && (
                          <span>₦{listing.weekly_rate.toLocaleString()}/week</span>
                        )}
                        {listing.monthly_rate && (
                          <span>• ₦{listing.monthly_rate.toLocaleString()}/month</span>
                        )}
                      </div>
                    )}
                  </div>

                  {isShortlet && (
                    <div className="space-y-4 mb-6">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-gray-700 mb-1">
                            Check-in
                          </label>
                          <input
                            type="date"
                            value={checkIn}
                            onChange={(e) => setCheckIn(e.target.value)}
                            className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-gray-700 mb-1">
                            Check-out
                          </label>
                          <input
                            type="date"
                            value={checkOut}
                            onChange={(e) => setCheckOut(e.target.value)}
                            className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">
                          Guests
                        </label>
                        <select
                          value={guests}
                          onChange={(e) => setGuests(parseInt(e.target.value))}
                          className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                        >
                          {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                            <option key={num} value={num}>
                              {num} guest{num > 1 ? 's' : ''}
                            </option>
                          ))}
                        </select>
                      </div>

                      {calculateNights() > 0 && (
                        <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
                          <div className="flex justify-between text-sm mb-2">
                            <span className="text-gray-700">
                              ₦{(listing.nightly_rate || listing.price).toLocaleString()} × {calculateNights()} night{calculateNights() > 1 ? 's' : ''}
                            </span>
                            <span className="font-semibold text-gray-900">
                              ₦{getTotalPrice().toLocaleString()}
                            </span>
                          </div>
                          <div className="flex justify-between text-base font-bold pt-2 border-t border-blue-200">
                            <span>Total</span>
                            <span>₦{getTotalPrice().toLocaleString()}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {listing.contact_phone && (
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <a
                        href={`tel:${listing.contact_phone}`}
                        className="py-4 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
                      >
                        <Phone className="w-5 h-5" />
                        Call
                      </a>
                      <a
                        href={`https://wa.me/${(listing.contact_whatsapp || listing.contact_phone).replace(/\D/g, '')}?text=${encodeURIComponent(`Hi, I'm interested in: ${listing.title}`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-4 bg-[#25D366] hover:bg-[#20BD5A] text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
                      >
                        <MessageCircle className="w-5 h-5" />
                        WhatsApp
                      </a>
                    </div>
                  )}

                  <button
                    onClick={() => setShowContactModal(true)}
                    className="w-full py-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl font-bold hover:from-blue-700 hover:to-cyan-700 transition-all shadow-lg mb-3"
                  >
                    {isShortlet ? 'Reserve' : 'Contact ' + listing.seller_type}
                  </button>

                  <div className="flex gap-2">
                    <button className="flex-1 py-3 border-2 border-gray-300 rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center gap-2">
                      <Heart className="w-5 h-5" />
                      <span className="font-semibold">Save</span>
                    </button>
                    <button className="flex-1 py-3 border-2 border-gray-300 rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center gap-2">
                      <Share2 className="w-5 h-5" />
                      <span className="font-semibold">Share</span>
                    </button>
                  </div>

                  <p className="text-xs text-gray-500 text-center mt-4">
                    You won't be charged yet
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {showAllImages && (
        <div className="fixed inset-0 bg-black z-50 flex flex-col">
          <div className="flex items-center justify-between p-4 bg-black/80">
            <button
              onClick={() => setShowAllImages(false)}
              className="p-2 text-white hover:bg-white/10 rounded-full"
            >
              <X className="w-6 h-6" />
            </button>
            <span className="text-white font-semibold">
              {currentImageIndex + 1} / {listing.images.length}
            </span>
            <div className="w-10" />
          </div>

          <div className="flex-1 relative flex items-center justify-center">
            <img
              src={listing.images[currentImageIndex]}
              alt={`${listing.title} ${currentImageIndex + 1}`}
              className="max-h-full max-w-full object-contain"
            />

            <button
              onClick={prevImage}
              className="absolute left-4 p-3 bg-white/90 rounded-full hover:bg-white transition-colors"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={nextImage}
              className="absolute right-4 p-3 bg-white/90 rounded-full hover:bg-white transition-colors"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          <div className="p-4 bg-black/80 overflow-x-auto">
            <div className="flex gap-2">
              {listing.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 ${
                    index === currentImageIndex ? 'border-white' : 'border-transparent'
                  }`}
                >
                  <img src={image} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {showVideoModal && listing.video_url && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="relative w-full max-w-5xl">
            <button
              onClick={() => setShowVideoModal(false)}
              className="absolute -top-12 right-0 p-2 text-white hover:bg-white/10 rounded-full"
            >
              <X className="w-6 h-6" />
            </button>
            <video src={listing.video_url} controls className="w-full rounded-2xl" autoPlay />
          </div>
        </div>
      )}

      {showContactModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Contact {listing.seller_type}</h3>

            <div className="space-y-3">
              {listing.contact_phone && (
                <a
                  href={`tel:${listing.contact_phone}`}
                  className="flex items-center gap-3 p-4 bg-blue-50 border-2 border-blue-200 rounded-xl hover:bg-blue-100 transition-all"
                >
                  <Phone className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Call</p>
                    <p className="font-semibold text-blue-700">{listing.contact_phone}</p>
                  </div>
                </a>
              )}

              {listing.contact_whatsapp && (
                <a
                  href={`https://wa.me/${listing.contact_whatsapp.replace(/\D/g, '')}?text=Hi, I'm interested in: ${listing.title}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-4 bg-green-50 border-2 border-green-200 rounded-xl hover:bg-green-100 transition-all"
                >
                  <MessageCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm text-gray-600">WhatsApp</p>
                    <p className="font-semibold text-green-700">Send message</p>
                  </div>
                </a>
              )}

              <button
                onClick={() => setShowContactModal(false)}
                className="w-full py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
};
