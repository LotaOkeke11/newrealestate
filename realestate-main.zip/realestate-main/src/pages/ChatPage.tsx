import { useState, useEffect, useRef } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Send, Phone, Video, MoreVertical, ArrowLeft, Search, Paperclip, Smile, Check, CheckCheck, MessageCircle, HeadphonesIcon } from 'lucide-react';

type Message = {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  is_read: boolean;
  created_at: string;
};

type Conversation = {
  id: string;
  listing_id?: string;
  buyer_id: string;
  seller_id: string;
  last_message?: string;
  last_message_at?: string;
  buyer_unread_count: number;
  seller_unread_count: number;
  other_user?: {
    id: string;
    email: string;
    full_name?: string;
  };
  listing?: {
    id: string;
    title: string;
    images: string[];
    price: number;
  };
};

export const ChatPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      loadConversations();

      // Set up real-time subscription for conversation updates
      const channel = supabase
        .channel('conversations-updates')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'conversations',
            filter: `buyer_id=eq.${user.id}`,
          },
          () => {
            loadConversations();
          }
        )
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'conversations',
            filter: `seller_id=eq.${user.id}`,
          },
          () => {
            loadConversations();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [user]);

  useEffect(() => {
    if (selectedConversation) {
      loadMessages(selectedConversation.id);
      markAsRead(selectedConversation.id);

      // Set up real-time subscription for new messages
      const channel = supabase
        .channel(`conversation:${selectedConversation.id}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
            filter: `conversation_id=eq.${selectedConversation.id}`,
          },
          (payload) => {
            const newMessage = payload.new as Message;
            // Only add if not from current user (avoid duplicates)
            if (newMessage.sender_id !== user?.id) {
              setMessages((current) => [...current, newMessage]);
              markAsRead(selectedConversation.id);
            }
          }
        )
        .subscribe();

      // Cleanup subscription on unmount or conversation change
      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [selectedConversation, user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadConversations = async () => {
    if (!user) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('conversations')
      .select(`
        id,
        listing_id,
        buyer_id,
        seller_id,
        last_message,
        last_message_at,
        buyer_unread_count,
        seller_unread_count,
        listing:listings(id, title, images, price)
      `)
      .or(`buyer_id.eq.${user.id},seller_id.eq.${user.id}`)
      .order('last_message_at', { ascending: false });

    if (data) {
      const conversationsWithUsers = await Promise.all(
        data.map(async (conv: any) => {
          const otherUserId = conv.buyer_id === user.id ? conv.seller_id : conv.buyer_id;
          const { data: userData } = await supabase
            .from('profiles')
            .select('id, email, full_name')
            .eq('id', otherUserId)
            .single();

          return {
            ...conv,
            other_user: userData
          };
        })
      );
      setConversations(conversationsWithUsers);
    }
    setLoading(false);
  };

  const loadMessages = async (conversationId: string) => {
    const { data } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });

    if (data) {
      setMessages(data);
    }
  };

  const markAsRead = async (conversationId: string) => {
    if (!user || !selectedConversation) return;

    await supabase
      .from('messages')
      .update({ is_read: true })
      .eq('conversation_id', conversationId)
      .neq('sender_id', user.id);

    const updateField = selectedConversation.buyer_id === user.id ? 'buyer_unread_count' : 'seller_unread_count';
    await supabase
      .from('conversations')
      .update({ [updateField]: 0 })
      .eq('id', conversationId);
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newMessage.trim() || !selectedConversation || !user || sending) return;

    const messageContent = newMessage.trim();
    setSending(true);
    setNewMessage('');

    try {
      const { data, error } = await supabase
        .from('messages')
        .insert({
          conversation_id: selectedConversation.id,
          sender_id: user.id,
          recipient_id: selectedConversation.buyer_id === user.id ? selectedConversation.seller_id : selectedConversation.buyer_id,
          content: messageContent,
          topic: 'chat',
          extension: 'text',
          is_read: false
        })
        .select()
        .single();

      if (error) {
        console.error('Error sending message:', error);
        setNewMessage(messageContent);
        setSending(false);
        return;
      }

      if (data) {
        setMessages([...messages, data]);

        await supabase
          .from('conversations')
          .update({
            last_message: messageContent,
            last_message_at: new Date().toISOString(),
            ...(selectedConversation.buyer_id === user.id
              ? { seller_unread_count: selectedConversation.seller_unread_count + 1 }
              : { buyer_unread_count: selectedConversation.buyer_unread_count + 1 }
            )
          })
          .eq('id', selectedConversation.id);

        loadConversations();
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      setNewMessage(messageContent);
    }

    setSending(false);
  };

  const startSupportChat = async () => {
    if (!user) return;

    const { data: existing } = await supabase
      .from('conversations')
      .select('*')
      .eq('buyer_id', user.id)
      .is('listing_id', null)
      .is('seller_id', null)
      .maybeSingle();

    if (existing) {
      setSelectedConversation(existing);
      return;
    }

    const { data, error } = await supabase
      .from('conversations')
      .insert({
        buyer_id: user.id,
        seller_id: user.id,
        last_message: 'Started support chat',
        last_message_at: new Date().toISOString()
      })
      .select()
      .single();

    if (data) {
      await supabase
        .from('messages')
        .insert({
          conversation_id: data.id,
          sender_id: user.id,
          recipient_id: user.id,
          content: 'Hello! How can we help you today?',
          topic: 'support',
          extension: 'text',
          is_read: false
        });

      loadConversations();
      setSelectedConversation(data);
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));

    if (hours < 24) {
      return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    } else if (hours < 48) {
      return 'Yesterday';
    } else if (hours < 168) {
      return date.toLocaleDateString('en-US', { weekday: 'short' });
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  const filteredConversations = conversations.filter(conv => {
    if (!searchQuery) return true;
    const searchLower = searchQuery.toLowerCase();
    return (
      conv.other_user?.full_name?.toLowerCase().includes(searchLower) ||
      conv.other_user?.email?.toLowerCase().includes(searchLower) ||
      conv.listing?.title?.toLowerCase().includes(searchLower) ||
      conv.last_message?.toLowerCase().includes(searchLower)
    );
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex items-center justify-center min-h-[60vh] px-4">
          <div className="text-center bg-white rounded-3xl shadow-2xl p-12 max-w-md">
            <MessageCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Sign In Required</h2>
            <p className="text-gray-600 mb-8 text-lg">Please sign in to access your messages</p>
            <a href="/login" className="block w-full px-8 py-4 bg-gradient-to-r from-green-500 to-teal-600 text-white rounded-xl font-bold hover:from-green-600 hover:to-teal-700 transition-all shadow-lg">
              Sign In
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex h-[calc(100vh-180px)] bg-white rounded-2xl shadow-xl overflow-hidden">
          {/* Conversations List */}
          <div className={`${selectedConversation ? 'hidden lg:flex' : 'flex'} flex-col w-full lg:w-96 border-r border-gray-200 bg-white`}>
            {/* Header */}
            <div className="p-4 bg-gradient-to-r from-green-500 to-teal-600">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold text-white">Chats</h2>
                <button
                  onClick={startSupportChat}
                  className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition-colors"
                  title="Help & Support"
                >
                  <HeadphonesIcon className="w-5 h-5 text-white" />
                </button>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search conversations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-white/90 rounded-lg focus:outline-none focus:ring-2 focus:ring-white"
                />
              </div>
            </div>

            {/* Conversations */}
            <div className="flex-1 overflow-y-auto">
              {loading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="animate-spin w-8 h-8 border-4 border-green-600 border-t-transparent rounded-full"></div>
                </div>
              ) : filteredConversations.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full p-8 text-center">
                  <MessageCircle className="w-16 h-16 text-gray-300 mb-4" />
                  <p className="text-gray-500 mb-2">No conversations yet</p>
                  <p className="text-sm text-gray-400">Start chatting by messaging a seller</p>
                  <button
                    onClick={startSupportChat}
                    className="mt-4 px-6 py-3 bg-gradient-to-r from-green-500 to-teal-600 text-white rounded-xl font-semibold hover:from-green-600 hover:to-teal-700 transition-all shadow-lg"
                  >
                    Start Support Chat
                  </button>
                </div>
              ) : (
                filteredConversations.map((conv) => {
                  const unreadCount = conv.buyer_id === user.id ? conv.buyer_unread_count : conv.seller_unread_count;
                  const isSelected = selectedConversation?.id === conv.id;

                  return (
                    <button
                      key={conv.id}
                      onClick={() => setSelectedConversation(conv)}
                      className={`w-full p-4 flex items-start gap-3 hover:bg-gray-50 transition-colors border-b border-gray-100 ${
                        isSelected ? 'bg-green-50' : ''
                      }`}
                    >
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-400 to-teal-500 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                        {conv.other_user?.full_name?.[0] || conv.other_user?.email?.[0] || '?'}
                      </div>
                      <div className="flex-1 min-w-0 text-left">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-semibold text-gray-900 truncate">
                            {conv.other_user?.full_name || conv.other_user?.email || 'Unknown User'}
                          </h3>
                          <span className="text-xs text-gray-500 flex-shrink-0">
                            {conv.last_message_at && formatTime(conv.last_message_at)}
                          </span>
                        </div>
                        {conv.listing && (
                          <p className="text-xs text-green-600 mb-1 truncate">
                            {conv.listing.title}
                          </p>
                        )}
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-gray-600 truncate">
                            {conv.last_message || 'No messages yet'}
                          </p>
                          {unreadCount > 0 && (
                            <span className="ml-2 px-2 py-0.5 bg-green-500 text-white text-xs font-bold rounded-full flex-shrink-0">
                              {unreadCount}
                            </span>
                          )}
                        </div>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {/* Chat Area */}
          <div className={`${selectedConversation ? 'flex' : 'hidden lg:flex'} flex-1 flex-col bg-gray-50`}>
            {selectedConversation ? (
              <>
                {/* Chat Header */}
                <div className="p-4 bg-white border-b border-gray-200 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setSelectedConversation(null)}
                      className="lg:hidden p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <ArrowLeft className="w-5 h-5 text-gray-600" />
                    </button>
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-400 to-teal-500 flex items-center justify-center text-white font-bold">
                      {selectedConversation.other_user?.full_name?.[0] || selectedConversation.other_user?.email?.[0] || '?'}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">
                        {selectedConversation.other_user?.full_name || selectedConversation.other_user?.email || 'Unknown User'}
                      </h3>
                      {selectedConversation.listing && (
                        <p className="text-xs text-gray-500 truncate max-w-xs">
                          {selectedConversation.listing.title}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const phone = selectedConversation.other_user?.full_name || 'User';
                        alert(`Voice call feature coming soon! Calling ${phone}...`);
                      }}
                      className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <Phone className="w-5 h-5 text-gray-600" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const user = selectedConversation.other_user?.full_name || 'User';
                        alert(`Video call feature coming soon! Starting video call with ${user}...`);
                      }}
                      className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <Video className="w-5 h-5 text-gray-600" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        alert('More options coming soon!');
                      }}
                      className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <MoreVertical className="w-5 h-5 text-gray-600" />
                    </button>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => {
                    const isSent = message.sender_id === user.id;
                    return (
                      <div
                        key={message.id}
                        className={`flex ${isSent ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                            isSent
                              ? 'bg-gradient-to-r from-green-500 to-teal-600 text-white'
                              : 'bg-white text-gray-900 shadow-sm'
                          }`}
                        >
                          <p className="text-sm">{message.content}</p>
                          <div className={`flex items-center gap-1 mt-1 text-xs ${isSent ? 'text-green-100' : 'text-gray-500'}`}>
                            <span>{formatTime(message.created_at)}</span>
                            {isSent && (
                              message.is_read ? (
                                <CheckCheck className="w-4 h-4" />
                              ) : (
                                <Check className="w-4 h-4" />
                              )
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={messagesEndRef} />
                </div>

                {/* Message Input */}
                <form onSubmit={sendMessage} className="p-4 bg-white border-t border-gray-200">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <Smile className="w-6 h-6 text-gray-500" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const input = document.createElement('input');
                        input.type = 'file';
                        input.accept = 'image/*,application/pdf,.doc,.docx';
                        input.onchange = (e: any) => {
                          const file = e.target?.files?.[0];
                          if (file) {
                            alert(`File attachment feature coming soon! Selected: ${file.name}`);
                          }
                        };
                        input.click();
                      }}
                      className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <Paperclip className="w-6 h-6 text-gray-500" />
                    </button>
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          const form = e.currentTarget.form;
                          if (form) {
                            form.requestSubmit();
                          }
                        }
                      }}
                      placeholder="Type a message..."
                      className="flex-1 px-4 py-3 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-green-500"
                      disabled={sending}
                    />
                    <button
                      type="submit"
                      disabled={!newMessage.trim() || sending}
                      className="p-3 bg-gradient-to-r from-green-500 to-teal-600 text-white rounded-full hover:from-green-600 hover:to-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg active:scale-95"
                    >
                      {sending ? (
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Send className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </form>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center p-8 text-center">
                <div>
                  <MessageCircle className="w-24 h-24 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-gray-700 mb-2">Select a conversation</h3>
                  <p className="text-gray-500">Choose a conversation from the list to start chatting</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};
