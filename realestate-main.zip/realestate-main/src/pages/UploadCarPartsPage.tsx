import { useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Wrench, X, CheckCircle2, AlertCircle, Image as ImageIcon, Check } from 'lucide-react';

export const UploadCarPartsPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    partCategory: '', partName: '', brand: '', partNumber: '', condition: '', price: '',
    compatibleMakes: [] as string[], compatibleModels: '', yearRange: '', warranty: '',
    description: '', locationState: '', locationCity: '', priceNegotiable: false,
    contactPhone: '', contactWhatsapp: ''
  });

  const partCategories = [
    'Engine Parts', 'Transmission', 'Brakes', 'Suspension', 'Exhaust', 'Electrical',
    'Body Parts', 'Interior', 'Wheels & Tires', 'Filters', 'Lights', 'Cooling System',
    'Fuel System', 'Steering', 'Clutch', 'Accessories', 'Tools', 'Other'
  ];
  const brands = [
    'OEM', 'Aftermarket', 'Toyota', 'Honda', 'Mercedes-Benz', 'BMW', 'Lexus', 'Nissan',
    'Ford', 'Volkswagen', 'Hyundai', 'Kia', 'Mazda', 'Audi', 'Peugeot', 'Bosch',
    'Denso', 'NGK', 'Brembo', 'Monroe', 'KYB', 'Mobil', 'Shell', 'Castrol', 'Other'
  ];
  const conditions = ['Brand New', 'Foreign Used', 'Nigerian Used', 'Refurbished'];
  const carMakes = [
    'Toyota', 'Honda', 'Mercedes-Benz', 'BMW', 'Lexus', 'Nissan', 'Ford', 'Volkswagen',
    'Hyundai', 'Kia', 'Mazda', 'Audi', 'Peugeot', 'Acura', 'Infiniti', 'Mitsubishi',
    'Suzuki', 'Subaru', 'Land Rover', 'Range Rover', 'Jeep', 'Universal (Fits All)'
  ];
  const nigeriaStates = [
    'Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo', 'Kaduna', 'Anambra', 'Enugu',
    'Delta', 'Edo', 'Ogun', 'Ondo', 'Osun', 'Kwara', 'Plateau', 'Benue'
  ];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + imageFiles.length > 10) { setError('Maximum 10 images allowed'); return; }
    setImageFiles((prev) => [...prev, ...files]);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreviews((prev) => [...prev, reader.result as string]);
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImageFiles((prev) => prev.filter((_, i) => i !== index));
    setImagePreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const toggleMake = (make: string) => {
    setFormData({
      ...formData,
      compatibleMakes: formData.compatibleMakes.includes(make)
        ? formData.compatibleMakes.filter((m) => m !== make)
        : [...formData.compatibleMakes, make]
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (!user) throw new Error('Please sign in');
      if (imageFiles.length < 2) throw new Error('Upload at least 2 images');

      const imageUrls: string[] = [];
      for (let i = 0; i < imageFiles.length; i++) {
        const file = imageFiles[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/part-${Date.now()}-${i}.${fileExt}`;
        const { error: uploadError } = await supabase.storage.from('listing-images').upload(fileName, file);
        if (!uploadError) {
          const { data: urlData } = supabase.storage.from('listing-images').getPublicUrl(fileName);
          imageUrls.push(urlData.publicUrl);
        }
      }

      const { data: category } = await supabase.from('categories').select('id, slug').eq('slug', 'auto-parts').maybeSingle();

      const listingData = {
        user_id: user.id, category_id: category?.id,
        title: `${formData.brand} ${formData.partName}`,
        description: formData.description, price: parseFloat(formData.price), currency: 'NGN',
        condition: formData.condition, images: imageUrls,
        item_type: formData.partCategory, brand: formData.brand,
        specifications: {
          part_number: formData.partNumber,
          compatible_makes: formData.compatibleMakes,
          compatible_models: formData.compatibleModels,
          year_range: formData.yearRange
        },
        warranty_status: formData.warranty, price_negotiable: formData.priceNegotiable,
        location_state: formData.locationState, location_city: formData.locationCity,
        contact_phone: formData.contactPhone, contact_whatsapp: formData.contactWhatsapp, status: 'active'
      };

      const { data: listing, error: listingError } = await supabase.from('listings').insert(listingData).select().single();
      if (listingError) throw listingError;
      setSuccess(true);
      setTimeout(() => {
        window.location.href = category?.slug ? `/category/${category.slug}` : '/';
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) { window.location.href = '/post-ad'; return null; }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />
      <main className="flex-1">
        <div className="bg-gradient-to-r from-gray-700 via-gray-800 to-gray-900 text-white py-10 px-4 shadow-xl">
          <div className="max-w-5xl mx-auto">
            <a href="/post-ad" className="text-white/90 hover:text-white text-sm font-semibold mb-3 inline-block">← Back</a>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold mb-2">Sell Car Parts & Accessories</h1>
                <p className="text-white/95 text-lg">List auto parts and accessories</p>
              </div>
              <div className="hidden md:flex w-20 h-20 bg-white/20 rounded-2xl items-center justify-center">
                <Wrench className="w-10 h-10 text-white" />
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-5xl mx-auto px-4 py-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {success && (
              <div className="p-5 bg-green-50 border-2 border-green-200 rounded-xl flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-green-800 text-lg">Success!</p>
                  <p className="text-green-700 text-sm">Your car part listing has been published</p>
                </div>
              </div>
            )}
            {error && (
              <div className="p-5 bg-red-50 border-2 border-red-200 rounded-xl flex items-start gap-3">
                <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-red-700">{error}</span>
              </div>
            )}

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-gray-200">Part Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Part Category *</label>
                  <select
                    value={formData.partCategory}
                    onChange={(e) => setFormData({ ...formData, partCategory: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  >
                    <option value="">Select category</option>
                    {partCategories.map((cat) => <option key={cat} value={cat}>{cat}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Part Name *</label>
                  <input
                    type="text"
                    value={formData.partName}
                    onChange={(e) => setFormData({ ...formData, partName: e.target.value })}
                    placeholder="e.g., Brake Pads, Engine Oil Filter"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Brand *</label>
                  <select
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  >
                    <option value="">Select brand</option>
                    {brands.map((brand) => <option key={brand} value={brand}>{brand}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Part Number (Optional)</label>
                  <input
                    type="text"
                    value={formData.partNumber}
                    onChange={(e) => setFormData({ ...formData, partNumber: e.target.value })}
                    placeholder="e.g., 04465-0K270"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Condition *</label>
                  <select
                    value={formData.condition}
                    onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  >
                    <option value="">Select condition</option>
                    {conditions.map((cond) => <option key={cond} value={cond}>{cond}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Warranty Status</label>
                  <select
                    value={formData.warranty}
                    onChange={(e) => setFormData({ ...formData, warranty: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  >
                    <option value="">Select warranty</option>
                    <option value="No Warranty">No Warranty</option>
                    <option value="3 Months">3 Months Warranty</option>
                    <option value="6 Months">6 Months Warranty</option>
                    <option value="1 Year">1 Year Warranty</option>
                    <option value="2 Years">2 Years Warranty</option>
                    <option value="Lifetime">Lifetime Warranty</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-gray-200">Vehicle Compatibility</h2>
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-3">Compatible Car Makes (Select all that apply)</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {carMakes.map((make) => (
                      <label
                        key={make}
                        className={`flex items-center gap-2 p-3 border-2 rounded-lg cursor-pointer transition-all ${
                          formData.compatibleMakes.includes(make)
                            ? 'border-gray-700 bg-gray-50'
                            : 'border-gray-200 hover:border-gray-400'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={formData.compatibleMakes.includes(make)}
                          onChange={() => toggleMake(make)}
                          className="w-4 h-4 text-gray-700 rounded focus:ring-gray-500"
                        />
                        <span className="text-sm font-semibold text-gray-900">{make}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Compatible Models (Optional)</label>
                  <input
                    type="text"
                    value={formData.compatibleModels}
                    onChange={(e) => setFormData({ ...formData, compatibleModels: e.target.value })}
                    placeholder="e.g., Camry, Corolla, Accord, Civic"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Year Range (Optional)</label>
                  <input
                    type="text"
                    value={formData.yearRange}
                    onChange={(e) => setFormData({ ...formData, yearRange: e.target.value })}
                    placeholder="e.g., 2015-2023"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-gray-200">Photos</h2>
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-gray-500 bg-gray-50 transition-colors">
                <ImageIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-2 font-semibold text-lg">Upload clear photos of your part</p>
                <p className="text-sm text-gray-500 mb-4">Up to 10 images (Min 2 required)</p>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                  id="image-upload"
                />
                <label
                  htmlFor="image-upload"
                  className="px-8 py-3 bg-gray-800 text-white rounded-lg cursor-pointer hover:bg-gray-900 inline-block font-bold transition-colors"
                >
                  Choose Images
                </label>
              </div>
              {imagePreviews.length > 0 && (
                <div className="mt-6">
                  <p className="font-bold text-gray-900 mb-3 text-lg">{imagePreviews.length} image(s) selected</p>
                  <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative aspect-square rounded-lg overflow-hidden border-2 border-gray-200 group">
                        <img src={preview} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full hover:bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-gray-200">Description</h2>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe the part condition, features, installation notes, and any additional information..."
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
              />
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-gray-200">Location</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">State *</label>
                  <select
                    value={formData.locationState}
                    onChange={(e) => setFormData({ ...formData, locationState: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  >
                    <option value="">Select state</option>
                    {nigeriaStates.map((state) => <option key={state} value={state}>{state}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">City/Area *</label>
                  <input
                    type="text"
                    value={formData.locationCity}
                    onChange={(e) => setFormData({ ...formData, locationCity: e.target.value })}
                    placeholder="e.g., Ikeja, Victoria Island"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-gray-200">Price & Contact</h2>
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Price (₦) *</label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-gray-400">₦</div>
                    <input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      placeholder="0"
                      required
                      min="0"
                      className="w-full pl-12 pr-4 py-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent text-xl font-bold"
                    />
                  </div>
                </div>
                <label className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-gray-400 transition-colors">
                  <input
                    type="checkbox"
                    checked={formData.priceNegotiable}
                    onChange={(e) => setFormData({ ...formData, priceNegotiable: e.target.checked })}
                    className="w-5 h-5 text-gray-700 rounded focus:ring-gray-500"
                  />
                  <span className="font-bold text-gray-900">Price is negotiable</span>
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      value={formData.contactPhone}
                      onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                      placeholder="+234 800 000 0000"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">WhatsApp Number (Optional)</label>
                    <input
                      type="tel"
                      value={formData.contactWhatsapp}
                      onChange={(e) => setFormData({ ...formData, contactWhatsapp: e.target.value })}
                      placeholder="+234 800 000 0000"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-6 border-t-2 border-gray-200">
              <a
                href="/post-ad"
                className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-lg font-bold hover:bg-gray-50 transition-colors"
              >
                Cancel
              </a>
              <button
                type="submit"
                disabled={loading || imageFiles.length < 2}
                className="px-12 py-3 bg-gradient-to-r from-gray-800 to-gray-900 text-white rounded-lg font-bold hover:from-gray-900 hover:to-black disabled:opacity-50 disabled:cursor-not-allowed shadow-lg flex items-center gap-3 transition-all"
              >
                {loading ? (
                  <>
                    <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                    Publishing...
                  </>
                ) : (
                  <>
                    <Check className="w-5 h-5" />
                    Publish Listing
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
};
