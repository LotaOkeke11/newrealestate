import { useState } from 'react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { ShoppingBasket, Utensils, ArrowRight, Sparkles } from 'lucide-react';

export const FoodCategoryPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const categories = [
    {
      name: 'Foodstuffs',
      slug: 'foodstuffs',
      icon: ShoppingBasket,
      gradient: 'from-lime-500 to-green-500',
      description: 'Sell rice, oil, beans, and groceries',
      path: '/upload/foodstuffs'
    },
    {
      name: 'Restaurants',
      slug: 'restaurants',
      icon: Utensils,
      gradient: 'from-orange-500 to-red-500',
      description: 'Add your restaurant and food menu',
      path: '/upload/restaurants'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex flex-col">
      <Header />

      <main className="flex-1 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-3 bg-gradient-to-r from-orange-500 to-amber-500 rounded-2xl mb-4">
            <Utensils className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Food & Restaurants
          </h1>
          <p className="text-xl text-gray-600">
            Choose what you want to list
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <a
                key={category.slug}
                href={category.path}
                className="group bg-white rounded-3xl p-10 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-2 border-transparent hover:border-orange-300"
              >
                <div className={`w-20 h-20 bg-gradient-to-br ${category.gradient} rounded-3xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg`}>
                  <Icon className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-3 group-hover:text-orange-600 transition-colors">
                  {category.name}
                </h3>
                <p className="text-gray-600 mb-6">{category.description}</p>
                <div className="flex items-center text-orange-600 font-semibold group-hover:gap-3 gap-2 transition-all">
                  <span>Get Started</span>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </div>
              </a>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <a
            href="/post-ad"
            className="inline-flex items-center gap-2 text-gray-600 hover:text-orange-600 font-semibold transition-colors"
          >
            <ArrowRight className="w-4 h-4 rotate-180" />
            Back to Categories
          </a>
        </div>
      </main>

      <Footer />
    </div>
  );
};
