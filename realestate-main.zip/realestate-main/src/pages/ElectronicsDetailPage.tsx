import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  ShoppingCart, Heart, Share2, Star, Truck, ShieldCheck, RotateCcw,
  ChevronLeft, ChevronRight, Check, X, Package, Award, MessageCircle,
  Smartphone, Zap, TrendingUp, Clock, MapPin, Phone
} from 'lucide-react';

type ElectronicsListing = {
  id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  images: string[];
  condition: string;
  brand: string;
  specifications: any;
  warranty_status: string;
  warranty_months: number;
  location_city: string;
  location_state: string;
  contact_phone: string;
  contact_whatsapp: string;
  created_at: string;
  views_count: number;
  profile: {
    full_name: string;
    avatar_url: string;
  };
  verification?: {
    status: string;
  };
};

export const ElectronicsDetailPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [listing, setListing] = useState<ElectronicsListing | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedToCart, setAddedToCart] = useState(false);

  const listingId = window.location.pathname.split('/electronics/')[1];

  useEffect(() => {
    loadListing();
    incrementViewCount();
  }, [listingId]);

  const loadListing = async () => {
    const { data } = await supabase
      .from('listings')
      .select(`
        *,
        profile:profiles!user_id(full_name, avatar_url),
        verification:seller_verifications(status)
      `)
      .eq('id', listingId)
      .single();

    if (data) {
      setListing(data as any);
    }
    setLoading(false);
  };

  const incrementViewCount = async () => {
    await supabase.rpc('increment_listing_views', { listing_id: listingId });
  };

  const addToCart = async () => {
    if (!user) {
      window.location.href = '/login';
      return;
    }

    await supabase.from('cart_items').upsert({
      user_id: user.id,
      listing_id: listingId,
      quantity: quantity,
      price_at_addition: listing?.price,
    });

    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 3000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Smartphone className="w-20 h-20 text-gray-300 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Product Not Found</h2>
            <a href="/electronics" className="text-orange-600 hover:text-orange-700">
              Browse all electronics
            </a>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const specs = listing.specifications || {};
  const savings = 0;
  const originalPrice = listing.price + savings;
  const discountPercent = savings > 0 ? Math.round((savings / originalPrice) * 100) : 0;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      {addedToCart && (
        <div className="fixed top-24 right-4 z-50 animate-scale-in">
          <div className="bg-green-500 text-white px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3">
            <Check className="w-6 h-6" />
            <span className="font-bold">Added to cart!</span>
          </div>
        </div>
      )}

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full">
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <div className="relative aspect-square bg-gray-100 rounded-xl overflow-hidden mb-4">
                <img
                  src={listing.images[currentImageIndex] || '/placeholder.png'}
                  alt={listing.title}
                  className="w-full h-full object-contain p-8"
                />
                {discountPercent > 0 && (
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-red-500 text-white rounded-lg font-bold text-sm">
                      -{discountPercent}%
                    </span>
                  </div>
                )}
                <div className="absolute top-4 right-4 flex gap-2">
                  <button className="p-2 bg-white rounded-full shadow-lg hover:bg-gray-50">
                    <Heart className="w-5 h-5" />
                  </button>
                  <button className="p-2 bg-white rounded-full shadow-lg hover:bg-gray-50">
                    <Share2 className="w-5 h-5" />
                  </button>
                </div>

                {listing.images.length > 1 && (
                  <>
                    <button
                      onClick={() =>
                        setCurrentImageIndex((prev) =>
                          prev === 0 ? listing.images.length - 1 : prev - 1
                        )
                      }
                      className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-white/90 rounded-full shadow-lg hover:bg-white"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() =>
                        setCurrentImageIndex((prev) =>
                          prev === listing.images.length - 1 ? 0 : prev + 1
                        )
                      }
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-white/90 rounded-full shadow-lg hover:bg-white"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </>
                )}
              </div>

              {listing.images.length > 1 && (
                <div className="flex gap-2 overflow-x-auto pb-2">
                  {listing.images.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 ${
                        index === currentImageIndex
                          ? 'border-orange-500'
                          : 'border-gray-200'
                      }`}
                    >
                      <img src={image} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              <div className="mt-6 space-y-3">
                <h3 className="font-bold text-gray-900 text-lg mb-3">Delivery & Returns</h3>
                <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-xl">
                  <Truck className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900">Free Delivery</p>
                    <p className="text-sm text-gray-600">
                      Free delivery within {listing.location_city}
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-xl">
                  <RotateCcw className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900">Return Policy</p>
                    <p className="text-sm text-gray-600">7 days return guarantee</p>
                  </div>
                </div>
                {listing.warranty_status && (
                  <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-xl">
                    <ShieldCheck className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">Warranty</p>
                      <p className="text-sm text-gray-600">
                        {listing.warranty_months} months {listing.warranty_status}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div>
              <div className="mb-4">
                {listing.brand && (
                  <p className="text-orange-600 font-semibold mb-1">{listing.brand}</p>
                )}
                <h1 className="text-2xl font-bold text-gray-900 mb-3">{listing.title}</h1>
                <div className="flex items-center gap-4 mb-4">
                  <button
                    onClick={() => {
                      const reviewsSection = document.querySelector('[data-reviews-section]');
                      reviewsSection?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-amber-50 border-2 border-amber-200 rounded-lg hover:bg-amber-100 transition-colors"
                  >
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className="w-4 h-4 text-amber-400 fill-amber-400"
                      />
                    ))}
                    <span className="text-sm font-semibold text-gray-900 ml-1">View Reviews</span>
                  </button>
                  <span className="text-sm text-gray-500">|</span>
                  <span className="text-sm text-gray-600">{listing.views_count} views</span>
                </div>

                <div className="p-4 bg-orange-50 border-2 border-orange-200 rounded-xl mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    {discountPercent > 0 && (
                      <span className="text-2xl text-gray-400 line-through">
                        ₦{originalPrice.toLocaleString()}
                      </span>
                    )}
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold text-orange-600">
                      ₦{listing.price.toLocaleString()}
                    </span>
                    {discountPercent > 0 && (
                      <span className="px-2 py-1 bg-orange-600 text-white rounded text-sm font-bold">
                        Save {discountPercent}%
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3">
                  <span className="text-gray-700">Condition:</span>
                  <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-semibold capitalize">
                    {listing.condition}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-700">
                    {listing.location_city}, {listing.location_state}
                  </span>
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Quantity
                </label>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 border-2 border-gray-300 rounded-lg font-bold hover:bg-gray-50"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-20 px-3 py-2 border-2 border-gray-300 rounded-lg text-center font-bold"
                  />
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 border-2 border-gray-300 rounded-lg font-bold hover:bg-gray-50"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                {listing.contact_phone && (
                  <div className="grid grid-cols-2 gap-3">
                    <a
                      href={`tel:${listing.contact_phone}`}
                      className="py-4 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
                    >
                      <Phone className="w-5 h-5" />
                      Call
                    </a>
                    <a
                      href={`https://wa.me/${(listing.contact_whatsapp || listing.contact_phone).replace(/\D/g, '')}?text=${encodeURIComponent(`Hi, I'm interested in: ${listing.title}`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-4 bg-[#25D366] hover:bg-[#20BD5A] text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
                    >
                      <MessageCircle className="w-5 h-5" />
                      WhatsApp
                    </a>
                  </div>
                )}
                <button
                  onClick={addToCart}
                  className="w-full py-4 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-xl font-bold hover:from-orange-600 hover:to-orange-700 transition-all shadow-lg flex items-center justify-center gap-2"
                >
                  <ShoppingCart className="w-5 h-5" />
                  Add to Cart
                </button>
                <button
                  onClick={async () => {
                    await addToCart();
                    window.location.href = '/cart';
                  }}
                  className="w-full py-4 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-bold hover:from-blue-600 hover:to-blue-700 transition-all shadow-lg flex items-center justify-center gap-2"
                >
                  <Zap className="w-5 h-5" />
                  Buy Now
                </button>
              </div>

              {listing.verification?.status === 'approved' && (
                <div className="flex items-center gap-2 p-3 bg-blue-50 border border-blue-200 rounded-xl mb-4">
                  <Award className="w-5 h-5 text-blue-600" />
                  <span className="text-sm font-semibold text-blue-800">
                    Verified Seller
                  </span>
                </div>
              )}

              <div className="border-t pt-4">
                <h3 className="font-bold text-gray-900 mb-3">Seller Information</h3>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-500 rounded-full overflow-hidden">
                    {listing.profile.avatar_url ? (
                      <img
                        src={listing.profile.avatar_url}
                        alt={listing.profile.full_name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-white font-bold">
                        {listing.profile.full_name.charAt(0)}
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">
                      {listing.profile.full_name}
                    </p>
                    <p className="text-sm text-gray-600">Active seller</p>
                  </div>
                </div>

                {listing.contact_whatsapp && (
                  <a
                    href={`https://wa.me/${listing.contact_whatsapp.replace(/\D/g, '')}?text=Hi, I'm interested in: ${listing.title}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full py-3 bg-green-500 text-white rounded-xl font-semibold hover:bg-green-600 transition-all"
                  >
                    <MessageCircle className="w-5 h-5" />
                    Chat with Seller
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Product Description</h2>
            <div className="prose max-w-none text-gray-700 whitespace-pre-line mb-6">
              {listing.description}
            </div>

            {Object.keys(specs).length > 0 && (
              <>
                <h3 className="text-lg font-bold text-gray-900 mb-4">Specifications</h3>
                <div className="space-y-2">
                  {Object.entries(specs).map(([key, value]) => (
                    <div
                      key={key}
                      className="flex justify-between py-3 border-b border-gray-100"
                    >
                      <span className="text-gray-600 capitalize">
                        {key.replace(/_/g, ' ')}
                      </span>
                      <span className="font-semibold text-gray-900">{String(value)}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>

          <div className="bg-white rounded-2xl shadow-sm p-6">
            <h3 className="font-bold text-gray-900 mb-4">Why Buy From Us?</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Check className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Authentic Products</p>
                  <p className="text-sm text-gray-600">100% genuine electronics</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <ShieldCheck className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Secure Payment</p>
                  <p className="text-sm text-gray-600">Safe and encrypted</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Truck className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Fast Delivery</p>
                  <p className="text-sm text-gray-600">Same day in select areas</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <RotateCcw className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Easy Returns</p>
                  <p className="text-sm text-gray-600">7 days hassle-free</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};
