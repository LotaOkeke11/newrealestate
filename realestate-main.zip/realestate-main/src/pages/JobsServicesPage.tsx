import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  Briefcase,
  MapPin,
  Star,
  ShieldCheck,
  Filter,
  Plus,
  Eye,
  Camera,
  Video,
  Edit3,
  Palette,
  Music,
  PartyPopper,
} from 'lucide-react';

type ServiceListing = {
  id: string;
  title: string;
  description: string;
  price: number;
  images: string[];
  portfolio_urls: string[];
  location_city: string;
  location_state: string;
  service_type: string;
  created_at: string;
  profile: {
    full_name: string;
    avatar_url: string;
  };
  verification?: {
    verification_level: number;
    status: string;
  };
};

export const JobsServicesPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [services, setServices] = useState<ServiceListing[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    serviceType: '',
    location: '',
    minPrice: '',
    maxPrice: '',
    verifiedOnly: false,
  });

  const serviceTypes = [
    { value: 'videographer', label: 'Videographer', icon: Video },
    { value: 'photographer', label: 'Photographer', icon: Camera },
    { value: 'editor', label: 'Video/Photo Editor', icon: Edit3 },
    { value: 'designer', label: 'Graphic Designer', icon: Palette },
    { value: 'dj', label: 'DJ Services', icon: Music },
  ];

  const states = ['Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo'];

  useEffect(() => {
    loadServices();
  }, [filters]);

  const loadServices = async () => {
    setLoading(true);

    let query = supabase
      .from('listings')
      .select(`
        id,
        title,
        description,
        price,
        images,
        portfolio_urls,
        location_city,
        location_state,
        service_type,
        created_at,
        profile:profiles(full_name, avatar_url),
        verification:seller_verifications(verification_level, status)
      `)
      .eq('status', 'active')
      .not('service_type', 'is', null);

    if (filters.serviceType) {
      query = query.eq('service_type', filters.serviceType);
    }

    if (filters.location) {
      query = query.eq('location_state', filters.location);
    }

    if (filters.minPrice) {
      query = query.gte('price', parseInt(filters.minPrice));
    }

    if (filters.maxPrice) {
      query = query.lte('price', parseInt(filters.maxPrice));
    }

    query = query.order('created_at', { ascending: false }).limit(50);

    const { data } = await query;

    if (data) {
      let results = data as any;

      if (filters.verifiedOnly) {
        results = results.filter(
          (item: any) => item.verification?.status === 'approved'
        );
      }

      setServices(results);
    }
    setLoading(false);
  };

  const getServiceIcon = (type: string) => {
    const service = serviceTypes.find((s) => s.value === type);
    return service?.icon || Briefcase;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl">
                <Briefcase className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-gray-900">Jobs & Services</h1>
                <p className="text-gray-600 text-lg">
                  {loading ? 'Loading...' : `${services.length} professionals available`}
                </p>
              </div>
            </div>

            {user && (
              <a
                href="/post-service"
                className="px-6 py-3 bg-gradient-to-r from-purple-500 to-indigo-600 text-white rounded-xl font-bold hover:from-purple-600 hover:to-indigo-700 transition-all shadow-lg flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Offer Service
              </a>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-xl p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-6">
                <Filter className="w-5 h-5 text-amber-600" />
                <h2 className="text-lg font-bold text-gray-900">Filters</h2>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Service Type
                  </label>
                  <select
                    value={filters.serviceType}
                    onChange={(e) => setFilters({ ...filters, serviceType: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                  >
                    <option value="">All Services</option>
                    {serviceTypes.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Location
                  </label>
                  <select
                    value={filters.location}
                    onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                  >
                    <option value="">All Locations</option>
                    {states.map((state) => (
                      <option key={state} value={state}>
                        {state}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Price Range
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      placeholder="Min"
                      value={filters.minPrice}
                      onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })}
                      className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:outline-none focus:border-amber-400"
                    />
                    <input
                      type="number"
                      placeholder="Max"
                      value={filters.maxPrice}
                      onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
                      className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 bg-green-50 border-2 border-green-200 rounded-xl">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-semibold text-green-700">
                      Verified Only
                    </span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={filters.verifiedOnly}
                      onChange={(e) =>
                        setFilters({ ...filters, verifiedOnly: e.target.checked })
                      }
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                  </label>
                </div>

                <button
                  onClick={() =>
                    setFilters({
                      serviceType: '',
                      location: '',
                      minPrice: '',
                      maxPrice: '',
                      verifiedOnly: false,
                    })
                  }
                  className="w-full py-2 border-2 border-amber-200 text-amber-700 rounded-xl font-semibold hover:bg-amber-50 transition-all"
                >
                  Clear Filters
                </button>
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <div className="text-center">
                  <div className="animate-spin w-16 h-16 border-4 border-amber-600 border-t-transparent rounded-full mx-auto mb-4"></div>
                  <p className="text-gray-600">Loading services...</p>
                </div>
              </div>
            ) : services.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
                <Briefcase className="w-24 h-24 text-gray-300 mx-auto mb-6" />
                <h2 className="text-2xl font-bold text-gray-900 mb-3">No services found</h2>
                <p className="text-gray-600 mb-6">
                  Try adjusting your filters to see more results
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {services.map((service) => {
                  const ServiceIcon = getServiceIcon(service.service_type);
                  return (
                    <div
                      key={service.id}
                      className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all p-6"
                    >
                      <div className="flex items-start gap-6">
                        <div className="w-32 h-32 bg-gray-100 rounded-2xl overflow-hidden flex-shrink-0">
                          {service.images && service.images.length > 0 ? (
                            <img
                              src={service.images[0]}
                              alt={service.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <ServiceIcon className="w-12 h-12 text-gray-400" />
                            </div>
                          )}
                        </div>

                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h3 className="text-xl font-bold text-gray-900 mb-2">
                                {service.title}
                              </h3>
                              <div className="flex items-center gap-3 text-sm text-gray-600">
                                <div className="flex items-center gap-1">
                                  <MapPin className="w-4 h-4" />
                                  <span>
                                    {service.location_city}, {service.location_state}
                                  </span>
                                </div>
                                {service.verification?.status === 'approved' && (
                                  <div className="flex items-center gap-1 px-2 py-1 bg-green-100 text-green-700 rounded-full">
                                    <ShieldCheck className="w-3 h-3" />
                                    <span className="text-xs font-semibold">Verified</span>
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-sm text-gray-500 mb-1">Starting at</p>
                              <p className="text-2xl font-bold text-purple-600">
                                ₦{service.price.toLocaleString()}
                              </p>
                            </div>
                          </div>

                          <p className="text-gray-700 mb-4 line-clamp-2">
                            {service.description}
                          </p>

                          {service.portfolio_urls && service.portfolio_urls.length > 0 && (
                            <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                              {service.portfolio_urls.slice(0, 4).map((url, index) => (
                                <div
                                  key={index}
                                  className="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0"
                                >
                                  <img
                                    src={url}
                                    alt={`Portfolio ${index + 1}`}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                              ))}
                              {service.portfolio_urls.length > 4 && (
                                <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                  <span className="text-sm font-bold text-gray-600">
                                    +{service.portfolio_urls.length - 4}
                                  </span>
                                </div>
                              )}
                            </div>
                          )}

                          <div className="flex items-center gap-3">
                            <a
                              href={`/listing/${service.id}`}
                              className="px-6 py-2 bg-gradient-to-r from-purple-500 to-indigo-600 text-white rounded-xl font-bold hover:from-purple-600 hover:to-indigo-700 transition-all flex items-center gap-2"
                            >
                              <Eye className="w-4 h-4" />
                              View Details
                            </a>
                            <a
                              href={`/messages?seller=${service.profile?.full_name}`}
                              className="px-6 py-2 border-2 border-purple-200 text-purple-700 rounded-xl font-bold hover:bg-purple-50 transition-all"
                            >
                              Contact
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};
