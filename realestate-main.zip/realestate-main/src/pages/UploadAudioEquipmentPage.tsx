import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import {
  Music, Upload, X, AlertCircle, CheckCircle, Radio, Mic,
  Volume2, Headphones, Cable, Disc, Speaker, Box, Plus, Settings,
  Zap, Award, Package, Sparkles, ShoppingBag, Play
} from 'lucide-react';

const AUDIO_CATEGORIES = [
  {
    value: 'Studio Recording',
    icon: Mic,
    subcategories: [
      'Studio Microphones',
      'Audio Interfaces',
      'Studio Monitors',
      'Preamps',
      'Compressors',
      'Equalizers',
      'Vocal Booths',
      'Pop Filters',
      'Shock Mounts',
      'Mic Stands'
    ]
  },
  {
    value: 'Live Sound & PA',
    icon: Speaker,
    subcategories: [
      'PA Speakers',
      'Subwoofers',
      'Power Amplifiers',
      'Powered Mixers',
      'Line Arrays',
      'Stage Monitors',
      'PA Systems Complete',
      'Portable PA Systems',
      'Column Speakers'
    ]
  },
  {
    value: 'DJ Equipment',
    icon: Disc,
    subcategories: [
      'DJ Controllers',
      'CDJ Players',
      'DJ Mixers',
      'Turntables',
      'DJ Headphones',
      'DJ Software',
      'Vinyl Records',
      'Slipmats',
      'DJ Cases'
    ]
  },
  {
    value: 'Microphones',
    icon: Mic,
    subcategories: [
      'Condenser Microphones',
      'Dynamic Microphones',
      'Ribbon Microphones',
      'USB Microphones',
      'Wireless Microphones',
      'Lavalier Microphones',
      'Shotgun Microphones',
      'Podcast Microphones',
      'Instrument Microphones'
    ]
  },
  {
    value: 'Speakers & Monitors',
    icon: Volume2,
    subcategories: [
      'Studio Monitors',
      'Bookshelf Speakers',
      'Bluetooth Speakers',
      'Portable Speakers',
      'Boombox',
      'Soundbars',
      'Home Theater Speakers',
      'Ceiling Speakers',
      'Outdoor Speakers'
    ]
  },
  {
    value: 'Headphones & Earphones',
    icon: Headphones,
    subcategories: [
      'Studio Headphones',
      'DJ Headphones',
      'Wireless Headphones',
      'In-Ear Monitors',
      'Gaming Headsets',
      'Noise Cancelling Headphones',
      'True Wireless Earbuds',
      'Wired Earphones',
      'Sport Earphones'
    ]
  },
  {
    value: 'Mixers & Controllers',
    icon: Settings,
    subcategories: [
      'Analog Mixers',
      'Digital Mixers',
      'USB Mixers',
      'Rack Mixers',
      'DJ Mixers',
      'Powered Mixers',
      'MIDI Controllers',
      'DAW Controllers',
      'Audio Routers'
    ]
  },
  {
    value: 'Cables & Accessories',
    icon: Cable,
    subcategories: [
      'XLR Cables',
      'TRS Cables',
      'Instrument Cables',
      'Speaker Cables',
      'Patch Cables',
      'USB Cables',
      'Adapters',
      'Cable Organizers',
      'DI Boxes'
    ]
  },
  {
    value: 'Amplifiers',
    icon: Radio,
    subcategories: [
      'Power Amplifiers',
      'Integrated Amplifiers',
      'Tube Amplifiers',
      'Class D Amplifiers',
      'Headphone Amplifiers',
      'Guitar Amplifiers',
      'Bass Amplifiers',
      'Keyboard Amplifiers',
      'PA Amplifiers'
    ]
  },
  {
    value: 'Sound Processing',
    icon: Zap,
    subcategories: [
      'Effects Processors',
      'Reverb Units',
      'Delay Units',
      'Vocal Processors',
      'Multieffects',
      'Rack Effects',
      'Pedals',
      'Crossovers',
      'Feedback Suppressors'
    ]
  }
];

const BRANDS = [
  'Shure', 'Sennheiser', 'Audio-Technica', 'Neumann', 'AKG', 'Rode',
  'Yamaha', 'JBL', 'Pioneer', 'Sony', 'Bose', 'QSC', 'Mackie',
  'Behringer', 'Allen & Heath', 'Focusrite', 'PreSonus', 'KRK',
  'M-Audio', 'Native Instruments', 'Beyerdynamic', 'Blue', 'Electro-Voice',
  'Crown', 'dbx', 'Soundcraft', 'Midas', 'RCF', 'EV', 'Genelec',
  'Adam Audio', 'Universal Audio', 'Apogee', 'RME', 'Tascam',
  'Denon', 'Technics', 'Numark', 'Rane', 'Vestax', 'Ortofon'
];

const CONNECTIVITY = [
  'XLR', 'TRS/TS', 'USB', 'Bluetooth', 'WiFi', 'AES/EBU',
  'ADAT', 'S/PDIF', 'Dante', 'AVB', 'MADI', 'Thunderbolt',
  'FireWire', 'RCA', 'SpeakON', '3.5mm Jack', '6.35mm Jack',
  'Optical', 'Wireless 2.4GHz', 'NFC'
];

const CONDITIONS = ['Brand New', 'Like New', 'Excellent', 'Good', 'Fair'];

const POWER_TYPES = [
  'AC Powered', 'Battery Powered', 'USB Powered', 'Phantom Power (48V)',
  'AA Batteries', 'Rechargeable Battery', 'Solar Powered', 'Power over Ethernet'
];

export const UploadAudioEquipmentPage = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    category: '',
    subcategory: '',
    title: '',
    description: '',
    brand: '',
    model: '',
    condition: 'Brand New',
    price: '',
    negotiable: true,
    power: '',
    watts: '',
    impedance: '',
    frequency_response: '',
    sensitivity: '',
    spl_max: '',
    channels: '',
    sample_rate: '',
    bit_depth: '',
    thd: '',
    signal_to_noise: '',
    driver_size: '',
    bluetooth_version: '',
    battery_life: '',
    weight: '',
    dimensions: '',
    rack_units: '',
    color: '',
    year_manufactured: '',
    warranty: '',
    warranty_period: '',
    location_city: '',
    location_state: '',
    shipping_available: false,
    shipping_fee: '',
    international_shipping: false,
    accessories_included: '',
    original_packaging: false,
    manual_included: false,
    tested_working: true,
  });

  const [connectivity, setConnectivity] = useState<string[]>([]);
  const [additionalFeatures, setAdditionalFeatures] = useState<string[]>([]);
  const [images, setImages] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);

  const FEATURES_LIST = [
    'Bluetooth Enabled',
    'WiFi Enabled',
    'Multi-room Audio',
    'Voice Control',
    'App Control',
    'Touch Controls',
    'LED Display',
    'Remote Control',
    'EQ Settings',
    'Presets',
    'Effects Built-in',
    'Recording Capable',
    'USB Recording',
    'SD Card Slot',
    'Aux Input',
    'Optical Input',
    'Balanced Outputs',
    'Phantom Power',
    'Battery Indicator',
    'Waterproof/Resistant',
    'Shockproof',
    'Foldable',
    'Portable',
    'Rack Mountable',
    'Stackable',
    'Active/Powered',
    'Passive',
    'Class D Technology',
    'DSP Processing',
    'Auto Calibration'
  ];

  const handleConnectivityToggle = (conn: string) => {
    if (connectivity.includes(conn)) {
      setConnectivity(connectivity.filter(c => c !== conn));
    } else {
      setConnectivity([...connectivity, conn]);
    }
  };

  const handleFeatureToggle = (feature: string) => {
    if (additionalFeatures.includes(feature)) {
      setAdditionalFeatures(additionalFeatures.filter(f => f !== feature));
    } else {
      setAdditionalFeatures([...additionalFeatures, feature]);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (images.length + files.length > 10) {
      setError('Maximum 10 images allowed');
      return;
    }

    setImages([...images, ...files]);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviews(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
    setPreviews(previews.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setError('Please login to post a listing');
      return;
    }

    if (images.length === 0) {
      setError('Please upload at least one image');
      return;
    }

    setUploading(true);
    setError('');

    try {
      const imageUrls: string[] = [];

      for (const image of images) {
        const fileExt = image.name.split('.').pop();
        const fileName = `${user.id}/${Date.now()}_${Math.random()}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from('listings')
          .upload(fileName, image);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('listings')
          .getPublicUrl(fileName);

        imageUrls.push(publicUrl);
      }

      const { error: insertError } = await supabase
        .from('listings')
        .insert({
          user_id: user.id,
          category_id: (await supabase.from('categories').select('id').eq('slug', 'electronics').single()).data?.id,
          title: formData.title,
          description: formData.description,
          price: parseFloat(formData.price),
          currency: 'NGN',
          images: imageUrls,
          location_city: formData.location_city,
          location_state: formData.location_state,
          metadata: {
            audio_category: formData.category,
            subcategory: formData.subcategory,
            brand: formData.brand,
            model: formData.model,
            condition: formData.condition,
            negotiable: formData.negotiable,
            power_type: formData.power,
            specifications: {
              watts: formData.watts,
              impedance: formData.impedance,
              frequency_response: formData.frequency_response,
              sensitivity: formData.sensitivity,
              spl_max: formData.spl_max,
              channels: formData.channels,
              sample_rate: formData.sample_rate,
              bit_depth: formData.bit_depth,
              thd: formData.thd,
              signal_to_noise: formData.signal_to_noise,
              driver_size: formData.driver_size,
              bluetooth_version: formData.bluetooth_version,
              battery_life: formData.battery_life,
              weight: formData.weight,
              dimensions: formData.dimensions,
              rack_units: formData.rack_units
            },
            connectivity: connectivity,
            color: formData.color,
            year_manufactured: formData.year_manufactured,
            warranty: formData.warranty,
            warranty_period: formData.warrantyPeriod,
            shipping_available: formData.shipping_available,
            shipping_fee: formData.shipping_fee,
            international_shipping: formData.international_shipping,
            accessories_included: formData.accessories_included,
            original_packaging: formData.original_packaging,
            manual_included: formData.manual_included,
            tested_working: formData.tested_working,
            additional_features: additionalFeatures
          }
        });

      if (insertError) throw insertError;

      setSuccess(true);
      setTimeout(() => {
        window.location.href = '/';
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to create listing');
    } finally {
      setUploading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-purple-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-4">Login Required</h2>
          <p className="text-gray-600 mb-4">Please login to list your audio equipment</p>
          <a href="/login" className="px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600">
            Login
          </a>
        </div>
      </div>
    );
  }

  const selectedCategory = AUDIO_CATEGORIES.find(cat => cat.value === formData.category);

  const steps = [
    { number: 1, title: 'Category & Details', icon: Music },
    { number: 2, title: 'Technical Specs', icon: Settings },
    { number: 3, title: 'Features & Connectivity', icon: Zap },
    { number: 4, title: 'Images & Submit', icon: Sparkles }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 flex flex-col">
      <Header />

      <main className="flex-1 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl shadow-lg">
                <Music className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  List Your Audio Equipment
                </h1>
                <p className="text-gray-600">Speakers, microphones, mixers & more</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mb-8">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center flex-1">
                <div className="flex flex-col items-center flex-1">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold transition-all ${
                    currentStep >= step.number
                      ? 'bg-gradient-to-br from-blue-600 to-purple-600 text-white shadow-lg scale-110'
                      : 'bg-gray-200 text-gray-400'
                  }`}>
                    {currentStep > step.number ? (
                      <CheckCircle className="w-6 h-6" />
                    ) : (
                      <step.icon className="w-6 h-6" />
                    )}
                  </div>
                  <span className={`text-xs mt-2 font-semibold ${
                    currentStep >= step.number ? 'text-blue-600' : 'text-gray-400'
                  }`}>
                    {step.title}
                  </span>
                </div>
                {index < steps.length - 1 && (
                  <div className={`h-1 flex-1 mx-2 rounded transition-all ${
                    currentStep > step.number ? 'bg-gradient-to-r from-blue-600 to-purple-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 border-2 border-blue-100">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border-2 border-red-200 rounded-xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <span className="text-red-700">{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-6 p-4 bg-green-50 border-2 border-green-200 rounded-xl flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
              <span className="text-green-700">Audio equipment listed successfully! Redirecting...</span>
            </div>
          )}

          <form onSubmit={handleSubmit}>
            {currentStep === 1 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Music className="w-6 h-6 text-blue-600" />
                  Category & Basic Details
                </h2>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Audio Equipment Category *
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                    {AUDIO_CATEGORIES.map((cat) => {
                      const Icon = cat.icon;
                      return (
                        <button
                          key={cat.value}
                          type="button"
                          onClick={() => setFormData({...formData, category: cat.value, subcategory: ''})}
                          className={`p-4 rounded-xl border-2 transition-all ${
                            formData.category === cat.value
                              ? 'bg-gradient-to-br from-blue-600 to-purple-600 text-white border-blue-500 shadow-lg'
                              : 'bg-white text-gray-700 border-blue-200 hover:border-blue-400'
                          }`}
                        >
                          <Icon className="w-6 h-6 mx-auto mb-2" />
                          <span className="text-xs font-semibold text-center block">{cat.value}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {selectedCategory && (
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Subcategory *
                    </label>
                    <select
                      value={formData.subcategory}
                      onChange={(e) => setFormData({...formData, subcategory: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                    >
                      <option value="">Select subcategory</option>
                      {selectedCategory.subcategories.map(sub => (
                        <option key={sub} value={sub}>{sub}</option>
                      ))}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Product Title *
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    required
                    className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                    placeholder="e.g., Shure SM58 Dynamic Microphone"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Description *
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    required
                    rows={4}
                    className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                    placeholder="Describe the audio equipment, its features, condition, usage..."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Brand *
                    </label>
                    <select
                      value={formData.brand}
                      onChange={(e) => setFormData({...formData, brand: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                    >
                      <option value="">Select brand</option>
                      {BRANDS.map(brand => (
                        <option key={brand} value={brand}>{brand}</option>
                      ))}
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Model Number
                    </label>
                    <input
                      type="text"
                      value={formData.model}
                      onChange={(e) => setFormData({...formData, model: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., SM58-LC"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Condition *
                    </label>
                    <select
                      value={formData.condition}
                      onChange={(e) => setFormData({...formData, condition: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                    >
                      {CONDITIONS.map(cond => (
                        <option key={cond} value={cond}>{cond}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Year of Manufacture
                    </label>
                    <input
                      type="number"
                      value={formData.year_manufactured}
                      onChange={(e) => setFormData({...formData, year_manufactured: e.target.value})}
                      min="1950"
                      max={new Date().getFullYear()}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="2024"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Price (NGN) *
                    </label>
                    <input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({...formData, price: e.target.value})}
                      required
                      min="0"
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="0"
                    />
                  </div>

                  <div className="flex items-center">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.negotiable}
                        onChange={(e) => setFormData({...formData, negotiable: e.target.checked})}
                        className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm font-semibold text-gray-700">Price Negotiable</span>
                    </label>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      City *
                    </label>
                    <input
                      type="text"
                      value={formData.location_city}
                      onChange={(e) => setFormData({...formData, location_city: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., Lagos"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      State *
                    </label>
                    <input
                      type="text"
                      value={formData.location_state}
                      onChange={(e) => setFormData({...formData, location_state: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., Lagos"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                  >
                    Next: Technical Specs
                  </button>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Settings className="w-6 h-6 text-blue-600" />
                  Technical Specifications
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Power Type
                    </label>
                    <select
                      value={formData.power}
                      onChange={(e) => setFormData({...formData, power: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                    >
                      <option value="">Select power type</option>
                      {POWER_TYPES.map(power => (
                        <option key={power} value={power}>{power}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Power Output (Watts)
                    </label>
                    <input
                      type="text"
                      value={formData.watts}
                      onChange={(e) => setFormData({...formData, watts: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 100W RMS"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Impedance
                    </label>
                    <input
                      type="text"
                      value={formData.impedance}
                      onChange={(e) => setFormData({...formData, impedance: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 8 Ohms, 32 Ohms"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Frequency Response
                    </label>
                    <input
                      type="text"
                      value={formData.frequency_response}
                      onChange={(e) => setFormData({...formData, frequency_response: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 20Hz - 20kHz"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Sensitivity (dB)
                    </label>
                    <input
                      type="text"
                      value={formData.sensitivity}
                      onChange={(e) => setFormData({...formData, sensitivity: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 95dB"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Max SPL
                    </label>
                    <input
                      type="text"
                      value={formData.spl_max}
                      onChange={(e) => setFormData({...formData, spl_max: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 128dB SPL"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Number of Channels
                    </label>
                    <input
                      type="text"
                      value={formData.channels}
                      onChange={(e) => setFormData({...formData, channels: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 2, 4, 8, 16"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Sample Rate
                    </label>
                    <input
                      type="text"
                      value={formData.sample_rate}
                      onChange={(e) => setFormData({...formData, sample_rate: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 44.1kHz, 48kHz, 96kHz"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Bit Depth
                    </label>
                    <input
                      type="text"
                      value={formData.bit_depth}
                      onChange={(e) => setFormData({...formData, bit_depth: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 16-bit, 24-bit"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      THD (Total Harmonic Distortion)
                    </label>
                    <input
                      type="text"
                      value={formData.thd}
                      onChange={(e) => setFormData({...formData, thd: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., <0.1%"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Signal-to-Noise Ratio
                    </label>
                    <input
                      type="text"
                      value={formData.signal_to_noise}
                      onChange={(e) => setFormData({...formData, signal_to_noise: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., >100dB"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Driver Size
                    </label>
                    <input
                      type="text"
                      value={formData.driver_size}
                      onChange={(e) => setFormData({...formData, driver_size: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 1 inch, 15 inch, 40mm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Bluetooth Version
                    </label>
                    <input
                      type="text"
                      value={formData.bluetooth_version}
                      onChange={(e) => setFormData({...formData, bluetooth_version: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 5.0, 5.3"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Battery Life
                    </label>
                    <input
                      type="text"
                      value={formData.battery_life}
                      onChange={(e) => setFormData({...formData, battery_life: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 10 hours"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Weight
                    </label>
                    <input
                      type="text"
                      value={formData.weight}
                      onChange={(e) => setFormData({...formData, weight: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 2.5kg"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Dimensions (L x W x H)
                    </label>
                    <input
                      type="text"
                      value={formData.dimensions}
                      onChange={(e) => setFormData({...formData, dimensions: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 30 x 20 x 15 cm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Rack Units (U)
                    </label>
                    <input
                      type="text"
                      value={formData.rack_units}
                      onChange={(e) => setFormData({...formData, rack_units: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., 1U, 2U, 4U"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Color
                    </label>
                    <input
                      type="text"
                      value={formData.color}
                      onChange={(e) => setFormData({...formData, color: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                      placeholder="e.g., Black, Silver, Wood"
                    />
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(1)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(3)}
                    className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                  >
                    Next: Features & Connectivity
                  </button>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Zap className="w-6 h-6 text-blue-600" />
                  Features & Connectivity
                </h2>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Connectivity Options
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                    {CONNECTIVITY.map(conn => (
                      <button
                        key={conn}
                        type="button"
                        onClick={() => handleConnectivityToggle(conn)}
                        className={`px-3 py-2 rounded-lg border-2 font-semibold text-sm transition-colors ${
                          connectivity.includes(conn)
                            ? 'bg-gradient-to-br from-blue-600 to-purple-600 text-white border-blue-500'
                            : 'bg-white text-gray-700 border-blue-200 hover:border-blue-400'
                        }`}
                      >
                        {conn}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Additional Features
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {FEATURES_LIST.map(feature => (
                      <button
                        key={feature}
                        type="button"
                        onClick={() => handleFeatureToggle(feature)}
                        className={`px-3 py-2 rounded-lg border-2 font-semibold text-sm transition-colors ${
                          additionalFeatures.includes(feature)
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-white text-gray-700 border-blue-200 hover:border-blue-400'
                        }`}
                      >
                        {feature}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Accessories Included
                  </label>
                  <textarea
                    value={formData.accessories_included}
                    onChange={(e) => setFormData({...formData, accessories_included: e.target.value})}
                    rows={3}
                    className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                    placeholder="List all included accessories (cables, cases, adapters, manuals, etc.)"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Warranty Available?
                    </label>
                    <select
                      value={formData.warranty}
                      onChange={(e) => setFormData({...formData, warranty: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                    >
                      <option value="">No Warranty</option>
                      <option value="Manufacturer Warranty">Manufacturer Warranty</option>
                      <option value="Store Warranty">Store Warranty</option>
                      <option value="Extended Warranty">Extended Warranty</option>
                    </select>
                  </div>

                  {formData.warranty && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Warranty Period
                      </label>
                      <input
                        type="text"
                        value={formData.warranty_period}
                        onChange={(e) => setFormData({...formData, warranty_period: e.target.value})}
                        className="w-full px-4 py-3 border-2 border-blue-200 rounded-xl focus:border-blue-500 focus:outline-none"
                        placeholder="e.g., 1 year, 6 months"
                      />
                    </div>
                  )}
                </div>

                <div className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200 rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Package className="w-5 h-5 text-blue-600" />
                    Item Condition & Accessories
                  </h3>

                  <div className="space-y-4">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.original_packaging}
                        onChange={(e) => setFormData({...formData, original_packaging: e.target.checked})}
                        className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="font-semibold text-gray-900">Comes with Original Packaging</span>
                    </label>

                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.manual_included}
                        onChange={(e) => setFormData({...formData, manual_included: e.target.checked})}
                        className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="font-semibold text-gray-900">User Manual Included</span>
                    </label>

                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.tested_working}
                        onChange={(e) => setFormData({...formData, tested_working: e.target.checked})}
                        className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="font-semibold text-gray-900">Tested & Working Perfectly</span>
                    </label>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-green-50 to-blue-50 border-2 border-green-200 rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <ShoppingBag className="w-5 h-5 text-green-600" />
                    Shipping & Delivery
                  </h3>

                  <div className="space-y-4">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.shipping_available}
                        onChange={(e) => setFormData({...formData, shipping_available: e.target.checked})}
                        className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500 mt-0.5"
                      />
                      <div className="flex-1">
                        <span className="font-semibold text-gray-900">Nationwide Shipping Available</span>
                        {formData.shipping_available && (
                          <input
                            type="number"
                            value={formData.shipping_fee}
                            onChange={(e) => setFormData({...formData, shipping_fee: e.target.value})}
                            min="0"
                            className="w-full mt-2 px-4 py-2 border-2 border-blue-200 rounded-lg focus:border-blue-500 focus:outline-none"
                            placeholder="Shipping fee (NGN)"
                          />
                        )}
                      </div>
                    </label>

                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.international_shipping}
                        onChange={(e) => setFormData({...formData, international_shipping: e.target.checked})}
                        className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="font-semibold text-gray-900">International Shipping Available</span>
                    </label>
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(4)}
                    className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                  >
                    Next: Images
                  </button>
                </div>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-blue-600" />
                  Product Images
                </h2>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Upload Images (Max 10) *
                  </label>
                  <p className="text-sm text-gray-600 mb-4">
                    Show your audio equipment from multiple angles, include close-ups of controls and connections
                  </p>
                  <div className="border-2 border-dashed border-blue-300 rounded-2xl p-8 text-center hover:border-blue-500 transition-colors bg-blue-50/30">
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleImageSelect}
                      className="hidden"
                      id="image-upload"
                    />
                    <label htmlFor="image-upload" className="cursor-pointer">
                      <Upload className="w-16 h-16 text-blue-400 mx-auto mb-3" />
                      <span className="text-gray-700 font-semibold block mb-1">Click to upload product images</span>
                      <span className="text-sm text-gray-500">PNG, JPG up to 10 images</span>
                    </label>
                  </div>

                  {previews.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
                      {previews.map((preview, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={preview}
                            alt={`Preview ${index + 1}`}
                            className="w-full h-32 object-cover rounded-xl border-2 border-blue-200"
                          />
                          <button
                            type="button"
                            onClick={() => removeImage(index)}
                            className="absolute -top-2 -right-2 p-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200 rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Play className="w-5 h-5 text-blue-600" />
                    Listing Summary
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Category:</span>
                      <span className="font-semibold text-gray-900">{formData.category || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Subcategory:</span>
                      <span className="font-semibold text-gray-900">{formData.subcategory || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Brand:</span>
                      <span className="font-semibold text-gray-900">{formData.brand || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Price:</span>
                      <span className="font-semibold text-gray-900">
                        {formData.price ? `NGN ${parseFloat(formData.price).toLocaleString()}` : 'Not set'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Connectivity:</span>
                      <span className="font-semibold text-gray-900">{connectivity.length} options</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Features:</span>
                      <span className="font-semibold text-gray-900">{additionalFeatures.length} selected</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Images:</span>
                      <span className="font-semibold text-gray-900">{images.length} uploaded</span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(3)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={uploading || images.length === 0}
                    className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-bold hover:shadow-2xl disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
                  >
                    {uploading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        Publish Listing
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
};
