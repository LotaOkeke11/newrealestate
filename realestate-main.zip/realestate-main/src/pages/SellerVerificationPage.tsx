import { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  ShieldCheck,
  Upload,
  CheckCircle2,
  AlertCircle,
  Camera,
  Building2,
  FileText,
  MapPin,
  Award,
  Clock,
  XCircle,
} from 'lucide-react';

type VerificationData = {
  id?: string;
  user_id: string;
  verification_level: number;
  national_id_url: string | null;
  selfie_url: string | null;
  utility_bill_url: string | null;
  cac_number: string | null;
  cac_certificate_url: string | null;
  business_name: string | null;
  business_logo_url: string | null;
  office_location: string | null;
  office_photo_url: string | null;
  status: 'pending' | 'approved' | 'rejected';
};

export const SellerVerificationPage = () => {
  const { user, profile } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentLevel, setCurrentLevel] = useState(0);
  const [existingVerification, setExistingVerification] = useState<VerificationData | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const [uploading, setUploading] = useState<string | null>(null);

  const [level1Data, setLevel1Data] = useState({
    nationalIdUrl: '',
    selfieUrl: '',
  });

  const [level2Data, setLevel2Data] = useState({
    utilityBillUrl: '',
  });

  const [level3Data, setLevel3Data] = useState({
    cacNumber: '',
    cacCertificateUrl: '',
    businessName: '',
    businessLogoUrl: '',
    officeLocation: '',
    officePhotoUrl: '',
  });

  useEffect(() => {
    if (user) {
      loadVerificationStatus();
    }
  }, [user]);

  const loadVerificationStatus = async () => {
    if (!user) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('seller_verifications')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();

    if (data) {
      setExistingVerification(data);
      setCurrentLevel(data.verification_level);

      setLevel1Data({
        nationalIdUrl: data.national_id_url || '',
        selfieUrl: data.selfie_url || '',
      });

      setLevel2Data({
        utilityBillUrl: data.utility_bill_url || '',
      });

      setLevel3Data({
        cacNumber: data.cac_number || '',
        cacCertificateUrl: data.cac_certificate_url || '',
        businessName: data.business_name || '',
        businessLogoUrl: data.business_logo_url || '',
        officeLocation: data.office_location || '',
        officePhotoUrl: data.office_photo_url || '',
      });
    }
    setLoading(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(field);
    setError('');

    try {
      const maxSize = 10 * 1024 * 1024;
      if (file.size > maxSize) {
        throw new Error('File size must be less than 10MB');
      }

      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'application/pdf'];
      if (!allowedTypes.includes(file.type)) {
        throw new Error('Only JPG, PNG, WEBP, and PDF files are allowed');
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `${user?.id}/${field}-${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('verification-media')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        throw uploadError;
      }

      const { data: urlData } = supabase.storage
        .from('verification-media')
        .getPublicUrl(fileName);

      setUploading(null);
      return urlData.publicUrl;
    } catch (err: any) {
      setError(err.message || 'Failed to upload file');
      setUploading(null);
      return null;
    }
  };

  const submitVerification = async (level: number) => {
    if (!user) return;

    setSubmitting(true);
    setError('');

    try {
      let verificationData: Partial<VerificationData> = {
        user_id: user.id,
        verification_level: level,
        status: 'pending',
      };

      if (level >= 1) {
        if (!level1Data.nationalIdUrl || !level1Data.selfieUrl) {
          throw new Error('Please upload all required documents for Level 1');
        }
        verificationData.national_id_url = level1Data.nationalIdUrl;
        verificationData.selfie_url = level1Data.selfieUrl;
      }

      if (level >= 2) {
        if (!level2Data.utilityBillUrl) {
          throw new Error('Please upload utility bill for Level 2');
        }
        verificationData.utility_bill_url = level2Data.utilityBillUrl;
      }

      if (level >= 3) {
        if (!level3Data.cacNumber || !level3Data.cacCertificateUrl || !level3Data.businessName || !level3Data.officeLocation) {
          throw new Error('Please complete all required fields for Level 3');
        }
        verificationData.cac_number = level3Data.cacNumber;
        verificationData.cac_certificate_url = level3Data.cacCertificateUrl;
        verificationData.business_name = level3Data.businessName;
        verificationData.business_logo_url = level3Data.businessLogoUrl;
        verificationData.office_location = level3Data.officeLocation;
        verificationData.office_photo_url = level3Data.officePhotoUrl;
      }

      if (existingVerification) {
        const { error: updateError } = await supabase
          .from('seller_verifications')
          .update(verificationData)
          .eq('id', existingVerification.id);

        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase
          .from('seller_verifications')
          .insert([verificationData]);

        if (insertError) throw insertError;
      }

      setSuccess(true);
      setTimeout(() => {
        loadVerificationStatus();
        setSuccess(false);
      }, 3000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const verificationLevels = [
    {
      level: 1,
      name: 'Basic Verification',
      badge: '🆔',
      color: 'from-blue-500 to-cyan-500',
      benefits: ['Verified badge on profile', 'Increased buyer trust', 'Access to basic seller tools'],
      requirements: ['Government-issued ID', 'Selfie for identity verification'],
    },
    {
      level: 2,
      name: 'Address Verified',
      badge: '🏠',
      color: 'from-green-500 to-emerald-500',
      benefits: ['Address verified badge', 'Higher listing priority', 'Unlock premium categories', 'Reduced buyer disputes'],
      requirements: ['All Level 1 requirements', 'Utility bill or bank statement'],
    },
    {
      level: 3,
      name: 'Business Verified',
      badge: '🏢',
      color: 'from-amber-500 to-orange-500',
      benefits: ['Business verified badge', 'Priority customer support', 'Featured seller status', 'API access', 'Bulk listing tools'],
      requirements: ['All Level 1 & 2 requirements', 'CAC registration certificate', 'Business name', 'Office address', 'Office photo'],
    },
  ];

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex items-center justify-center min-h-[60vh] px-4">
          <div className="text-center bg-white rounded-3xl shadow-2xl p-12 max-w-md">
            <ShieldCheck className="w-20 h-20 text-amber-500 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Sign In Required</h2>
            <p className="text-gray-600 mb-8 text-lg">Please sign in to access verification</p>
            <a href="/login" className="block w-full px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-bold hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg">
              Sign In
            </a>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="animate-spin w-16 h-16 border-4 border-amber-600 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-gray-600">Loading verification status...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-xl">
              <ShieldCheck className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">Seller Verification</h1>
              <p className="text-gray-600 text-lg">Build trust and unlock premium features</p>
            </div>
          </div>
        </div>

        {success && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-green-800">Verification Submitted!</p>
              <p className="text-sm text-green-700">Your documents are under review. We'll notify you within 24-48 hours.</p>
            </div>
          </div>
        )}

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
            <span className="text-sm text-red-700">{error}</span>
          </div>
        )}

        {existingVerification && (
          <div className={`mb-8 p-6 rounded-2xl border-2 ${
            existingVerification.status === 'approved' ? 'bg-green-50 border-green-300' :
            existingVerification.status === 'rejected' ? 'bg-red-50 border-red-300' :
            'bg-yellow-50 border-yellow-300'
          }`}>
            <div className="flex items-start gap-4">
              {existingVerification.status === 'approved' && <CheckCircle2 className="w-8 h-8 text-green-600" />}
              {existingVerification.status === 'rejected' && <XCircle className="w-8 h-8 text-red-600" />}
              {existingVerification.status === 'pending' && <Clock className="w-8 h-8 text-yellow-600" />}

              <div className="flex-1">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {existingVerification.status === 'approved' && `Level ${existingVerification.verification_level} Verification Approved`}
                  {existingVerification.status === 'rejected' && 'Verification Rejected'}
                  {existingVerification.status === 'pending' && 'Verification Under Review'}
                </h3>
                <p className="text-gray-700">
                  {existingVerification.status === 'approved' && 'Your seller account has been verified. You can now access premium features.'}
                  {existingVerification.status === 'rejected' && 'Please review your documents and resubmit with correct information.'}
                  {existingVerification.status === 'pending' && 'Our team is reviewing your documents. This usually takes 24-48 hours.'}
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {verificationLevels.map((level) => (
            <div
              key={level.level}
              className={`relative bg-white rounded-2xl shadow-xl p-6 border-2 ${
                currentLevel >= level.level && existingVerification?.status === 'approved'
                  ? 'border-green-400'
                  : 'border-amber-200'
              }`}
            >
              {currentLevel >= level.level && existingVerification?.status === 'approved' && (
                <div className="absolute -top-3 -right-3 w-10 h-10 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
              )}

              <div className={`w-16 h-16 bg-gradient-to-br ${level.color} rounded-2xl flex items-center justify-center text-3xl mb-4`}>
                {level.badge}
              </div>

              <h3 className="text-xl font-bold text-gray-900 mb-2">{level.name}</h3>
              <p className="text-sm text-gray-600 mb-4">Level {level.level}</p>

              <div className="mb-4">
                <h4 className="font-semibold text-gray-900 mb-2 text-sm">Benefits:</h4>
                <ul className="space-y-1">
                  {level.benefits.map((benefit, idx) => (
                    <li key={idx} className="text-xs text-gray-700 flex items-start gap-2">
                      <CheckCircle2 className="w-3 h-3 text-green-500 flex-shrink-0 mt-0.5" />
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-gray-900 mb-2 text-sm">Requirements:</h4>
                <ul className="space-y-1">
                  {level.requirements.map((req, idx) => (
                    <li key={idx} className="text-xs text-gray-600 flex items-start gap-2">
                      <span className="text-amber-500">•</span>
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Verification Forms</h2>

          <div className="space-y-8">
            <div className="border-2 border-amber-200 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center text-white font-bold">
                  1
                </div>
                <h3 className="text-xl font-bold text-gray-900">Level 1: Basic Verification</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Government-Issued ID *
                  </label>
                  <div className="border-2 border-dashed border-amber-300 rounded-xl p-6 text-center hover:border-amber-400 transition-colors cursor-pointer">
                    <Upload className="w-8 h-8 text-amber-600 mx-auto mb-2" />
                    <p className="text-sm text-gray-600 mb-2">Upload ID Card, Driver's License, or Passport</p>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={async (e) => {
                        const url = await handleFileUpload(e, 'national_id');
                        if (url) setLevel1Data({ ...level1Data, nationalIdUrl: url });
                      }}
                      className="hidden"
                      id="national-id-upload"
                      disabled={uploading === 'national_id'}
                    />
                    <label htmlFor="national-id-upload" className={`px-4 py-2 bg-amber-600 text-white rounded-lg text-sm cursor-pointer hover:bg-amber-700 ${uploading === 'national_id' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                      {uploading === 'national_id' ? 'Uploading...' : 'Choose File'}
                    </label>
                    {level1Data.nationalIdUrl && (
                      <p className="text-xs text-green-600 mt-2 font-semibold">✓ Government ID Uploaded Successfully</p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Selfie with ID *
                  </label>
                  <div className="border-2 border-dashed border-amber-300 rounded-xl p-6 text-center hover:border-amber-400 transition-colors cursor-pointer">
                    <Camera className="w-8 h-8 text-amber-600 mx-auto mb-2" />
                    <p className="text-sm text-gray-600 mb-2">Take or upload a selfie holding your ID</p>
                    <input
                      type="file"
                      accept="image/*"
                      capture="user"
                      onChange={async (e) => {
                        const url = await handleFileUpload(e, 'selfie');
                        if (url) setLevel1Data({ ...level1Data, selfieUrl: url });
                      }}
                      className="hidden"
                      id="selfie-upload"
                      disabled={uploading === 'selfie'}
                    />
                    <label htmlFor="selfie-upload" className={`px-4 py-2 bg-amber-600 text-white rounded-lg text-sm cursor-pointer hover:bg-amber-700 ${uploading === 'selfie' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                      {uploading === 'selfie' ? 'Uploading...' : 'Take/Upload Selfie'}
                    </label>
                    {level1Data.selfieUrl && (
                      <p className="text-xs text-green-600 mt-2 font-semibold">✓ Selfie Uploaded Successfully</p>
                    )}
                  </div>
                </div>
              </div>

              <button
                onClick={() => submitVerification(1)}
                disabled={submitting || !level1Data.nationalIdUrl || !level1Data.selfieUrl}
                className="mt-6 w-full py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-xl font-bold hover:from-blue-600 hover:to-cyan-600 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting ? 'Submitting...' : 'Submit Level 1 Verification'}
              </button>
            </div>

            <div className="border-2 border-amber-200 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg flex items-center justify-center text-white font-bold">
                  2
                </div>
                <h3 className="text-xl font-bold text-gray-900">Level 2: Address Verification</h3>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Utility Bill or Bank Statement *
                </label>
                <div className="border-2 border-dashed border-amber-300 rounded-xl p-6 text-center hover:border-amber-400 transition-colors cursor-pointer">
                  <FileText className="w-8 h-8 text-amber-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-600 mb-2">Upload recent utility bill, bank statement, or rental agreement</p>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={async (e) => {
                      const url = await handleFileUpload(e, 'utility_bill');
                      if (url) setLevel2Data({ utilityBillUrl: url });
                    }}
                    className="hidden"
                    id="utility-bill-upload"
                    disabled={uploading === 'utility_bill'}
                  />
                  <label htmlFor="utility-bill-upload" className={`px-4 py-2 bg-amber-600 text-white rounded-lg text-sm cursor-pointer hover:bg-amber-700 ${uploading === 'utility_bill' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                    {uploading === 'utility_bill' ? 'Uploading...' : 'Choose File'}
                  </label>
                  {level2Data.utilityBillUrl && (
                    <p className="text-xs text-green-600 mt-2 font-semibold">✓ Utility Bill/Bank Statement Uploaded</p>
                  )}
                </div>
              </div>

              <button
                onClick={() => submitVerification(2)}
                disabled={submitting || !level2Data.utilityBillUrl || currentLevel < 1}
                className="mt-6 w-full py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-bold hover:from-green-600 hover:to-emerald-600 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting ? 'Submitting...' : 'Submit Level 2 Verification'}
              </button>
            </div>

            <div className="border-2 border-amber-200 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-amber-500 to-orange-500 rounded-lg flex items-center justify-center text-white font-bold">
                  3
                </div>
                <h3 className="text-xl font-bold text-gray-900">Level 3: Business Verification</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    CAC Registration Number *
                  </label>
                  <input
                    type="text"
                    value={level3Data.cacNumber}
                    onChange={(e) => setLevel3Data({ ...level3Data, cacNumber: e.target.value })}
                    placeholder="BN1234567 or RC1234567"
                    className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Business Name *
                  </label>
                  <input
                    type="text"
                    value={level3Data.businessName}
                    onChange={(e) => setLevel3Data({ ...level3Data, businessName: e.target.value })}
                    placeholder="Your Business Name"
                    className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    CAC Certificate *
                  </label>
                  <div className="border-2 border-dashed border-amber-300 rounded-xl p-4 text-center hover:border-amber-400 transition-colors cursor-pointer">
                    <Building2 className="w-6 h-6 text-amber-600 mx-auto mb-1" />
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={async (e) => {
                        const url = await handleFileUpload(e, 'cac_certificate');
                        if (url) setLevel3Data({ ...level3Data, cacCertificateUrl: url });
                      }}
                      className="hidden"
                      id="cac-certificate-upload"
                      disabled={uploading === 'cac_certificate'}
                    />
                    <label htmlFor="cac-certificate-upload" className={`px-3 py-2 bg-amber-600 text-white rounded-lg text-xs cursor-pointer hover:bg-amber-700 ${uploading === 'cac_certificate' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                      {uploading === 'cac_certificate' ? 'Uploading...' : 'Upload'}
                    </label>
                    {level3Data.cacCertificateUrl && (
                      <p className="text-xs text-green-600 mt-1 font-semibold">✓ CAC Certificate Uploaded</p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Business Logo (Optional)
                  </label>
                  <div className="border-2 border-dashed border-amber-300 rounded-xl p-4 text-center hover:border-amber-400 transition-colors cursor-pointer">
                    <Award className="w-6 h-6 text-amber-600 mx-auto mb-1" />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={async (e) => {
                        const url = await handleFileUpload(e, 'business_logo');
                        if (url) setLevel3Data({ ...level3Data, businessLogoUrl: url });
                      }}
                      className="hidden"
                      id="business-logo-upload"
                      disabled={uploading === 'business_logo'}
                    />
                    <label htmlFor="business-logo-upload" className={`px-3 py-2 bg-amber-600 text-white rounded-lg text-xs cursor-pointer hover:bg-amber-700 ${uploading === 'business_logo' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                      {uploading === 'business_logo' ? 'Uploading...' : 'Upload'}
                    </label>
                    {level3Data.businessLogoUrl && (
                      <p className="text-xs text-green-600 mt-1 font-semibold">✓ Business Logo Uploaded</p>
                    )}
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Office Address *
                  </label>
                  <input
                    type="text"
                    value={level3Data.officeLocation}
                    onChange={(e) => setLevel3Data({ ...level3Data, officeLocation: e.target.value })}
                    placeholder="Full office address"
                    className="w-full px-4 py-3 border-2 border-amber-200 rounded-xl focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Office Photo *
                  </label>
                  <div className="border-2 border-dashed border-amber-300 rounded-xl p-6 text-center hover:border-amber-400 transition-colors cursor-pointer">
                    <MapPin className="w-8 h-8 text-amber-600 mx-auto mb-2" />
                    <p className="text-sm text-gray-600 mb-2">Upload photo of your office/shop front</p>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={async (e) => {
                        const url = await handleFileUpload(e, 'office_photo');
                        if (url) setLevel3Data({ ...level3Data, officePhotoUrl: url });
                      }}
                      className="hidden"
                      id="office-photo-upload"
                      disabled={uploading === 'office_photo'}
                    />
                    <label htmlFor="office-photo-upload" className={`px-4 py-2 bg-amber-600 text-white rounded-lg text-sm cursor-pointer hover:bg-amber-700 ${uploading === 'office_photo' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                      {uploading === 'office_photo' ? 'Uploading...' : 'Choose File'}
                    </label>
                    {level3Data.officePhotoUrl && (
                      <p className="text-xs text-green-600 mt-2 font-semibold">✓ Office Photo Uploaded Successfully</p>
                    )}
                  </div>
                </div>
              </div>

              <button
                onClick={() => submitVerification(3)}
                disabled={
                  submitting ||
                  !level3Data.cacNumber ||
                  !level3Data.cacCertificateUrl ||
                  !level3Data.businessName ||
                  !level3Data.officeLocation ||
                  !level3Data.officePhotoUrl ||
                  currentLevel < 2
                }
                className="mt-6 w-full py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-xl font-bold hover:from-amber-600 hover:to-orange-600 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting ? 'Submitting...' : 'Submit Level 3 Verification'}
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 bg-blue-50 border-2 border-blue-200 rounded-2xl p-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-blue-900 mb-2">Important Information</h3>
              <ul className="space-y-2 text-sm text-blue-800">
                <li>• All documents must be clear and readable</li>
                <li>• Government IDs must be valid and not expired</li>
                <li>• Selfie must clearly show your face and ID</li>
                <li>• Utility bills must be dated within the last 3 months</li>
                <li>• CAC certificates must match your business name</li>
                <li>• Verification typically takes 24-48 hours</li>
                <li>• You can upgrade to higher levels after approval</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
