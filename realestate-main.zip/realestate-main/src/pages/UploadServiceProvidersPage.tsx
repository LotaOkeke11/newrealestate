import { useState } from 'react';
import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Briefcase, X, CheckCircle2, AlertCircle, Image as ImageIcon, Check, Upload, Link as LinkIcon } from 'lucide-react';

export const UploadServiceProvidersPage = () => {
  const { user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    serviceCategory: '',
    serviceName: '',
    experienceYears: '',
    serviceType: '',
    specialization: '',
    availability: '',
    travelRadius: '',
    equipmentOwned: '',
    softwareSkills: '',
    portfolioUrl1: '',
    portfolioUrl2: '',
    portfolioUrl3: '',
    certifications: '',
    languages: '',
    teamSize: '',
    turnaroundTime: '',
    revisionPolicy: '',
    description: '',
    locationState: '',
    locationCity: '',
    hourlyRate: '',
    projectRate: '',
    packageRates: '',
    priceNegotiable: false,
    contactPhone: '',
    contactWhatsapp: '',
    contactEmail: '',
    services: {
      consultation: false,
      onSiteService: false,
      remoteService: false,
      emergencyService: false,
      weekendService: false
    }
  });

  const serviceCategories = [
    { value: 'photographers', label: 'Photography Services' },
    { value: 'videographers', label: 'Videography Services' },
    { value: 'performers', label: 'Entertainment/Performance' },
    { value: 'designers', label: 'Design Services' },
    { value: 'editors', label: 'Editing Services' },
    { value: 'cleaning-services', label: 'Cleaning Services' }
  ];

  const photographyTypes = ['Wedding', 'Portrait', 'Event', 'Product', 'Real Estate', 'Corporate', 'Fashion', 'Sports', 'Wildlife', 'Food'];
  const videographyTypes = ['Wedding Films', 'Corporate Videos', 'Music Videos', 'Documentaries', 'Commercials', 'Real Estate Tours', 'Event Coverage'];
  const performanceTypes = ['Musician', 'DJ', 'MC/Host', 'Comedian', 'Dancer', 'Magician', 'Band', 'Solo Artist'];
  const designTypes = ['Graphic Design', 'Web Design', 'UI/UX Design', 'Logo Design', 'Brand Identity', 'Social Media Graphics', 'Print Design'];
  const cleaningTypes = ['Residential', 'Commercial', 'Deep Cleaning', 'Move-in/out', 'Carpet Cleaning', 'Window Cleaning', 'Post-Construction'];

  const nigeriaStates = ['Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo', 'Kaduna', 'Anambra', 'Enugu', 'Delta', 'Edo', 'Ogun', 'Plateau', 'Osun', 'Ondo'];

  const getServiceTypes = () => {
    switch(formData.serviceCategory) {
      case 'photographers': return photographyTypes;
      case 'videographers': return videographyTypes;
      case 'performers': return performanceTypes;
      case 'designers': return designTypes;
      case 'cleaning-services': return cleaningTypes;
      default: return [];
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + imageFiles.length > 10) { setError('Maximum 10 portfolio images'); return; }
    setImageFiles((prev) => [...prev, ...files]);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreviews((prev) => [...prev, reader.result as string]);
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImageFiles((prev) => prev.filter((_, i) => i !== index));
    setImagePreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (!user) throw new Error('Please sign in');
      if (imageFiles.length < 2) throw new Error('Upload at least 2 portfolio images');

      const imageUrls: string[] = [];
      for (let i = 0; i < imageFiles.length; i++) {
        const file = imageFiles[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/service-${Date.now()}-${i}.${fileExt}`;
        const { error: uploadError } = await supabase.storage.from('listing-images').upload(fileName, file);
        if (!uploadError) {
          const { data: urlData } = supabase.storage.from('listing-images').getPublicUrl(fileName);
          imageUrls.push(urlData.publicUrl);
        }
      }

      const { data: category } = await supabase.from('categories').select('id, slug').eq('slug', formData.serviceCategory).maybeSingle();

      const portfolioUrls = [formData.portfolioUrl1, formData.portfolioUrl2, formData.portfolioUrl3].filter(url => url.trim() !== '');

      const listingData = {
        user_id: user.id,
        category_id: category?.id,
        title: formData.serviceName || `${formData.serviceType} - ${formData.specialization}`,
        description: formData.description,
        price: formData.hourlyRate ? parseFloat(formData.hourlyRate) : 0,
        currency: 'NGN',
        images: imageUrls,
        service_type: formData.serviceType,
        portfolio_urls: portfolioUrls,
        specifications: {
          experience_years: formData.experienceYears,
          specialization: formData.specialization,
          availability: formData.availability,
          travel_radius: formData.travelRadius,
          equipment_owned: formData.equipmentOwned,
          software_skills: formData.softwareSkills,
          certifications: formData.certifications,
          languages: formData.languages,
          team_size: formData.teamSize,
          turnaround_time: formData.turnaroundTime,
          revision_policy: formData.revisionPolicy,
          hourly_rate: formData.hourlyRate,
          project_rate: formData.projectRate,
          package_rates: formData.packageRates
        },
        features: formData.services,
        price_negotiable: formData.priceNegotiable,
        location_state: formData.locationState,
        location_city: formData.locationCity,
        contact_phone: formData.contactPhone,
        contact_whatsapp: formData.contactWhatsapp,
        status: 'active'
      };

      const { data: listing, error: listingError } = await supabase.from('listings').insert(listingData).select().single();
      if (listingError) throw listingError;
      setSuccess(true);
      setTimeout(() => {
        window.location.href = category?.slug ? `/category/${category.slug}` : '/';
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) { window.location.href = '/post-ad'; return null; }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50 flex flex-col">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuClick={() => setSidebarOpen(true)} />
      <main className="flex-1">
        <div className="bg-gradient-to-r from-teal-600 via-cyan-600 to-blue-600 text-white py-8 px-4 shadow-xl">
          <div className="max-w-5xl mx-auto">
            <a href="/post-ad" className="text-white/90 hover:text-white text-sm font-semibold mb-3 inline-block">← Back</a>
            <div className="flex items-center justify-between">
              <div><h1 className="text-4xl font-bold mb-2">Offer Your Services</h1><p className="text-white/95 text-lg">Showcase your expertise and connect with clients</p></div>
              <div className="hidden md:block w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center"><Briefcase className="w-10 h-10 text-white" /></div>
            </div>
          </div>
        </div>

        <div className="max-w-5xl mx-auto px-4 py-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {success && <div className="p-5 bg-green-50 border-2 border-green-200 rounded-xl flex items-start gap-3"><CheckCircle2 className="w-6 h-6 text-green-500" /><div><p className="font-bold text-green-800 text-lg">Success! Your service is now live</p></div></div>}
            {error && <div className="p-5 bg-red-50 border-2 border-red-200 rounded-xl flex items-start gap-3"><AlertCircle className="w-6 h-6 text-red-500" /><span className="text-sm text-red-700">{error}</span></div>}

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-teal-200">Service Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="md:col-span-2"><label className="block text-sm font-bold text-gray-700 mb-2">Service Category *</label>
                  <select value={formData.serviceCategory} onChange={(e) => setFormData({...formData, serviceCategory: e.target.value, serviceType: ''})} required className="w-full px-4 py-3 border rounded-lg focus:border-teal-500">
                    <option value="">Select service category</option>
                    {serviceCategories.map((cat) => <option key={cat.value} value={cat.value}>{cat.label}</option>)}
                  </select>
                </div>
                {formData.serviceCategory && (
                  <div><label className="block text-sm font-bold text-gray-700 mb-2">Service Type *</label>
                    <select value={formData.serviceType} onChange={(e) => setFormData({...formData, serviceType: e.target.value})} required className="w-full px-4 py-3 border rounded-lg focus:border-teal-500">
                      <option value="">Select type</option>
                      {getServiceTypes().map((type) => <option key={type} value={type}>{type}</option>)}
                    </select>
                  </div>
                )}
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Service Name/Title *</label>
                  <input type="text" value={formData.serviceName} onChange={(e) => setFormData({...formData, serviceName: e.target.value})} placeholder="e.g., Professional Wedding Photography" required className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Years of Experience</label>
                  <input type="number" value={formData.experienceYears} onChange={(e) => setFormData({...formData, experienceYears: e.target.value})} placeholder="5" min="0" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Specialization</label>
                  <input type="text" value={formData.specialization} onChange={(e) => setFormData({...formData, specialization: e.target.value})} placeholder="e.g., Outdoor weddings, Corporate branding" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-teal-200">Portfolio & Skills</h2>
              <div className="space-y-5">
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Portfolio Images *</label>
                  <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-teal-400 bg-gray-50">
                    <ImageIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-600 mb-2 font-semibold">Upload up to 10 portfolio images (Min 2)</p>
                    <input type="file" multiple accept="image/*" onChange={handleImageChange} className="hidden" id="image-upload" />
                    <label htmlFor="image-upload" className="px-6 py-3 bg-teal-600 text-white rounded-lg cursor-pointer hover:bg-teal-700 inline-block font-bold">Choose Images</label>
                  </div>
                  {imagePreviews.length > 0 && (
                    <div className="mt-5">
                      <p className="font-bold text-gray-900 mb-3">{imagePreviews.length} image(s)</p>
                      <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
                        {imagePreviews.map((preview, index) => (
                          <div key={index} className="relative aspect-square rounded-lg overflow-hidden border-2 border-gray-200 group">
                            <img src={preview} alt={`Portfolio ${index + 1}`} className="w-full h-full object-cover" />
                            <button type="button" onClick={() => removeImage(index)} className="absolute top-1 right-1 p-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 opacity-0 group-hover:opacity-100"><X className="w-3 h-3" /></button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 gap-4">
                  <div><label className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2"><LinkIcon className="w-4 h-4" />Portfolio Website/Link 1</label>
                    <input type="url" value={formData.portfolioUrl1} onChange={(e) => setFormData({...formData, portfolioUrl1: e.target.value})} placeholder="https://yourwebsite.com" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                  </div>
                  <div><label className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2"><LinkIcon className="w-4 h-4" />Portfolio Link 2 (Optional)</label>
                    <input type="url" value={formData.portfolioUrl2} onChange={(e) => setFormData({...formData, portfolioUrl2: e.target.value})} placeholder="https://instagram.com/yourprofile" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                  </div>
                  <div><label className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2"><LinkIcon className="w-4 h-4" />Portfolio Link 3 (Optional)</label>
                    <input type="url" value={formData.portfolioUrl3} onChange={(e) => setFormData({...formData, portfolioUrl3: e.target.value})} placeholder="https://behance.net/yourprofile" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                  </div>
                </div>

                <div><label className="block text-sm font-bold text-gray-700 mb-2">Equipment/Tools Owned</label>
                  <textarea value={formData.equipmentOwned} onChange={(e) => setFormData({...formData, equipmentOwned: e.target.value})} placeholder="List your equipment/tools..." rows={3} className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Software/Skills</label>
                  <input type="text" value={formData.softwareSkills} onChange={(e) => setFormData({...formData, softwareSkills: e.target.value})} placeholder="e.g., Adobe Photoshop, Lightroom, Premiere Pro" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-teal-200">Availability & Terms</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Availability</label>
                  <input type="text" value={formData.availability} onChange={(e) => setFormData({...formData, availability: e.target.value})} placeholder="e.g., Mon-Fri, Weekends" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Travel Radius</label>
                  <input type="text" value={formData.travelRadius} onChange={(e) => setFormData({...formData, travelRadius: e.target.value})} placeholder="e.g., Within Lagos, Nationwide" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Turnaround Time</label>
                  <input type="text" value={formData.turnaroundTime} onChange={(e) => setFormData({...formData, turnaroundTime: e.target.value})} placeholder="e.g., 7-10 days, 2 weeks" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">Revision Policy</label>
                  <input type="text" value={formData.revisionPolicy} onChange={(e) => setFormData({...formData, revisionPolicy: e.target.value})} placeholder="e.g., 2 free revisions" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-teal-200">Description</h2>
              <textarea value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} placeholder="Describe your services, past projects, what makes you unique..." rows={6} required className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-teal-200">Location</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div><label className="block text-sm font-bold text-gray-700 mb-2">State *</label>
                  <select value={formData.locationState} onChange={(e) => setFormData({...formData, locationState: e.target.value})} required className="w-full px-4 py-3 border rounded-lg focus:border-teal-500">
                    <option value="">Select</option>{nigeriaStates.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div><label className="block text-sm font-bold text-gray-700 mb-2">City/Area *</label>
                  <input type="text" value={formData.locationCity} onChange={(e) => setFormData({...formData, locationCity: e.target.value})} placeholder="Lekki" required className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-5 pb-3 border-b-2 border-teal-200">Pricing & Contact</h2>
              <div className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div><label className="block text-sm font-bold text-gray-700 mb-2">Hourly Rate (₦)</label>
                    <input type="number" value={formData.hourlyRate} onChange={(e) => setFormData({...formData, hourlyRate: e.target.value})} placeholder="10000" min="0" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                  </div>
                  <div><label className="block text-sm font-bold text-gray-700 mb-2">Project Rate (₦)</label>
                    <input type="number" value={formData.projectRate} onChange={(e) => setFormData({...formData, projectRate: e.target.value})} placeholder="50000" min="0" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                  </div>
                  <div><label className="block text-sm font-bold text-gray-700 mb-2">Package Rates</label>
                    <input type="text" value={formData.packageRates} onChange={(e) => setFormData({...formData, packageRates: e.target.value})} placeholder="Basic/Standard/Premium" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                  </div>
                </div>
                <label className="flex items-center gap-2 p-3 border rounded-lg cursor-pointer hover:border-teal-400">
                  <input type="checkbox" checked={formData.priceNegotiable} onChange={(e) => setFormData({...formData, priceNegotiable: e.target.checked})} className="w-4 h-4 text-teal-600 rounded" />
                  <span className="font-semibold text-gray-900">Rates negotiable</span>
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div><label className="block text-sm font-bold text-gray-700 mb-2">Phone *</label>
                    <input type="tel" value={formData.contactPhone} onChange={(e) => setFormData({...formData, contactPhone: e.target.value})} placeholder="+234" required className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                  </div>
                  <div><label className="block text-sm font-bold text-gray-700 mb-2">WhatsApp</label>
                    <input type="tel" value={formData.contactWhatsapp} onChange={(e) => setFormData({...formData, contactWhatsapp: e.target.value})} placeholder="+234" className="w-full px-4 py-3 border rounded-lg focus:border-teal-500" />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4">
              <a href="/post-ad" className="px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg font-bold hover:bg-gray-50">Cancel</a>
              <button type="submit" disabled={loading || imageFiles.length < 2} className="px-10 py-3 bg-gradient-to-r from-teal-600 to-cyan-600 text-white rounded-lg font-bold hover:from-teal-700 hover:to-cyan-700 disabled:opacity-50 shadow-lg flex items-center gap-2">
                {loading ? <><div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>Publishing...</> : <><Check className="w-5 h-5" />Publish</>}
              </button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
};
