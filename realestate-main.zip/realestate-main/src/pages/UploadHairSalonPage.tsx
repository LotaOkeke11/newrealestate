import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import {
  Scissors, Upload, X, AlertCircle, CheckCircle, Plus, Trash2,
  MapPin, Clock, Calendar, Star, Phone, Mail, Instagram, Facebook,
  DollarSign, Users, Award, Sparkles
} from 'lucide-react';

type ServiceItem = {
  name: string;
  description: string;
  duration: string;
  price: string;
  category: string;
};

type StaffMember = {
  name: string;
  role: string;
  specialty: string;
  experience: string;
};

const SERVICE_CATEGORIES = [
  'Haircuts & Styling',
  'Hair Color & Highlights',
  'Hair Treatments',
  'Braiding & Weaving',
  'Locs & Twists',
  'Hair Extensions',
  'Relaxer & Texturizer',
  'Bridal & Special Events',
  'Kids Hair Services',
  'Beard Grooming'
];

const WORKING_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const AMENITIES = [
  'Free WiFi',
  'Air Conditioning',
  'Complimentary Drinks',
  'Waiting Area',
  'Music/TV',
  'Private Rooms',
  'Wheelchair Accessible',
  'Parking Available',
  'Card Payment',
  'Online Booking'
];

export const UploadHairSalonPage = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    salon_name: '',
    tagline: '',
    description: '',
    address: '',
    location_city: '',
    location_state: '',
    landmark: '',
    contact_phone: '',
    contact_email: user?.email || '',
    whatsapp_number: '',
    instagram_handle: '',
    facebook_page: '',
    website: '',
    years_in_business: '',
    unisex: true,
    walk_ins_accepted: true,
    appointment_required: false,
    online_booking_available: false,
    booking_url: '',
    cancellation_policy: '',
    payment_methods: [] as string[],
  });

  const [workingHours, setWorkingHours] = useState<{[key: string]: {open: string, close: string, closed: boolean}}>({
    Monday: { open: '09:00', close: '18:00', closed: false },
    Tuesday: { open: '09:00', close: '18:00', closed: false },
    Wednesday: { open: '09:00', close: '18:00', closed: false },
    Thursday: { open: '09:00', close: '18:00', closed: false },
    Friday: { open: '09:00', close: '18:00', closed: false },
    Saturday: { open: '09:00', close: '18:00', closed: false },
    Sunday: { open: '', close: '', closed: true },
  });

  const [services, setServices] = useState<ServiceItem[]>([
    { name: '', description: '', duration: '30', price: '', category: 'Haircuts & Styling' }
  ]);

  const [staff, setStaff] = useState<StaffMember[]>([
    { name: '', role: 'Stylist', specialty: '', experience: '' }
  ]);

  const [amenities, setAmenities] = useState<string[]>([]);
  const [images, setImages] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);

  const handlePaymentMethodToggle = (method: string) => {
    if (formData.payment_methods.includes(method)) {
      setFormData({...formData, payment_methods: formData.payment_methods.filter(m => m !== method)});
    } else {
      setFormData({...formData, payment_methods: [...formData.payment_methods, method]});
    }
  };

  const handleAmenityToggle = (amenity: string) => {
    if (amenities.includes(amenity)) {
      setAmenities(amenities.filter(a => a !== amenity));
    } else {
      setAmenities([...amenities, amenity]);
    }
  };

  const addService = () => {
    setServices([...services, { name: '', description: '', duration: '30', price: '', category: 'Haircuts & Styling' }]);
  };

  const removeService = (index: number) => {
    setServices(services.filter((_, i) => i !== index));
  };

  const updateService = (index: number, field: keyof ServiceItem, value: string) => {
    const updated = [...services];
    updated[index][field] = value;
    setServices(updated);
  };

  const addStaff = () => {
    setStaff([...staff, { name: '', role: 'Stylist', specialty: '', experience: '' }]);
  };

  const removeStaff = (index: number) => {
    setStaff(staff.filter((_, i) => i !== index));
  };

  const updateStaff = (index: number, field: keyof StaffMember, value: string) => {
    const updated = [...staff];
    updated[index][field] = value;
    setStaff(updated);
  };

  const updateWorkingHours = (day: string, field: 'open' | 'close' | 'closed', value: string | boolean) => {
    setWorkingHours({
      ...workingHours,
      [day]: { ...workingHours[day], [field]: value }
    });
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (images.length + files.length > 10) {
      setError('Maximum 10 images allowed');
      return;
    }

    setImages([...images, ...files]);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviews(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
    setPreviews(previews.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setError('Please login to post a listing');
      return;
    }

    setUploading(true);
    setError('');

    try {
      const imageUrls: string[] = [];

      for (const image of images) {
        const fileExt = image.name.split('.').pop();
        const fileName = `${user.id}/${Date.now()}_${Math.random()}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from('listings')
          .upload(fileName, image);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('listings')
          .getPublicUrl(fileName);

        imageUrls.push(publicUrl);
      }

      const validServices = services.filter(s => s.name && s.price);
      const validStaff = staff.filter(s => s.name);

      const { error: insertError } = await supabase
        .from('listings')
        .insert({
          user_id: user.id,
          category_id: (await supabase.from('categories').select('id').eq('slug', 'hair-salon-services').single()).data?.id,
          title: formData.salon_name,
          description: formData.description,
          price: validServices.length > 0 ? parseFloat(validServices[0].price) : 0,
          currency: 'NGN',
          images: imageUrls,
          location_city: formData.location_city,
          location_state: formData.location_state,
          contact_phone: formData.contact_phone,
          contact_email: formData.contact_email,
          metadata: {
            salon_name: formData.salon_name,
            tagline: formData.tagline,
            address: formData.address,
            landmark: formData.landmark,
            whatsapp_number: formData.whatsapp_number,
            instagram_handle: formData.instagram_handle,
            facebook_page: formData.facebook_page,
            website: formData.website,
            years_in_business: formData.years_in_business,
            unisex: formData.unisex,
            walk_ins_accepted: formData.walk_ins_accepted,
            appointment_required: formData.appointment_required,
            online_booking_available: formData.online_booking_available,
            booking_url: formData.booking_url,
            cancellation_policy: formData.cancellation_policy,
            payment_methods: formData.payment_methods,
            working_hours: workingHours,
            services: validServices,
            staff: validStaff,
            amenities: amenities
          }
        });

      if (insertError) throw insertError;

      setSuccess(true);
      setTimeout(() => {
        window.location.href = '/';
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to create listing');
    } finally {
      setUploading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-pink-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-4">Login Required</h2>
          <p className="text-gray-600 mb-4">Please login to list your hair salon</p>
          <a href="/login" className="px-6 py-3 bg-pink-500 text-white rounded-lg hover:bg-pink-600">
            Login
          </a>
        </div>
      </div>
    );
  }

  const steps = [
    { number: 1, title: 'Basic Info', icon: Scissors },
    { number: 2, title: 'Services & Rates', icon: DollarSign },
    { number: 3, title: 'Staff & Hours', icon: Users },
    { number: 4, title: 'Gallery & Submit', icon: Sparkles }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50 flex flex-col">
      <Header />

      <main className="flex-1 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-pink-500 to-purple-600 rounded-2xl shadow-lg">
                <Scissors className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                  List Your Hair Salon
                </h1>
                <p className="text-gray-600">Unisex salon services, bookings & rate cards</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mb-8">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center flex-1">
                <div className="flex flex-col items-center flex-1">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold transition-all ${
                    currentStep >= step.number
                      ? 'bg-gradient-to-br from-pink-500 to-purple-600 text-white shadow-lg scale-110'
                      : 'bg-gray-200 text-gray-400'
                  }`}>
                    {currentStep > step.number ? (
                      <CheckCircle className="w-6 h-6" />
                    ) : (
                      <step.icon className="w-6 h-6" />
                    )}
                  </div>
                  <span className={`text-xs mt-2 font-semibold ${
                    currentStep >= step.number ? 'text-pink-600' : 'text-gray-400'
                  }`}>
                    {step.title}
                  </span>
                </div>
                {index < steps.length - 1 && (
                  <div className={`h-1 flex-1 mx-2 rounded transition-all ${
                    currentStep > step.number ? 'bg-gradient-to-r from-pink-500 to-purple-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 border-2 border-pink-100">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border-2 border-red-200 rounded-xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <span className="text-red-700">{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-6 p-4 bg-green-50 border-2 border-green-200 rounded-xl flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
              <span className="text-green-700">Salon listed successfully! Redirecting...</span>
            </div>
          )}

          <form onSubmit={handleSubmit}>
            {currentStep === 1 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Scissors className="w-6 h-6 text-pink-600" />
                  Basic Information
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Salon Name *
                    </label>
                    <input
                      type="text"
                      value={formData.salon_name}
                      onChange={(e) => setFormData({...formData, salon_name: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                      placeholder="e.g., Glam Hair Studio"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Tagline
                    </label>
                    <input
                      type="text"
                      value={formData.tagline}
                      onChange={(e) => setFormData({...formData, tagline: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                      placeholder="Your signature slogan"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      About Your Salon *
                    </label>
                    <textarea
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      required
                      rows={4}
                      className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                      placeholder="Describe your salon, expertise, unique offerings..."
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Full Address *
                    </label>
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) => setFormData({...formData, address: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                      placeholder="Street address"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      City *
                    </label>
                    <input
                      type="text"
                      value={formData.location_city}
                      onChange={(e) => setFormData({...formData, location_city: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                      placeholder="e.g., Lagos"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      State *
                    </label>
                    <input
                      type="text"
                      value={formData.location_state}
                      onChange={(e) => setFormData({...formData, location_state: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                      placeholder="e.g., Lagos"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Landmark
                    </label>
                    <input
                      type="text"
                      value={formData.landmark}
                      onChange={(e) => setFormData({...formData, landmark: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                      placeholder="Near..."
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Years in Business
                    </label>
                    <input
                      type="number"
                      value={formData.years_in_business}
                      onChange={(e) => setFormData({...formData, years_in_business: e.target.value})}
                      min="0"
                      className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                      placeholder="e.g., 5"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      value={formData.contact_phone}
                      onChange={(e) => setFormData({...formData, contact_phone: e.target.value})}
                      required
                      className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                      placeholder="+234..."
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      WhatsApp Number
                    </label>
                    <input
                      type="tel"
                      value={formData.whatsapp_number}
                      onChange={(e) => setFormData({...formData, whatsapp_number: e.target.value})}
                      className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                      placeholder="+234..."
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Instagram Handle
                    </label>
                    <div className="relative">
                      <Instagram className="absolute left-3 top-3 w-5 h-5 text-pink-500" />
                      <input
                        type="text"
                        value={formData.instagram_handle}
                        onChange={(e) => setFormData({...formData, instagram_handle: e.target.value})}
                        className="w-full pl-11 pr-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                        placeholder="@yoursalon"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Facebook Page
                    </label>
                    <div className="relative">
                      <Facebook className="absolute left-3 top-3 w-5 h-5 text-blue-600" />
                      <input
                        type="text"
                        value={formData.facebook_page}
                        onChange={(e) => setFormData({...formData, facebook_page: e.target.value})}
                        className="w-full pl-11 pr-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none transition-colors"
                        placeholder="facebook.com/yoursalon"
                      />
                    </div>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      Salon Type
                    </label>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.unisex}
                          onChange={(e) => setFormData({...formData, unisex: e.target.checked})}
                          className="w-5 h-5 text-pink-500 border-gray-300 rounded focus:ring-pink-500"
                        />
                        <span className="text-sm font-semibold text-gray-700">Unisex Salon</span>
                      </label>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="px-8 py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                  >
                    Next: Services & Rates
                  </button>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <DollarSign className="w-6 h-6 text-pink-600" />
                  Services & Rate Card
                </h2>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-gray-900">Service Menu</h3>
                    <button
                      type="button"
                      onClick={addService}
                      className="flex items-center gap-2 px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      Add Service
                    </button>
                  </div>

                  {services.map((service, index) => (
                    <div key={index} className="p-5 border-2 border-pink-100 rounded-xl bg-pink-50/30">
                      <div className="flex items-start justify-between mb-4">
                        <span className="text-sm font-bold text-pink-600">Service {index + 1}</span>
                        {services.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeService(index)}
                            className="text-red-500 hover:text-red-600 transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Service Name *
                          </label>
                          <input
                            type="text"
                            value={service.name}
                            onChange={(e) => updateService(index, 'name', e.target.value)}
                            className="w-full px-4 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                            placeholder="e.g., Hair Cut & Styling"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Category
                          </label>
                          <select
                            value={service.category}
                            onChange={(e) => updateService(index, 'category', e.target.value)}
                            className="w-full px-4 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                          >
                            {SERVICE_CATEGORIES.map(cat => (
                              <option key={cat} value={cat}>{cat}</option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Duration (minutes)
                          </label>
                          <input
                            type="number"
                            value={service.duration}
                            onChange={(e) => updateService(index, 'duration', e.target.value)}
                            min="15"
                            step="15"
                            className="w-full px-4 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Price (NGN) *
                          </label>
                          <input
                            type="number"
                            value={service.price}
                            onChange={(e) => updateService(index, 'price', e.target.value)}
                            min="0"
                            className="w-full px-4 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                            placeholder="0"
                          />
                        </div>

                        <div className="md:col-span-2">
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Description
                          </label>
                          <textarea
                            value={service.description}
                            onChange={(e) => updateService(index, 'description', e.target.value)}
                            rows={2}
                            className="w-full px-4 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                            placeholder="Brief description of the service"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">Booking Settings</h3>
                  <div className="space-y-3">
                    <label className="flex items-center gap-3 p-4 border-2 border-pink-100 rounded-xl hover:bg-pink-50/30 cursor-pointer transition-colors">
                      <input
                        type="checkbox"
                        checked={formData.walk_ins_accepted}
                        onChange={(e) => setFormData({...formData, walk_ins_accepted: e.target.checked})}
                        className="w-5 h-5 text-pink-500 border-gray-300 rounded focus:ring-pink-500"
                      />
                      <div>
                        <span className="font-semibold text-gray-900">Accept Walk-ins</span>
                        <p className="text-sm text-gray-600">Customers can visit without appointment</p>
                      </div>
                    </label>

                    <label className="flex items-center gap-3 p-4 border-2 border-pink-100 rounded-xl hover:bg-pink-50/30 cursor-pointer transition-colors">
                      <input
                        type="checkbox"
                        checked={formData.appointment_required}
                        onChange={(e) => setFormData({...formData, appointment_required: e.target.checked})}
                        className="w-5 h-5 text-pink-500 border-gray-300 rounded focus:ring-pink-500"
                      />
                      <div>
                        <span className="font-semibold text-gray-900">Appointment Required</span>
                        <p className="text-sm text-gray-600">All services require prior booking</p>
                      </div>
                    </label>

                    <label className="flex items-center gap-3 p-4 border-2 border-pink-100 rounded-xl hover:bg-pink-50/30 cursor-pointer transition-colors">
                      <input
                        type="checkbox"
                        checked={formData.online_booking_available}
                        onChange={(e) => setFormData({...formData, online_booking_available: e.target.checked})}
                        className="w-5 h-5 text-pink-500 border-gray-300 rounded focus:ring-pink-500"
                      />
                      <div>
                        <span className="font-semibold text-gray-900">Online Booking Available</span>
                        <p className="text-sm text-gray-600">Accept bookings through website/app</p>
                      </div>
                    </label>

                    {formData.online_booking_available && (
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Booking URL
                        </label>
                        <input
                          type="url"
                          value={formData.booking_url}
                          onChange={(e) => setFormData({...formData, booking_url: e.target.value})}
                          className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none"
                          placeholder="https://..."
                        />
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Payment Methods Accepted
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {['Cash', 'Card', 'Transfer', 'Mobile Money'].map(method => (
                      <button
                        key={method}
                        type="button"
                        onClick={() => handlePaymentMethodToggle(method)}
                        className={`px-4 py-3 rounded-lg border-2 font-semibold transition-colors ${
                          formData.payment_methods.includes(method)
                            ? 'bg-pink-500 text-white border-pink-500'
                            : 'bg-white text-gray-700 border-pink-200 hover:border-pink-400'
                        }`}
                      >
                        {method}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Cancellation Policy
                  </label>
                  <textarea
                    value={formData.cancellation_policy}
                    onChange={(e) => setFormData({...formData, cancellation_policy: e.target.value})}
                    rows={3}
                    className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-500 focus:outline-none"
                    placeholder="e.g., Cancel 24 hours before for full refund..."
                  />
                </div>

                <div className="flex justify-between pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(1)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(3)}
                    className="px-8 py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                  >
                    Next: Staff & Hours
                  </button>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Users className="w-6 h-6 text-pink-600" />
                  Staff & Working Hours
                </h2>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-gray-900">Our Team</h3>
                    <button
                      type="button"
                      onClick={addStaff}
                      className="flex items-center gap-2 px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      Add Staff
                    </button>
                  </div>

                  {staff.map((member, index) => (
                    <div key={index} className="p-5 border-2 border-pink-100 rounded-xl bg-pink-50/30">
                      <div className="flex items-start justify-between mb-4">
                        <span className="text-sm font-bold text-pink-600">Team Member {index + 1}</span>
                        {staff.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeStaff(index)}
                            className="text-red-500 hover:text-red-600 transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Name
                          </label>
                          <input
                            type="text"
                            value={member.name}
                            onChange={(e) => updateStaff(index, 'name', e.target.value)}
                            className="w-full px-4 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                            placeholder="Staff name"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Role
                          </label>
                          <select
                            value={member.role}
                            onChange={(e) => updateStaff(index, 'role', e.target.value)}
                            className="w-full px-4 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                          >
                            <option value="Stylist">Stylist</option>
                            <option value="Senior Stylist">Senior Stylist</option>
                            <option value="Barber">Barber</option>
                            <option value="Colorist">Colorist</option>
                            <option value="Braider">Braider</option>
                            <option value="Makeup Artist">Makeup Artist</option>
                            <option value="Manager">Manager</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Specialty
                          </label>
                          <input
                            type="text"
                            value={member.specialty}
                            onChange={(e) => updateStaff(index, 'specialty', e.target.value)}
                            className="w-full px-4 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                            placeholder="e.g., Braids, Color"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            Experience
                          </label>
                          <input
                            type="text"
                            value={member.experience}
                            onChange={(e) => updateStaff(index, 'experience', e.target.value)}
                            className="w-full px-4 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                            placeholder="e.g., 5 years"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-pink-600" />
                    Working Hours
                  </h3>
                  <div className="space-y-3">
                    {WORKING_DAYS.map(day => (
                      <div key={day} className="p-4 border-2 border-pink-100 rounded-xl">
                        <div className="flex items-center gap-4">
                          <div className="w-32">
                            <span className="font-semibold text-gray-900">{day}</span>
                          </div>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={workingHours[day]?.closed}
                              onChange={(e) => updateWorkingHours(day, 'closed', e.target.checked)}
                              className="w-4 h-4 text-pink-500 border-gray-300 rounded focus:ring-pink-500"
                            />
                            <span className="text-sm text-gray-600">Closed</span>
                          </label>
                          {!workingHours[day]?.closed && (
                            <>
                              <input
                                type="time"
                                value={workingHours[day]?.open || ''}
                                onChange={(e) => updateWorkingHours(day, 'open', e.target.value)}
                                className="px-3 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                              />
                              <span className="text-gray-600">to</span>
                              <input
                                type="time"
                                value={workingHours[day]?.close || ''}
                                onChange={(e) => updateWorkingHours(day, 'close', e.target.value)}
                                className="px-3 py-2 border-2 border-pink-200 rounded-lg focus:border-pink-500 focus:outline-none"
                              />
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">Amenities & Facilities</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {AMENITIES.map(amenity => (
                      <button
                        key={amenity}
                        type="button"
                        onClick={() => handleAmenityToggle(amenity)}
                        className={`px-4 py-3 rounded-lg border-2 font-semibold text-sm transition-colors ${
                          amenities.includes(amenity)
                            ? 'bg-pink-500 text-white border-pink-500'
                            : 'bg-white text-gray-700 border-pink-200 hover:border-pink-400'
                        }`}
                      >
                        {amenity}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(4)}
                    className="px-8 py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-xl font-bold hover:shadow-lg transition-all"
                  >
                    Next: Gallery
                  </button>
                </div>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-pink-600" />
                  Salon Gallery
                </h2>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Upload Images (Max 10) *
                  </label>
                  <p className="text-sm text-gray-600 mb-4">
                    Show your salon interior, work samples, team photos
                  </p>
                  <div className="border-2 border-dashed border-pink-300 rounded-2xl p-8 text-center hover:border-pink-500 transition-colors bg-pink-50/30">
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleImageSelect}
                      className="hidden"
                      id="image-upload"
                    />
                    <label htmlFor="image-upload" className="cursor-pointer">
                      <Upload className="w-16 h-16 text-pink-400 mx-auto mb-3" />
                      <span className="text-gray-700 font-semibold block mb-1">Click to upload salon images</span>
                      <span className="text-sm text-gray-500">PNG, JPG up to 10 images</span>
                    </label>
                  </div>

                  {previews.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
                      {previews.map((preview, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={preview}
                            alt={`Preview ${index + 1}`}
                            className="w-full h-32 object-cover rounded-xl border-2 border-pink-200"
                          />
                          <button
                            type="button"
                            onClick={() => removeImage(index)}
                            className="absolute -top-2 -right-2 p-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-gradient-to-br from-pink-50 to-purple-50 border-2 border-pink-200 rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Award className="w-5 h-5 text-pink-600" />
                    Listing Summary
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Salon Name:</span>
                      <span className="font-semibold text-gray-900">{formData.salon_name || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Location:</span>
                      <span className="font-semibold text-gray-900">{formData.location_city || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Services:</span>
                      <span className="font-semibold text-gray-900">{services.filter(s => s.name).length} services</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Staff Members:</span>
                      <span className="font-semibold text-gray-900">{staff.filter(s => s.name).length} members</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Images:</span>
                      <span className="font-semibold text-gray-900">{images.length} uploaded</span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(3)}
                    className="px-8 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={uploading || images.length === 0}
                    className="px-8 py-4 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-xl font-bold hover:shadow-2xl disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
                  >
                    {uploading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Star className="w-5 h-5" />
                        Publish Salon Listing
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
};
