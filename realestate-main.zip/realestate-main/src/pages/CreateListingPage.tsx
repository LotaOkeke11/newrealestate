import { useEffect } from 'react';

export const CreateListingPage = () => {
  useEffect(() => {
    window.location.href = '/post-ad';
  }, []);

  return null;
};
