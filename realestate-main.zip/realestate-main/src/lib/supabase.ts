import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  full_name: string;
  phone_number: string | null;
  account_type: 'buyer' | 'seller' | 'business';
  location_state: string | null;
  location_city: string | null;
  avatar_url: string | null;
  referral_code: string | null;
  referred_by: string | null;
  subscribe_promotions: boolean;
  created_at: string;
  updated_at: string;
};

export type Category = {
  id: string;
  name: string;
  slug: string;
  icon: string | null;
  description: string | null;
  parent_id: string | null;
  order_index: number;
  is_active: boolean;
  created_at: string;
};

export type Listing = {
  id: string;
  user_id: string;
  category_id: string;
  title: string;
  description: string | null;
  price: number;
  currency: string;
  condition: string | null;
  status: string;
  location_state: string | null;
  location_city: string | null;
  location_area: string | null;
  latitude: number | null;
  longitude: number | null;
  is_featured: boolean;
  is_boosted: boolean;
  boost_expires_at: string | null;
  views_count: number;
  contact_phone: string | null;
  contact_whatsapp: string | null;
  images: string[];
  video_url: string | null;
  metadata: Record<string, any>;
  ai_moderation_status: string;
  ai_moderation_notes: string | null;
  created_at: string;
  updated_at: string;
};

export type Subscription = {
  id: string;
  user_id: string;
  tier: 'free' | 'starter' | 'pro' | 'verified_business' | 'premium_enterprise';
  status: 'active' | 'expired' | 'cancelled';
  starts_at: string;
  expires_at: string | null;
  listings_used: number;
  listings_limit: number;
  created_at: string;
};
