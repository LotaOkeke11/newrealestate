import { useEffect, useState } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import { HomePage } from './pages/HomePage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { ImprovedSellerDashboard } from './pages/ImprovedSellerDashboard';
import { CategoryPage } from './pages/CategoryPage';
import { RealEstateListingForm } from './pages/RealEstateListingForm';
import { PostAdPage } from './pages/PostAdPage';
import { SubscriptionPage } from './pages/SubscriptionPage';
import { SubscriptionSuccessPage } from './pages/SubscriptionSuccessPage';
import { CreateListingPage } from './pages/CreateListingPage';
import { MessagesPage } from './pages/MessagesPage';
import { ChatPage } from './pages/ChatPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { SellerVerificationPage } from './pages/SellerVerificationPage';
import { SearchResultsPage } from './pages/SearchResultsPage';
import { BrowseCategoriesPage } from './pages/BrowseCategoriesPage';
import { RentalsPage } from './pages/RentalsPage';
import { JobsServicesPage } from './pages/JobsServicesPage';
import { RealEstateDetailPage } from './pages/RealEstateDetailPage';
import { ElectronicsDetailPage } from './pages/ElectronicsDetailPage';
import { UnifiedPostAdPage } from './pages/UnifiedPostAdPage';
import { UploadRealEstatePage } from './pages/UploadRealEstatePage';
import { UploadElectronicsPage } from './pages/UploadElectronicsPage';
import { UploadShortletAirbnbPage } from './pages/UploadShortletAirbnbPage';
import { UploadCamerasPage } from './pages/UploadCamerasPage';
import { UploadCarsJijiPage } from './pages/UploadCarsJijiPage';
import { UploadCarPartsPage } from './pages/UploadCarPartsPage';
import { UploadMediaCreativePage } from './pages/UploadMediaCreativePage';
import { UploadFashionPage } from './pages/UploadFashionPage';
import { UploadMotorcyclesPage } from './pages/UploadMotorcyclesPage';
import { UploadServiceProvidersPage } from './pages/UploadServiceProvidersPage';
import { UploadBeautyPage } from './pages/UploadBeautyPage';
import { UploadHairSalonPage } from './pages/UploadHairSalonPage';
import { UploadFoodstuffsPage } from './pages/UploadFoodstuffsPage';
import { UploadRestaurantPage } from './pages/UploadRestaurantPage';
import { FoodCategoryPage } from './pages/FoodCategoryPage';
import { UploadFurniturePage } from './pages/UploadFurniturePage';
import { UploadAudioEquipmentPage } from './pages/UploadAudioEquipmentPage';
import { CarDetailPage } from './pages/CarDetailPage';
import { CarPartsDetailPage } from './pages/CarPartsDetailPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { EditListingPage } from './pages/EditListingPage';

function App() {
  const [route, setRoute] = useState(window.location.pathname);

  useEffect(() => {
    const handlePopState = () => {
      setRoute(window.location.pathname);
    };

    window.addEventListener('popstate', handlePopState);

    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');

      if (anchor && anchor.href && anchor.origin === window.location.origin) {
        e.preventDefault();
        const url = new URL(anchor.href);
        window.history.pushState({}, '', url.pathname);
        setRoute(url.pathname);
        window.scrollTo(0, 0);
      }
    };

    document.addEventListener('click', handleClick);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      document.removeEventListener('click', handleClick);
    };
  }, []);

  const renderRoute = () => {
    if (route.startsWith('/category/')) {
      const slug = route.split('/category/')[1];
      return <CategoryPage slug={slug} />;
    }

    if (route.startsWith('/property/')) {
      return <RealEstateDetailPage />;
    }

    if (route.startsWith('/electronics/')) {
      return <ElectronicsDetailPage />;
    }

    if (route.startsWith('/car/')) {
      return <CarDetailPage />;
    }

    if (route.startsWith('/car-part/')) {
      return <CarPartsDetailPage />;
    }

    if (route.startsWith('/edit-listing/')) {
      return <EditListingPage />;
    }

    if (route.startsWith('/listing/')) {
      return <ProductDetailPage />;
    }

    if (route.startsWith('/product/')) {
      return <ProductDetailPage />;
    }

    if (route.startsWith('/upload/')) {
      const category = route.split('/upload/')[1];
      if (category === 'real-estate') return <UploadRealEstatePage />;
      if (category === 'shortlet' || category === 'rentals') return <UploadShortletAirbnbPage />;
      if (category === 'vehicles' || category === 'cars-sale') return <UploadCarsJijiPage />;
      if (category === 'auto-parts') return <UploadCarPartsPage />;
      if (category === 'cameras') return <UploadCamerasPage />;
      if (category === 'media-creative') return <UploadMediaCreativePage />;
      if (category === 'electronics') return <UploadElectronicsPage />;
      if (category === 'fashion' || category === 'men-fashion') return <UploadFashionPage />;
      if (category === 'motorcycles') return <UploadMotorcyclesPage />;
      if (category === 'lands') return <UploadRealEstatePage />;
      if (category === 'lighting') return <UploadCamerasPage />;
      if (category === 'electrical') return <UploadElectronicsPage />;
      if (category === 'audio-equipment') return <UploadAudioEquipmentPage />;
      if (category === 'photographers') return <UploadServiceProvidersPage />;
      if (category === 'performers') return <UploadServiceProvidersPage />;
      if (category === 'accessories') return <UploadFashionPage />;
      if (category === 'beauty' || category === 'beauty-personal-care') return <UploadBeautyPage />;
      if (category === 'hair-salon-services') return <UploadHairSalonPage />;
      if (category === 'wigs-extensions') return <UploadBeautyPage />;
      if (category === 'makeup-services') return <UploadBeautyPage />;
      if (category === 'makeup-products') return <UploadBeautyPage />;
      if (category === 'skincare-products') return <UploadBeautyPage />;
      if (category === 'perfumes-fragrances') return <UploadBeautyPage />;
      if (category === 'spa-wellness') return <UploadBeautyPage />;
      if (category === 'boats-marine') return <UploadCarsJijiPage />;
      if (category === 'cleaning-services') return <UploadServiceProvidersPage />;
      if (category === 'designers') return <UploadServiceProvidersPage />;
      if (category === 'pet-store') return <UploadElectronicsPage />;
      if (category === 'luxury-rentals') return <UploadCarsJijiPage />;
      if (category === 'commercial') return <UploadRealEstatePage />;
      if (category === 'furniture') return <UploadFurniturePage />;
      if (category === 'home-garden') return <UploadFurniturePage />;
      if (category === 'jobs') return <UploadMediaCreativePage />;
      if (category === 'foodstuffs') return <UploadFoodstuffsPage />;
      if (category === 'restaurants') return <UploadRestaurantPage />;
      if (category === 'food-restaurants') return <UploadFoodstuffsPage />;
      return <UploadElectronicsPage />;
    }

    switch (route) {
      case '/':
        return <HomePage />;
      case '/login':
        return <LoginPage />;
      case '/register':
        return <RegisterPage />;
      case '/dashboard':
      case '/seller-dashboard':
        return <ImprovedSellerDashboard />;
      case '/list-property':
        return <RealEstateListingForm />;
      case '/post-ad':
        return <UnifiedPostAdPage />;
      case '/create-listing':
        return <CreateListingPage />;
      case '/subscription':
        return <SubscriptionPage />;
      case '/subscription/success':
        return <SubscriptionSuccessPage />;
      case '/messages':
        return <MessagesPage />;
      case '/chat':
        return <ChatPage />;
      case '/cart':
        return <CartPage />;
      case '/checkout':
        return <CheckoutPage />;
      case '/verification':
        return <SellerVerificationPage />;
      case '/search':
        return <SearchResultsPage />;
      case '/categories':
        return <BrowseCategoriesPage />;
      case '/rentals':
        return <RentalsPage />;
      case '/jobs-services':
        return <JobsServicesPage />;
      case '/food-category':
        return <FoodCategoryPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <AuthProvider>
      {renderRoute()}
    </AuthProvider>
  );
}

export default App;
